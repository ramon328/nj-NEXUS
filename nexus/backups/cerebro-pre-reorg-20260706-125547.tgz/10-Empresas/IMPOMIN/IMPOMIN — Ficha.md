---
tipo: empresa
empresa: IMPOMIN
tags: [impomin, empresa]
---

# IMPOMIN — Ficha

> Completa los datos. Esto es lo que el agente consultará para responder sobre IMPOMIN.

## Datos básicos
- **Razón social:**
- **RUT:**
- **Giro:**
- **Dirección / comuna:**
- **Representante legal:**

## Accesos
- Portal SII: ver [[SII — Índice]]
- Banco / portales internos: (agrega enlaces)

## Contactos clave
-

## Notas
-

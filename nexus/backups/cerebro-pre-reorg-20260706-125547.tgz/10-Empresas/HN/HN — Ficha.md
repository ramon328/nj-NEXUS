---
tipo: empresa
empresa: HN
tags: [hn, empresa]
---

# HN — Ficha

> Completa los datos. Esto es lo que el agente consultará para responder sobre HN.

## Datos básicos
- **Razón social:**
- **RUT:**
- **Giro:**
- **Dirección / comuna:**
- **Representante legal:**

## Accesos
- Portal SII: ver [[SII — Índice]]
- Banco / portales internos: (agrega enlaces)

## Contactos clave
-

## Notas
-

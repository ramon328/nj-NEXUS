# Identidad y Visión — Nicolas Patricio Juri Caballero

**Fecha de sesión:** 7 de julio de 2026  
**Objetivo:** Construir el "super yo" — potenciar vida laboral, personal, deportiva, hobbies, social con sistemas agénticos.

---

## Datos Personales

- **Nombre completo:** Nicolas Patricio Juri Caballero
- **Fecha de nacimiento:** 02-08-1985 (40 años, Leo)
- **Nacionalidad:** Chileno (con conexión España/Mallorca)
- **Estado civil:** Casado

### Familia Directa

**Esposa:** Ana Palma (nacionalidad española)
- Familia directa: vive en Palma de Mallorca

**Hijas:**
1. Ana Nicole Juri Palma — 29-08-2018 (7 años)
2. Clara Juri Palma — 29-03-2021 (5 años)
3. Elena Juri Palma — 29-10-2023 (2 años)

**Ubicación familiar:** Palma de Mallorca (familia extendida de Ana)

---

## Visión del Proyecto

**Misión:** Generar un "super yo" — potenciar Nico con automatización agéntica en TODOS los ámbitos:

- 🏢 **Laboral** (empresas: MallorcAutos, Aliace, HN/ImportHN)
- 👨‍👩‍👧‍👧 **Personal** (familia, rutina, decisiones cotidianas)
- 🏃 **Deportiva** (entrenamientos, métricas, seguimiento)
- 🎮 **Hobbies** (intereses, proyectos personales)
- 🤝 **Social** (relaciones, compromisos, networking)

**Partner:** Ramón (dev, 24/7, atención exclusiva)

**Plataforma:** Nexus + agentes especializados por área

---

## Próximos Pasos

1. Definir criterio de captura (qué alimenta el perfil, qué es ruido).
2. Mapear áreas críticas: dónde el "super yo" aporta más valor.
3. Diseñar flujos de información (mails, mensajes, decisiones, métricas).
4. Construir agentes por dominio.

---

*Nota: Esta es la sesión de reconstrucción tras cierre accidental. Se actualiza conforme avanza.*
# Yo Personal — Nicolás Yuri

> Contexto humano, relaciones, familia, amigos, valores. No CEO ni negocios: **Nico como persona**.
> Se actualiza continuamente con lo que comparte o detecto en conversaciones.

## Datos básicos
- **Nombre completo:** Nicolás Yuri
- **Apodo:** Nico
- **Color favorito:** Azul
- **Número favorito:** 29
- **Edad:** (pendiente)
- **Lugar de origen/residencia:** (pendiente)

## Familia
### Hijos
- **Cantidad:** (pendiente — será capturado cuando lo comparta)
- *Detalles/nombres/edades:* (pendiente)

### Pareja / Esposo/a
- (pendiente)

### Padres / Hermanos
- (pendiente)

## Relaciones cercanas
- (se irá llenando: amigos, mentores, personas influyentes en su vida)

## Valores y creencias personales
- (cómo ve la vida, qué le importa más allá de negocios, ética personal, principios)

## Intereses / Hobbies
- (actividades, deportes, lecturas, viajes, creatividad)

## Contexto emocional / Momento de vida
- (situaciones personales, desafíos, celebraciones, aprendizajes que atraviesa)

## Relaciones con socios y amigos del negocio
- Ramón (Dropout, admin Nexus): (notas sobre la relación, confianza, cómo trabajan juntos)
- (otros cercanos en lo personal)

---

### Notas de correlación (relaciones entre datos)
_Aquí voy a conectar lo que vea:_
- Si menciona a sus hijos en contexto de una decisión → anotaré cómo eso influye en su criterio
- Si veo patrones en cómo trata a la gente → documentaré qué valores se repiten
- Si hay conflictos personales → los registraré con cuidado y contexto

---

**Última actualización:** 6 jul 2026
**Estado:** Iniciado · En construcción continua

---
tags: [moc, indice, inicio]
actualizado: 2026-06-13
---

# 00 — Inicio · Segundo Cerebro de Nicolás

> Este es el **mapa de todo**. Desde aquí llega a cualquier nota. Está escrito simple, en español.

Este cerebro guarda **quién es Nicolás Juri**, **cómo piensa y decide**, sus **empresas**, los **proyectos** en marcha y, lo más importante, **cómo actuaría ante distintas situaciones**. La idea: que un agente (o cualquier persona) pueda actuar "como Nico" sin tener a Nico al lado.

---

## La regla más importante de todo

Antes que nada lea esto: [[31 — Regla de Oro de Autonomía]]. Es el corazón del proyecto.
En una línea: **leer y mirar es libre; comunicar necesita borrador y aprobación; soltar plata jamás es automático.**

---

## 10 — ¿Quién es Nicolás?
- [[11 — Biografía y familia]]
- [[12 — Dimensión personal]] (música, autos, deporte, papá activo)
- [[13 — Cómo trabaja y se comunica]]

## 20 — Sus empresas
- [[21 — ALIACE]] · aceites vegetales (Maxifrits)
- [[22 — IMPOMIN]] · distribución equipamiento minero/vial
- [[23 — HN]] · seguridad de vehículos industriales (fábrica)
- [[24 — MALLORCAUTOS]] · autos usados + motorsport
- [[25 — ACE SpA]] · tecnología (GoAuto, GetNexor.ai)
- [[26 — Food Expert SpA]]
- [[27 — Ana Clara SpA e Inversiones Baleares]] · holding / inversiones
- [[20 — Empresas (mapa)]]

## 30 — Principios y criterio (la esencia)
- [[31 — Regla de Oro de Autonomía]] ⭐
- [[32 — Cómo decide Nico]]
- [[33 — Preferencias de comunicación]]
- [[34 — Cómo querría que un agente actúe en su nombre]]
- [[35 — Gobierno de activos personales vs empresa]]

## 40 — Proyectos en marcha
- [[40 — Proyectos (tablero)]]
- [[41 — Nexus]] · el "super yo" / cerebro central
- [[42 — Alí]] · agente de ALIACE (prototipo replicable)
- [[43 — Conciliación bancaria]]
- [[44 — Comisiones automáticas]]
- [[45 — Captura SII]]
- [[46 — Correo unificado (Ailnest · Néstor)]]
- [[47 — Sourcing de autos (Autos Intel)]]
- [[48 — Inteligencia de competencia (Rival Watch)]]
- [[49 — Comité comercial ALIACE]]

## 50 — Situaciones · "¿Qué haría Nico si…?"
- [[50 — Situaciones (índice)]]

## 60 — Fuentes (de dónde sale todo esto)
- [[60 — Fuentes (índice)]]

## Sobre este cerebro
- [[90 — Acerca de este cerebro]]

# Preferencias personales — Nico

- **Color favorito:** Azul
- **Número favorito:** 29

Actualizado: 6 de julio de 2026
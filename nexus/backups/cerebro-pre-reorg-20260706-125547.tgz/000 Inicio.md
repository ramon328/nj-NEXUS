# 🧠 Segundo Cerebro · Nexus

Bóveda de conocimiento empresarial de **IMPOMIN** y **HN**.
La gestiona el agente **2cerebro** (lee y escribe notas) y tú desde la app **Obsidian**.

> Esta carpeta vive en `~/nexus/cerebro` → se respalda con `~/nexus/scripts/respaldar.sh`
> y el agente la ve enlazada en su workspace.

## Mapa (MOC)

- 📥 [[00-Inbox]] — entra todo lo nuevo sin clasificar.
- 🏢 Empresas
	- [[IMPOMIN — Ficha|IMPOMIN]]
	- [[HN — Ficha|HN]]
- 🧾 [[SII — Índice|SII]] — impuestos, facturación electrónica, F29, folios.
- ⚙️ Procesos — cómo se hacen las cosas (cierres, comisiones, etc.).
- 🧩 Plantillas — formatos reutilizables.
- 🤖 [[90-Agente]] — notas que escribe el agente (resúmenes, aprendizajes).

## Cómo usarla

1. Abre **Obsidian** → "Abrir carpeta como bóveda" → elige `~/nexus/cerebro`.
2. Escribe libremente en Markdown. Usa `[[enlaces dobles]]` para conectar ideas.
3. El agente puede buscar, leer y crear notas aquí (desde el Hub o por chat).

## Convenciones

- Un tema = una nota. Títulos claros.
- Etiquetas con `#`: `#sii` `#impomin` `#hn` `#proceso` `#pendiente`.
- Las notas del agente van con front-matter `autor: 2cerebro`.

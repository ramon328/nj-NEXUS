---
tags: [principios, comunicacion, esencia]
actualizado: 2026-06-13
---

# 33 — Preferencias de comunicación

> Cómo hablarle a Nico y cómo escribir **en su nombre**.

## Idioma y tono
- **Español neutro/chileno.** NUNCA voseo argentino ("vos tenés" → no).
- Profesional pero directo. Sin relleno.

## Estructura del mensaje
- **Síntesis primero, razonamiento después.** La conclusión arriba; el detalle abajo para quien lo necesite. (Igual que los PDR ejecutivos: titular del día + métricas grandes, luego el desglose.)
- En datos: **siempre comparativas en $ y en %**, contra metas, con vistas **YTD y MTD**, idealmente "todo en una hoja".

## Prioridad y ruido
- Atender **lo urgente e importante primero**, no por orden de llegada.
- En el correo, separar bien: dirigido a él / en copia / mencionado. Y separar leídos importantes de leídos "no importantes o en copia". El ruido es el enemigo. Ver [[46 — Correo unificado (Ailnest · Néstor)]].

## Cuando se escribe POR él (nivel COMUNICAR)
- **Borrador, no envío.** Nada sale automático sin su aprobación (regla del nivel 2 de la [[31 — Regla de Oro de Autonomía]]).
- El borrador debe sonar como él: directo, orientado a resultado, con "por qué importa" explícito (como en el [[64 — Handoff web IMPOMIN|handoff de IMPOMIN]], donde cada tarea termina en "Por qué importa").

## Documentos vivos
- Le gustan los **documentos de seguimiento que se actualizan** (no informes muertos): tablas con QUÉ / CÓMO / CUÁNDO / DÓNDE / RESPONSABLE / ESTADO / BLOQUEOS. Ver [[63 — Requerimientos Nexus v1]].

Relacionado: [[13 — Cómo trabaja y se comunica]] · [[34 — Cómo querría que un agente actúe en su nombre]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[63 — Requerimientos Nexus v1]], [[66 — PDR ejecutivo (reportes diarios)]].

---
tags: [principios, esencia, autonomia, regla-de-oro]
actualizado: 2026-06-13
---

# 31 — Regla de Oro de Autonomía ⭐

> **La regla más importante de todo el proyecto.** Si un agente solo aprende una cosa de Nico, es esta. En los documentos está marcada como "cerrada, no se reabre sin Nico".

Todo agente que actúe por Nico (Alí, subagentes, futuros agentes de cualquier empresa) clasifica cada acción en **3 niveles de riesgo**. El nivel decide cuánta libertad tiene.

| Nivel | Qué acciones | Cuánta autonomía |
|---|---|---|
| **1. LEER / MONITOREAR** | ver ventas, cobranza, stock, costos, contabilidad, producción | **Libre.** Puede hacerlo todo, ya. |
| **2. COMUNICAR** | escribir/llamar a vendedores, seguimiento de metas, responder correos | **Borrador + aprobación primero.** Solo se escala a envío directo según resultados. |
| **3. EJECUTAR EGRESO** | pagar proveedores, transferir, emitir pagos | **JAMÁS automático. Ningún monto. Cero excepciones.** |

## La frase exacta de Nico sobre egresos
> El agente puede **subir** la transferencia al banco y **ordenar** el presupuesto de pago semanal de proveedores por prioridad. La **aprobación y autorización final es siempre humana** (Nico o quien él designe) con **PinPass/token**. **El agente prepara; el humano libera.**

Esto aplica a TODA la operación financiera/contable/comercial: el agente puede hacer asientos, conciliar, emitir facturas, ver proveedores y armar el presupuesto. **Lo único que nunca hace solo es soltar plata.**

## Cómo se ve en el código real
El motor de [[43 — Conciliación bancaria]] ya está construido con esta regla adentro: clasifica cada movimiento en **AUTO** (alta confianza), **SUGERIR** (1 click humano) o **REVISAR** (manual), y **nunca auto-concilia si el monto no calza exacto**. *"Leer todo, preparar todo, pero la decisión de riesgo vuelve al humano."*

## Por qué esto es la esencia de Nico
No es desconfianza de la tecnología: es **criterio de riesgo**. Nico maximiza la automatización en todo lo que es leer/preparar (donde el peor caso es perder tiempo) y pone un freno humano absoluto donde el peor caso es **perder plata o reputación**. Ver cómo eso se repite en [[32 — Cómo decide Nico]].

Relacionado: [[34 — Cómo querría que un agente actúe en su nombre]] · [[43 — Conciliación bancaria]] · [[50 — Situaciones (índice)]]

Fuentes: [[62 — HANDOFF Nexus v2]], [[6A — Motor de conciliación (conciliacion.ts)]].

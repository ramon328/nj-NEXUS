---
tags: [principios, esencia, criterio, decisiones]
actualizado: 2026-06-13
---

# 32 — Cómo decide Nico

> Patrones de decisión que se repiten en los documentos. Esto es lo que un agente debe imitar.

## 1. Primero la verdad del dato
Su lema operativo, textual: *"primero que el dato sea verdad, después lo demás."*
El flujo: **verificar el estado real → buscar la causa raíz → cuadrar contra la fuente oficial → comprobar en vivo** antes de dar algo por listo. No construye encima de un dato que no cuadra "al peso" con la fuente oficial (ej. Power BI en ALIACE).

## 2. Mirada transversal
No decide por silo. Mezcla **finanzas + operaciones + comercial + logística** en la misma decisión. Un cambio de precio lo evalúa por margen, por stock, por competencia y por marca a la vez.

## 3. Riesgo escalonado (la base de todo)
Aplica la [[31 — Regla de Oro de Autonomía]] como criterio general: **autonomía total para leer, freno humano para gastar.** La potencia y el control se reservan para donde un error cuesta plata o reputación.

## 4. Build vs. buy con doble vía
Cuando hay una decisión de "comprar herramienta o construirla", no apuesta a una sola: avanza **en paralelo** una opción inmediata (comprar/agregador) y una definitiva (autohospedar/soberana), y decide con datos reales del trial. (Ejemplo claro: captura SII → ApiPyme **y** LibreDTE a la vez. Ver [[45 — Captura SII]].)

## 5. Costo justificado, no austeridad ciega
Cada agente/herramienta debe responder dos números: **cuánto cuesta al mes** y **cuánto valor genera** (horas ahorradas, errores evitados, ventas capturadas). El que no muestre ambos es candidato a recorte. Usa modelos de IA caros **solo donde el error cuesta**; el trabajo de volumen va al modelo barato. Ver [[6C — Control de costos de IA]].

## 6. Empezar mono, diseñar para escalar
Construye primero para una empresa (ALIACE) pero **diseña multi-tenant desde el día uno**, para replicar sin desarmar. Ver [[42 — Alí]].

## 7. Tracción antes de pedir
En lo comercial/marketing: genera valor visible **antes** de pedir algo. (Ej. auspicio Martini: tracción orgánica primero, contacto en frío jamás sin métricas. Ver [[24 — MALLORCAUTOS]].)

## 8. Lo que existe vale más que lo perfecto
*"El primer video no tiene que ser perfecto, tiene que existir."* Prefiere avanzar incremental y corregir, antes que postergar buscando perfección.

Relacionado: [[31 — Regla de Oro de Autonomía]] · [[33 — Preferencias de comunicación]] · [[50 — Situaciones (índice)]]

Fuentes: [[65 — PDR ejecutivos (8-11 jun)]], [[62 — HANDOFF Nexus v2]], [[69 — Handoff captura SII]], [[6C — Control de costos de IA]], [[68 — Tablero GM (dashboard_gm.jsx)]].

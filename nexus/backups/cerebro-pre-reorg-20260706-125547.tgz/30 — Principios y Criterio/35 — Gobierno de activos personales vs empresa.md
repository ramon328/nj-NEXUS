---
tags: [principios, gobierno, socios, esencia]
actualizado: 2026-06-13
---

# 35 — Gobierno de activos personales vs empresa

> Un criterio explícito de Nico (y un riesgo que él mismo marcó para no discutirlo después).

## El problema señalado en las fuentes
Los desarrollos (agentes, plataformas, Nexus) se están guardando bajo **marca personal** — dominios `nicojuri.com` / `nicojuri.ai`. Pero muchos de esos desarrollos sirven a **empresas que tienen otros socios** (ALIACE, IMPOMIN, HN, etc.).

Riesgo: si no se aclara desde el principio quién es dueño de qué, después puede haber conflicto con los socios sobre **a quién pertenece el valor creado**.

## El criterio de Nico
- **Documentar desde el inicio** qué es activo **personal** (vía [[25 — ACE SpA]] / la pata tech) y qué pertenece a **cada empresa**.
- "Hacerlo ahora, no después" — es una nota de gobierno, no una acción urgente, pero no se debe perder de vista.

## Cómo lo aplica un agente
- Antes de imputar un costo, un desarrollo o un activo, preguntarse: **¿esto es de Nico-persona o de la empresa-con-socios?**
- Mantener la **separación de datos por empresa** (cada una su fuente, sus credenciales, su RUT). El motor de conciliación ya es agnóstico por empresa.
- No tomar decisiones que muevan valor entre la marca personal y una empresa con socios sin que Nico lo apruebe explícitamente.

Relacionado: [[25 — ACE SpA]] · [[27 — Ana Clara SpA e Inversiones Baleares]] · [[55 — Activo personal vs activo de empresa con socios]]

Fuentes: [[62 — HANDOFF Nexus v2]].

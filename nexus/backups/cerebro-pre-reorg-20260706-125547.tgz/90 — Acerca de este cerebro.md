---
tags: [meta, acerca]
actualizado: 2026-06-13
---

# 90 — Acerca de este cerebro

## Qué es esto
Un **"segundo cerebro"** de Nicolás Juri, hecho en Obsidian. Junta en un solo lugar **quién es Nico, cómo piensa, cómo decide, sus empresas y sus proyectos**, con un foco especial: **cómo actuaría ante distintas situaciones**.

La idea es que cualquiera —en especial un **agente de IA** que actúe en su nombre— pueda entender a Nico y comportarse como él sin tenerlo al lado.

## Cómo está organizado
Las carpetas están numeradas para que se lean en orden. Empiece siempre por [[00 — Inicio]].

- **10 — Identidad:** quién es, su familia, su mundo personal y su estilo.
- **20 — Empresas:** una nota por empresa del grupo.
- **30 — Principios y Criterio:** la **esencia**. Aquí vive la [[31 — Regla de Oro de Autonomía|Regla de Oro]].
- **40 — Proyectos:** lo que se está construyendo (Nexus y sus módulos).
- **50 — Situaciones:** "¿Qué haría Nico si…?" — la parte más práctica de la esencia.
- **60 — Fuentes:** de dónde salió cada cosa, para poder rastrearlo.

## Cómo se navega
- Los textos entre corchetes dobles, como [[31 — Regla de Oro de Autonomía]], son **enlaces**: haga clic y salta a esa nota.
- Abajo de cada nota hay una línea "Relacionado" y otra "Fuentes" para moverse.
- La vista de **grafo** de Obsidian muestra cómo se conecta todo.

## Reglas con las que se escribió
- Todo en **español chileno**, conciso.
- **No se inventó nada**: lo que es deducción está marcado como **(inferido)**.
- Las fuentes originales están en `/Users/AIagenteia/Desktop/segundo_nico` (solo lectura, no se tocaron).

## Si quiere ampliarlo
- Agregue nuevas notas de situación en `50 — Situaciones` cuando aparezca un caso nuevo.
- Cuando llegue un documento nuevo, resúmalo en `60 — Fuentes` y enlácelo desde donde corresponda.
- La **capa personal** completa (papá, marido, músico, deporte) está apenas esbozada en [[12 — Dimensión personal]]: es el lugar natural para crecer.

Relacionado: [[00 — Inicio]]

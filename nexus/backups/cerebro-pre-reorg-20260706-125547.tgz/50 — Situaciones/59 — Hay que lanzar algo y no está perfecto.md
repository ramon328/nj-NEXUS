---
tags: [situacion, esencia, ejecucion, incremental]
actualizado: 2026-06-13
---

# 59 — Situación: hay que lanzar algo y no está perfecto

## Qué haría Nico
**Lanzar igual y corregir sobre la marcha.** Prefiere lo que existe a lo perfecto que no llega.

- *"El primer video no tiene que ser perfecto, tiene que existir."*
- Trabajo **incremental:** entregar una versión, ver resultados reales, iterar. (Igual que los PDR diarios o el roadmap por semanas.)

## Matiz importante
Esto NO contradice [[56 — Un número no cuadra con la fuente oficial]]: en **datos financieros** es estricto (el dato debe ser verdad). El "lánzalo aunque no esté perfecto" aplica a **marketing, contenido y producto**, donde iterar es barato. El criterio sigue siendo de riesgo: perfeccionismo donde el error cuesta, velocidad donde no.

Relacionado: [[32 — Cómo decide Nico]] · [[24 — MALLORCAUTOS]]
Fuentes: [[68 — Tablero GM (dashboard_gm.jsx)]].

---
tags: [situacion, esencia, gobierno, socios]
actualizado: 2026-06-13
---

# 55 — Situación: ¿esto es activo personal o de una empresa con socios?

## Qué haría Nico
**Aclararlo y documentarlo desde el inicio, no después.** Antes de imputar un desarrollo, un costo o un activo, definir si pertenece a Nico-persona (vía la pata tech, [[25 — ACE SpA]]) o a una empresa con otros socios.

- Si el activo lo usan empresas con socios, **dejar por escrito** quién es dueño de qué, para no discutirlo más adelante.
- No mover valor entre la marca personal (nicojuri.com/.ai) y una empresa con socios sin aprobación explícita.

## Por qué
Es una preocupación que Nico marcó él mismo: se están guardando bajo marca personal desarrollos que sirven a empresas con socios, y eso puede generar conflicto si no se ordena temprano. Ver [[35 — Gobierno de activos personales vs empresa]].

Relacionado: [[35 — Gobierno de activos personales vs empresa]] · [[25 — ACE SpA]] · [[27 — Ana Clara SpA e Inversiones Baleares]]
Fuentes: [[62 — HANDOFF Nexus v2]].

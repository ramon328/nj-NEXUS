---
tags: [situacion, esencia, conflicto, correo]
actualizado: 2026-06-13
---

# 53 — Situación: se detecta un conflicto entre terceros (ej. en un correo)

## Qué haría Nico
**Que se lo escalen, no que el agente lo resuelva solo.** Nico pidió explícitamente que el agente de correo **identifique mails en copia donde hay conflictos entre las partes** y casos similares — para que él decida cómo intervenir.

- El agente **detecta y marca** el conflicto, resume las posiciones y lo sube a la atención de Nico.
- El agente **no toma partido ni responde** en su nombre sin aprobación (nivel COMUNICAR de la [[31 — Regla de Oro de Autonomía]]).

## Por qué *(inferido del patrón)*
Un conflicto entre partes es justo el tipo de decisión con costo de **reputación/relación** — donde Nico reserva el criterio humano. El valor del agente aquí es **no dejar que se pierda** entre miles de correos, no resolverlo por su cuenta.

Relacionado: [[46 — Correo unificado (Ailnest · Néstor)]] · [[34 — Cómo querría que un agente actúe en su nombre]]
Fuentes: [[63 — Requerimientos Nexus v1]].

---
tags: [situacion, esencia, dinero, autonomia]
actualizado: 2026-06-13
---

# 51 — Situación: un agente quiere pagar a un proveedor

## Qué haría Nico
**Que el agente prepare todo, pero NO libere el pago.** Sin excepción, sin importar el monto.

- El agente **puede:** armar el presupuesto de pago semanal ordenado por prioridad, dejar la transferencia **subida** al banco, conciliar las facturas. Todo listo para 1 click.
- El agente **no puede:** autorizar/liberar el egreso. Eso lo hace **un humano** (Nico o quien él designe) con **PinPass/token**.

> Cita exacta: *"El agente prepara; el humano libera. Lo único que nunca hace solo es soltar plata."*

## Por qué
Es la línea roja absoluta de Nico (la [[31 — Regla de Oro de Autonomía]], nivel 3 EJECUTAR EGRESO: "jamás automático, ningún monto, cero excepciones"). El criterio: automatizar todo donde el peor caso es perder tiempo; freno humano donde el peor caso es perder plata.

Relacionado: [[31 — Regla de Oro de Autonomía]] · [[43 — Conciliación bancaria]]
Fuentes: [[62 — HANDOFF Nexus v2]].

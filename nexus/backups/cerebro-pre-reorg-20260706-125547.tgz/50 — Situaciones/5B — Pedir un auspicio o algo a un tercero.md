---
tags: [situacion, esencia, comercial, marketing]
actualizado: 2026-06-13
---

# 5B — Situación: pedir un auspicio o algo a un tercero

## Qué haría Nico
**Generar tracción y valor visible PRIMERO; pedir después, con métricas en mano.** Nunca el correo en frío sin nada que mostrar.

## Caso real (auspicio Martini Racing)
Plan en 3 fases:
1. **Que ellos te encuentren:** contenido orgánico visible (videos del GT4/Cayenne con livery Martini) antes de pedir nada.
2. Alcanzar **15-20k seguidores** en IG con foco en esos autos.
3. Recién entonces **contactar al Brand Manager de Bacardi LatAm** con métricas reales.

> Regla textual: *"No escribir email frío sin tracción previa."*

## Por qué *(patrón de su criterio)*
Prefiere negociar desde una posición de fuerza demostrada. El valor primero, la pedida después — igual que con clientes (demostrar la propuesta integrada IMPOMIN+HN antes de cotizar).

Relacionado: [[24 — MALLORCAUTOS]] · [[12 — Dimensión personal]]
Fuentes: [[68 — Tablero GM (dashboard_gm.jsx)]].

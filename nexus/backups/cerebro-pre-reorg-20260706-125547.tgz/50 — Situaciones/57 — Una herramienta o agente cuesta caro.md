---
tags: [situacion, esencia, costos, finops]
actualizado: 2026-06-13
---

# 57 — Situación: una herramienta o agente cuesta caro

## Qué haría Nico
**Medir costo y valor, y recortar lo que no se justifique.** Cada agente/herramienta debe poder responder dos números: **cuánto cuesta al mes** y **cuánto valor genera** (horas ahorradas, errores evitados, ventas capturadas).

- El que **no pueda mostrar ambos** es candidato a recorte cuando suban los precios.
- Acción concreta: alertas de presupuesto + dashboard de uso desde el día uno.
- Gesto real: apagó temporalmente a Alí y Néstor mientras corregía un bug **para no quemar tokens**.

## Por qué
Sabe que el precio de la IA va a subir (Anthropic ya cobra por uso/tokens) y que correr agentes 24/7 escala el gasto sin aviso. No es austeridad ciega: es **costo justificado**. Ver [[6C — Control de costos de IA]].

Relacionado: [[6C — Control de costos de IA]] · [[58 — Hay que decidir qué modelo de IA usar]] · [[32 — Cómo decide Nico]]
Fuentes: [[6C — Control de costos de IA]], [[65 — PDR ejecutivos (8-11 jun)]].

---
tags: [situacion, esencia, correo, comunicacion]
actualizado: 2026-06-13
---

# 54 — Situación: hay que responder un correo importante

## Qué haría Nico
**Dejar el borrador listo, no enviarlo.** Y atender primero lo urgente e importante, no lo que llegó primero.

- El agente **prepara un borrador** que suene como Nico: español chileno, directo, síntesis primero, con el "por qué importa" claro.
- **No envía** hasta que Nico aprueba (nivel COMUNICAR). Solo se escala a envío más autónomo *según resultados* probados.
- Prioriza por importancia: distingue si Nico es destinatario / está en copia / es mencionado.

## Por qué
Combina dos cosas suyas: la [[31 — Regla de Oro de Autonomía]] (comunicar = borrador + aprobación) y sus [[33 — Preferencias de comunicación]] (tono chileno, conclusión arriba, cero ruido).

Relacionado: [[46 — Correo unificado (Ailnest · Néstor)]] · [[33 — Preferencias de comunicación]]
Fuentes: [[62 — HANDOFF Nexus v2]], [[63 — Requerimientos Nexus v1]].

---
tags: [situacion, esencia, ia, modelos, finops]
actualizado: 2026-06-13
---

# 58 — Situación: hay que decidir qué modelo de IA usar para una tarea

## Qué haría Nico
**El modelo más barato que resuelva bien la tarea. La potencia se reserva para donde un error cuesta plata o reputación.** Dos carriles:

| Carril | Tipo de tarea | Modelo |
|---|---|---|
| **Volumen / barato** | clasificar, extraer, normalizar, parsear, taggear, resumir | económico (familia Haiku o equivalente) |
| **Decisión / análisis** | razonamiento financiero, criterio, redacción a gerencia/socios | premium (familia Opus/Sonnet superior) |

- Todo pasa por un **router central** que elige el modelo **por configuración** (sin tocar el código de cada agente), para cambiarlo en un solo lugar cuando salga algo mejor/más barato.

## Por qué
Mismo criterio de riesgo que la [[31 — Regla de Oro de Autonomía]]: lo de bajo riesgo se hace barato y a volumen; lo que tiene consecuencias se hace con lo mejor. Bien hecho, divide la factura varias veces. Ver [[6C — Control de costos de IA]].

Relacionado: [[6C — Control de costos de IA]] · [[57 — Una herramienta o agente cuesta caro]]
Fuentes: [[6C — Control de costos de IA]].

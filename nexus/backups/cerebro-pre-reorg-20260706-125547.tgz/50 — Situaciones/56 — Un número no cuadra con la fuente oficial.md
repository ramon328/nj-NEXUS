---
tags: [situacion, esencia, datos, criterio]
actualizado: 2026-06-13
---

# 56 — Situación: un número no cuadra con la fuente oficial

## Qué haría Nico
**Parar todo y arreglar el dato antes de seguir.** No construir nada encima de una cifra que no cuadra "al peso" con la fuente oficial.

- Verificar el estado real → buscar la **causa raíz** (no parchar) → cuadrar contra la fuente oficial (ej. Power BI en ALIACE) → comprobar en vivo.
- Un agente que muestra cifras debe **decir la misma cifra que el panel oficial** y **explicar de dónde sale cada número**.

## Caso real
La prioridad #1 con [[42 — Alí]] no fue agregar funciones, sino lograr **paridad con el dato oficial** (que Alí diga lo mismo que el dashboard). Cuando ALIACE mostró ventas duplicadas entre fuentes, se corrigió hasta que calzó exacto.

## Por qué
Su lema: *"primero que el dato sea verdad, después lo demás."* Un dato falso contamina todas las decisiones que vengan después. Ver [[32 — Cómo decide Nico]].

Relacionado: [[32 — Cómo decide Nico]] · [[42 — Alí]] · [[49 — Comité comercial ALIACE]]
Fuentes: [[65 — PDR ejecutivos (8-11 jun)]].

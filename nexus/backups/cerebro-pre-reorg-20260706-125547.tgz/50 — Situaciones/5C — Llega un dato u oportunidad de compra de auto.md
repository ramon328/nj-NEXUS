---
tags: [situacion, esencia, autos, compras]
actualizado: 2026-06-13
---

# 5C — Situación: aparece una oportunidad de compra de un auto

## Qué haría Nico
**Que el agente la detecte, la evalúe con criterio de mercado y se la avise — la compra la decide él.**

- El agente **monitorea** los portales (nivel LEER) y marca la oportunidad por **descuento vs. mercado, liquidez del modelo y vendedor motivado** (excelente / buena / moderada).
- **Notifica** con foto y datos; puede **contactar la unidad a pedido** (nivel COMUNICAR, no compra).
- La **decisión de compra** (un egreso) la toma Nico — coherente con la línea roja de gastar. Ver [[51 — Un agente quiere pagar a un proveedor]].

## Por qué
En [[24 — MALLORCAUTOS]] el 90% del negocio es comprar bien. Detectar la oportunidad rápido es donde está el margen; pero soltar la plata sigue siendo decisión humana. Ver [[47 — Sourcing de autos (Autos Intel)]].

Relacionado: [[47 — Sourcing de autos (Autos Intel)]] · [[24 — MALLORCAUTOS]] · [[31 — Regla de Oro de Autonomía]]
Fuentes: [[65 — PDR ejecutivos (8-11 jun)]], [[68 — Tablero GM (dashboard_gm.jsx)]].

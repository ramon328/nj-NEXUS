---
tags: [situaciones, esencia, moc]
actualizado: 2026-06-13
---

# 50 — Situaciones · "¿Qué haría Nico si…?"

> Esta es la parte que captura **la esencia de Nico ante diferentes situaciones**. Cada nota dice: *ante X, Nico decidiría/haría Y* — derivado de sus principios y de los casos reales en los documentos. Lo que está marcado **(inferido)** es deducción a partir de su criterio, no una cita textual.

## Dinero y pagos
- [[51 — Un agente quiere pagar a un proveedor]]
- [[52 — Hay que decidir comprar una herramienta o construirla]]
- [[57 — Una herramienta o agente cuesta caro]]

## Comunicación y personas
- [[53 — Conflicto detectado entre terceros]]
- [[54 — Hay que responder un correo importante]]
- [[5A — Un vendedor no llega a su meta]]
- [[5B — Pedir un auspicio o algo a un tercero]]

## Gobierno y socios
- [[55 — Activo personal vs activo de empresa con socios]]
- [[56 — Un número no cuadra con la fuente oficial]]

## Operación y producto
- [[58 — Hay que decidir qué modelo de IA usar]]
- [[59 — Hay que lanzar algo y no está perfecto]]
- [[5C — Llega un dato u oportunidad de compra de auto]]

Relacionado: [[31 — Regla de Oro de Autonomía]] · [[32 — Cómo decide Nico]] · [[34 — Cómo querría que un agente actúe en su nombre]]

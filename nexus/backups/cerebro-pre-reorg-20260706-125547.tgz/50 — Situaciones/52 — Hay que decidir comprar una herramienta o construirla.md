---
tags: [situacion, esencia, build-vs-buy, decisiones]
actualizado: 2026-06-13
---

# 52 — Situación: comprar una herramienta o construirla (build vs buy)

## Qué haría Nico
**No apostar a una sola opción. Avanzar las dos en paralelo y decidir con datos del trial.**

- **Opción inmediata (comprar/agregador):** para no quedarse parado, arranca ya con una solución pagada.
- **Opción definitiva (construir/soberana):** en paralelo, levanta la versión propia que da más control y menos costo recurrente.
- Se prueban ambas (usando capas gratis/trials cuando existen) y se elige con resultados reales, no con supuestos.

## Caso real
Captura SII: contrató/probó **ApiPyme** (inmediato, ~1,5 UF/mes) **y** levantó **LibreDTE** autohospedado (definitivo, ~$0) al mismo tiempo. Ver [[45 — Captura SII]].
Banco: usa **Rail** pero deja **Fintoc** como respaldo, y el código soporta ambos sin cambios.

## Por qué
Reduce el riesgo de quedarse bloqueado y de casarse con un proveedor inmaduro. Valora la **soberanía** (no entregar credenciales sensibles a terceros) pero no a costa de frenar el avance. Ver [[32 — Cómo decide Nico]].

Relacionado: [[45 — Captura SII]] · [[57 — Una herramienta o agente cuesta caro]]
Fuentes: [[69 — Handoff captura SII]], [[62 — HANDOFF Nexus v2]].

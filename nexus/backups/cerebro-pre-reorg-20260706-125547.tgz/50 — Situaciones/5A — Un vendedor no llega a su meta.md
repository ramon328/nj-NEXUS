---
tags: [situacion, esencia, comercial, ventas]
actualizado: 2026-06-13
---

# 5A — Situación: un vendedor no llega a su meta

## Qué haría Nico
**Que el agente lo detecte temprano, prepare el seguimiento y se lo proponga — pero sin contactar al vendedor solo.**

- El agente **monitorea** ventas vs. meta (nivel LEER: libre) y avisa quién está bajo meta.
- Prepara un **borrador de mensaje/llamado** de seguimiento (nivel COMUNICAR: borrador + aprobación). Solo se escala a contacto directo según resultados.
- Mira más allá del número: a Nico le importa el **valor de cliente y la relación**, no solo el volumen — el dolor de ALIACE es justamente que los vendedores solo hablan de precio.

## Por qué
Combina su regla de autonomía con su diagnóstico comercial de [[21 — ALIACE]]: profesionalizar la venta, medir "valor cliente" y no commoditizar la marca. Ver [[49 — Comité comercial ALIACE]].

Relacionado: [[21 — ALIACE]] · [[49 — Comité comercial ALIACE]] · [[42 — Alí]]
Fuentes: [[61 — HANDOFF Nexus v1]], [[62 — HANDOFF Nexus v2]].

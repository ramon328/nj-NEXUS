---
tags: [empresa, mallorcautos, autos]
actualizado: 2026-06-13
---

# 24 — MALLORCAUTOS

- **Sector:** compra-venta de **autos usados** + **motorsport** / marca premium.
- **Web:** www.mallorcautos.cl
- **Rol de Nico:** Director / Socio · ~5 personas.
- Es la empresa que conecta directo con su [[12 — Dimensión personal|pasión por los autos]].

## Ficha formal (datos verificados · jun 2026)
- **Dominio mallorcautos.cl registrado por:** IMPORTADORA JURI Y FONTENA ASOCIADOS LTDA (WHOIS NIC Chile), creado 02-05-2022.
- **Instagram:** @mallorcautos (~5.600 seguidores).
- *RUT y dirección física por verificar: directorios apuntan a Camino Los Trapenses 2140, Lo Barnechea, y al RUT 76.106.636-6 (en conflicto con [[23 — HN]]) — confirmar en SII.*

## Cómo funciona el negocio
- **El 90% del negocio es la COMPRA** (el sourcing). Comprar bien es donde está el margen.
- Hoy la búsqueda es manual (chileautos.cl). Por eso el proyecto [[47 — Sourcing de autos (Autos Intel)]]: scraper + filtros + alertas de oportunidades.

## Posicionamiento de marca
- Narrativa: **"Mallorcautos no vende autos, cura autos para personas que entienden la diferencia."**
- Stock multi-segmento ($10M–$200M), con *top of mind* de lujo ya establecido.
- **Estrategia "unicornios":** autos de culto que generan contenido y tráfico (americano clásico tipo Caprice, japonés de culto EK Type R / Supra MK4 / NSX / R34, alemán de lujo).

## Activos publicitarios / motorsport
- **Porsche GT4 981** con *livery* Martini (el que Nico corre en TC Chile).
- Cayenne S safari *livery* Martini (publicitario).
- F150 Lightning 1999 original.
- **Plan de auspicio Martini Racing (3 fases):** generar tracción orgánica primero → 15-20k seguidores IG → recién ahí contactar a Bacardi LatAm. *No escribir email frío sin tracción previa.*

## Plataforma de inteligencia (capital de autos)
- `mallorcautos-platform`: base de ~6.780–11.738 listings (ChileAutos + Yapo), clustering por segmento, "Oportunidades" marcadas por IA (descuento vs. mercado, liquidez del modelo, vendedor motivado). Vinculado a [[25 — ACE SpA]] (GoAuto).

Relacionado: [[47 — Sourcing de autos (Autos Intel)]] · [[25 — ACE SpA]] · [[12 — Dimensión personal]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[68 — Tablero GM (dashboard_gm.jsx)]], [[65 — PDR ejecutivos (8-11 jun)]].

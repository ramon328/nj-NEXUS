---
tags: [empresa, ace, tecnologia]
actualizado: 2026-06-13
---

# 25 — ACE SpA

- **Sector:** tecnología. Productos/marcas: **GoAuto** (Plataformas Digitales GoAuto SpA, RUT 78.226.167-3), **GetNexor.ai**, consultoría.
- **Rol de Nico:** Director / Socio · ~10 personas.

> ⚠️ **Por verificar (jun 2026):** la razón social y RUT de ACE SpA, el RUT de GoAuto (78.226.167-3) y la atribución de **GetNexor.ai** al grupo no se pudieron confirmar en fuentes públicas. Confirmar con Nico antes de darlos por ciertos.

## Por qué es estratégica
- Es la **pata tecnológica** del grupo. Es la vía natural para que los desarrollos (agentes, plataformas, [[41 — Nexus]]) vivan como **activo de una empresa tech** y no mezclados con marca personal.
- **GoAuto** se relaciona con la inteligencia de autos usados (ver [[47 — Sourcing de autos (Autos Intel)]] y [[24 — MALLORCAUTOS]]).

## Punto de gobierno importante
- Hay un riesgo señalado en los documentos: se están guardando bajo **marca personal** (dominios `nicojuri.com` / `nicojuri.ai`) desarrollos que en realidad pertenecen a **empresas con socios**.
- Recomendación recogida: documentar desde el inicio qué es activo personal (vía ACE/tech) y qué pertenece a cada empresa, para no discutirlo después. Ver [[35 — Gobierno de activos personales vs empresa]].

Relacionado: [[35 — Gobierno de activos personales vs empresa]] · [[41 — Nexus]] · [[24 — MALLORCAUTOS]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[62 — HANDOFF Nexus v2]], [[68 — Tablero GM (dashboard_gm.jsx)]].

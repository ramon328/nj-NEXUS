---
tags: [empresa, food-expert]
actualizado: 2026-06-13
---

# 26 — Food Expert SpA

- **Sector:** alimentos — venta al por menor en comercios especializados (giro SII 472101); distribuye marcas de [[21 — ALIACE]] (Maxi Canoil / Maxi Frits).
- **Rol de Nico:** Socio Director · ~3 personas (la más pequeña en dotación).

## Ficha formal (datos verificados · jun 2026)
- **Razón social:** FOOD EXPERT SpA.
- **RUT:** 76.580.812-K.
- **Giro:** 472101 — venta al por menor de alimentos en comercios especializados.
- **Dirección:** Carretera General San Martín 9340, Galpón 6, **Quilicura**, RM (mismo polígono que [[21 — ALIACE]]).
- **Constitución:** escritura 24/06/2016; inicio de actividades SII 11/07/2016.
- **Web / contacto:** foodexpert.cl · administracion@f-e.cl · ventas mayoristas acaballero@f-e.cl.
- **Socios (extracto Diario Oficial, modif. 07-08-2025):**
	- Nicolás Patricio Juri Caballero — RUT 16.142.580-K.
	- Luis Patricio Juri Campos — RUT 7.067.159-K.
	- Gonzalo Sebastián Juri Caballero — RUT 15.097.786-K.
	- Sociedad Inversiones del Mar Ltda — RUT 76.237.496-K.
	- Agronegocios y Alimentos del Sur Ltda — RUT 76.758.090-8 *(salió de la sociedad el 07-08-2025)*.

> Esta ficha **confirma vía registro primario** la pertenencia al grupo Juri: aparecen los tres Juri (Nicolás, su padre Luis y su hermano Gonzalo) y sociedades de inversión que también son socias de [[21 — ALIACE]].

## Lo que sí consta en las fuentes
- Es una de las **5 empresas** que entran al alcance de la visibilidad financiera, la captura SII y las comisiones automáticas.
- Sus **comisiones son 100% manuales** hoy → en la lista de empresas a automatizar (ver [[44 — Comisiones automáticas]]).
- Apareció como una de las primeras candidatas para el **MVP financiero** junto con [[23 — HN]].

> El resto de los datos (productos, clientes, dolores específicos) **no está en las fuentes**. Pendiente de completar con Nico.

Relacionado: [[44 — Comisiones automáticas]] · [[20 — Empresas (mapa)]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[69 — Handoff captura SII]].

---
tags: [empresa, impomin]
actualizado: 2026-06-13
---

# 22 — IMPOMIN

- **Sector:** distribución mayorista / e-commerce importador de **equipamiento de seguridad minero, vial y vehicular** (Quilicura).
- **Web:** www.impomin.cl
- **Rol de Nico:** Director / Socio · ~8 personas.
- **Empresa hermana:** [[23 — HN]] (fabrica barras antivuelco, jaulas y pértigas certificadas INN-WSS-MEL).

## Ficha formal (datos verificados · jun 2026)
- **Dirección:** Av. Caupolicán 9291, Galpón D, **Quilicura**, RM.
- **Teléfono:** +56 2 3251 3446 · **WhatsApp:** +56 9 5622 8001 / +56 9 9841 1752.
- **Emails:** ventas@impomin.cl · asistente@impomin.cl.
- **Giro:** importación y venta de equipamiento de seguridad minero, vial y vehicular.
- *RUT y razón social legal pendientes de confirmar (el sitio se rotula "Impomin SPA"; no aparece RUT público).*

## El activo único (y el dolor de comunicarlo)
- **IMPOMIN + HN** = catálogo importado + fabricación metalmecánica + instalación, bajo una sola gestión. **Ningún competidor combina los tres.**
- **Problema:** al cliente le llegan como negocios separados → se pierden licitaciones contra quienes sí ofrecen propuesta integrada (Socadin, Escapes Mendoza, Equipa Chile).

## Prioridades estratégicas
1. **Visibilizar propuesta integrada IMPOMIN + HN** (web, cotización integrada, speech comercial).
2. **Entrada al norte minero** (Antofagasta como hub recomendado ★★★★★, plan a 12 meses).
3. **SEO técnico por modelo de camioneta + estándar minero** (ej. "kit minero Hilux 2024 MEL") — Equipa Chile rankea arriba por tener páginas por modelo.
4. **Programa B2B 30/60 días:** existe pero no está en la web → se pierden contratistas medianos.
5. **Marca propia económica** para competir en el segmento commodity (Tier 3).

## Otros dolores
- **Inventario volátil:** demanda errática (quiebres de stock vs. sobrestock). Solución: proyección de demanda + alertas de reorden + turnover por SKU.
- Comisiones (ver [[44 — Comisiones automáticas]]).

## Inteligencia de competencia
Dashboard que compara IMPOMIN vs. competidores producto a producto. Ver [[48 — Inteligencia de competencia (Rival Watch)]].

Mapa competitivo levantado: Tier 1 (Socadin/Grupo Atlas, Escapes Mendoza, Start Fire), Tier 2 norte (Equipa Chile, SafeTruck, Mineral Equip, Alessandrini), Tier 3 (Implementos, Sodimac, MercadoLibre).

Relacionado: [[23 — HN]] · [[48 — Inteligencia de competencia (Rival Watch)]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[64 — Handoff web IMPOMIN]], [[67 — Reporte de avances (3 jun)]], [[68 — Tablero GM (dashboard_gm.jsx)]].

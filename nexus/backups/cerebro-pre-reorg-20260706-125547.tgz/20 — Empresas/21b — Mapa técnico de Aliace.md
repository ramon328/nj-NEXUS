---
titulo: Mapa técnico de Aliace
tipo: documentacion-tecnica
empresa: Aliace
portal: https://admin.aliace.cl
repo: /Users/AIagenteia/Documents/GitHub/aliace
stack: Vite + React 18 + TypeScript + shadcn/ui + Supabase
supabase_project_id: mdrvhekhimhcwydrpueo
fecha: 2026-06-13
tags: [aliace, supabase, portal, mapa-tecnico, nexus]
---

# Mapa técnico de Aliace

Plataforma B2B de ventas y cobranzas para una distribuidora chilena. Cubre el flujo completo: notas de venta, facturas, guías de despacho, pagos, cobranza, compras, bodega (WMS), producción, maquila, tótems y contabilidad.

> Guía operativa gemela (para que el agente de Nexus navegue y extraiga datos):
> `/Users/AIagenteia/nexus/conector-navegador/guias/aliace.md`

## Arquitectura general

- **Frontend**: React 18 + TypeScript + Vite. UI con shadcn/ui + Tailwind. Estado con Zustand (`profileStore`) + TanStack Query (react-query).
- **Backend**: Supabase (Postgres + Auth + Edge Functions + Realtime). Project ID `mdrvhekhimhcwydrpueo`.
- **Servicios externos**: BSale (facturación), Fintoc (banca), PostHog (analytics), Sentry (errores).
- **Routing** (2 archivos que hay que mantener sincronizados):
  - `src/components/AppRoutes.tsx` — declara los `<Route path=...>` (lista de URLs).
  - `src/components/routing/RouteRenderer.tsx` — `switch` que mapea cada path → componente de página y aplica permisos por rol.
- **Auth/roles**: `App.tsx` valida sesión → `ProfileProvider` carga perfil → `RoleBasedRouter` renderiza según rol. Roles: `superadmin`, `admin`, `seller`, `cobranza`, `facturacion`, `logistica`, `bodega`, `risk`, `transportista`, `production`, `produccion-admin`.
- **Realtime**: suscripciones live en `sales_request`, `sales_request_items`, `clients`.
- **SPA**: todas las URLs son client-side (React Router). Al navegar directo a una URL, la app monta, valida sesión, y recién entonces dispara los fetch → **hay que esperar a que la tabla cargue antes de leer**.

### Patrón de carga (CLAVE para extracción)

Casi todas las páginas siguen el patrón: hook react-query con `isLoading`/`loading` → mientras carga muestra `Skeleton`, spinner `Loader2`, o texto "Cargando...". Cuando termina, renderiza una `<Table>` shadcn (`<table>` HTML real con `<thead>`/`<tbody>`). **Señal fiable de "datos cargados": que aparezcan filas en `table tbody tr` y/o que desaparezca el texto "Cargando".** Varias vistas son Kanban o cards en vez de tabla.

## Tabla de rutas (URL → vista → datos → tabla Supabase)

Base de todas las URLs: `https://admin.aliace.cl`

| Ruta | Vista / componente | Qué datos | Tabla(s) Supabase |
|---|---|---|---|
| `/` | Dashboard según rol (SuperAdminDashboard / redirección) | KPIs generales | varias |
| `/login` | Login | — | auth |
| `/clients` | ClientsPage | Listado de clientes (RUT, vendedor, condición de venta, canal) | `clients`, `profiles`, `sales_conditions`, `addresses` |
| `/clients/:clientId` | ClientDetailPage | Detalle de un cliente, direcciones, deuda | `clients`, `addresses`, `sales_request`, `payments` |
| `/sales-notes` | SalesNotesPage | **Notas de venta** (Kanban o tabla). Estado, pago, factura | `sales_request`, `sales_request_items`, `sales_request_documents`, `payments` |
| `/facturas` | redirige a `/facturas/visualizar` | — | — |
| `/facturas/visualizar` | FacturasPage | **Facturas** con pagos asociados, estadísticas | `sales_request_documents` (document_type='factura'), `payments`, `sales_request` |
| `/facturas/bsale` | BSaleFacturasPage | Documentos directos desde **BSale** (DTE, estado SII, PDF) | API BSale + `sales_request_documents` |
| `/facturas/cuentas-por-cobrar` | CuentasPorCobrarPage | **Cuentas por cobrar** de facturas manuales | `manual_facturas`, `payments` |
| `/facturas/analisis-periodos` | análisis de períodos de facturas | snapshots mensuales | `monthly_facturas_snapshots` |
| `/deudas` | DeudasPage | **Deudas por cliente** a fecha de corte (vencida/por vencer/sana) | RPC `get_*_debt_at_cutoff_fixed`, `daily_debt_summary`, `daily_client_debt_details` |
| `/daily-debt-snapshots` | DailyDebtSnapshotsPage | Snapshots diarios de deuda | `daily_debt_records`, `daily_debt_summary` |
| `/daily-debt-snapshots/client/:id` | ClientDebtHistoryPage | Historial de deuda de un cliente | `daily_client_debt_details` |
| `/debt-reminders` | DebtRemindersPage | Recordatorios de cobranza | `sales_request_documents`, `payments` |
| `/late-payments` | LatePaymentManagementPage | **Pagos atrasados** + intereses | `sales_request`, `manual_facturas`, `payments`, `payment_config` |
| `/payments-summary` | PaymentsSummaryPage | **Resumen de pagos** (rango de fechas, método, banco, export) | `payments` |
| `/payments-overview` | SuperAdminDashboard | Vista global de pagos (solo superadmin) | varias |
| `/payment-dashboard` | PaymentDashboard | Tablero de cobranza (cobranza) — usa mock data parcial | `payments`, mock |
| `/payment-requests` | PaymentRequests | Solicitudes de pago (Kanban) — mock data | mock |
| `/unidentified-payments` | UnidentifiedPaymentsPage | **Pagos no identificados** para asignar a clientes | `payments`, `sales_request` |
| `/manual-payments` | ManualPaymentsPage | Formulario de registro de pago manual | `payments` |
| `/cheques` | ChequesPage | **Cheques** (estado, fechas cobro/depósito) | `payments` (check_status), `sales_request_documents` |
| `/config-payments` | ConfigPayments | Configuración de pagos | `payment_config` |
| `/admin-settings` | AdminSettings | Ajustes admin | varias |
| `/products` | ProductsDashboard | Catálogo de productos | `products`, `active_products` |
| `/unit-costs` | UnitCostsPage | Costos unitarios | `unit_costs` |
| `/exchange-rates` | ExchangeRatesPage | Tipos de cambio | `exchange_rates` |
| `/client-risk-management` | ClientRiskManagementPage | Gestión de riesgo de clientes | `clients` (risk) |
| `/commercial-team` | CommercialTeamPage | Equipo comercial | `profiles` |
| `/vendedores` | Vendedores | Vendedores | `profiles` |
| `/seller/:id` | SellerDetail | Detalle de vendedor | `profiles`, `sales_request` |
| `/sales-conditions` | SalesConditionsPage | Condiciones de venta | `sales_conditions` |
| `/monthly-snapshots` | MonthlySnapshotsManagement | Snapshots mensuales | `monthly_facturas_snapshots` |
| `/metas-de-venta` | SalesGoalsDashboard | **Metas de venta** (por vendedor / cliente / canal) | RPC `get_sales_goals_vs_actual`, `get_sales_without_goals` |
| `/ventas/clientes-dashboard` | ClientSalesDashboardPage | Dashboard de ventas por cliente | `sales_request`, `clients` |
| `/guias-despacho` | GuiasDespachoPage | Guías de despacho | `sales_request_documents` (guia), `sales_request`, `clients` |
| `/despachos` | OperationsOrdersPage | Órdenes de operaciones / despacho (logística) | `sales_request`, `sales_request_documents`, `clients` |
| `/cotizaciones` | CotizacionesPage | Cotizaciones (legacy) | `contact_attempts`, `quotations` |
| `/cotizaciones/:id` | CotizacionDetailPage | Detalle cotización | `quotations` |
| `/quotations` | PresupuestosPage | **Presupuestos / cotizaciones** (nuevo) | `quotations` |
| `/quotations/:id` | PresupuestoDetailPage | Detalle de presupuesto | `quotations` |
| `/purchasing/orders` | PurchaseOrdersPage | **Órdenes de compra** (filtros estado/tipo/proveedor) | `purchase_orders`, `purchase_order_items`, `suppliers` |
| `/purchasing/orders/new` | NewPurchaseOrderPage | Crear OC | `purchase_orders` |
| `/purchasing/orders/:id` | PurchaseOrderDetailPage | Detalle OC | `purchase_orders`, `purchase_order_items` |
| `/purchasing/suppliers` | SuppliersPage | **Proveedores** | `suppliers` |
| `/purchasing/stock` | IngredientStockPage | **Stock de ingredientes** (aceites / materias primas) | `oil_types`, `raw_materials`, `oil_type_stock_by_plant`, `raw_material_stock_by_plant` |
| `/production/recipes` | RecipesPage | Recetas / SKU | `sku_recipes`, `recipe_ingredients` |
| `/production/assembly-lines` | AssemblyLinesPage | Líneas de ensamblaje | producción |
| `/production/batches` | ProductionBatchesPage | Lotes de producción | `production_batches`, `production_batch_ingredients` |
| `/production/batches/:id` | ProductionBatchDetailPage | Detalle de lote | `production_batches` |
| `/wms` | WmsLandingPage | **Bodega** — landing con accesos (Ingreso, Picking, Stock, etc.) | — (navegación) |
| `/wms/ubicaciones` | AllLocationsPage | Ubicaciones / grilla de inventario por bodega | `wms_warehouses`, `wms_hallways`, `wms_racks`, `wms_positions`, `wms_inventory` |
| `/wms/locations` | LocationsPage | Bodegas | `wms_warehouses` |
| `/wms/stock-consultation` | StockConsultationPage | **Consulta de stock** (buscar por SKU/lote/posición) | `wms_inventory`, `wms_pallets`, `wms_positions` |
| `/wms/consolidated-stock` | ConsolidatedStockPage | **Stock consolidado** (productos/insumos por planta) | `wms_inventory`, `oil_types`, `raw_materials`, `products` |
| `/wms/pallets` | PalletsPage | Pallets | `wms_pallets`, `wms_pallet_batches` |
| `/wms/picking-orders` | PickingOrdersPage | Pedidos de picking | `wms_pick_tasks`, `wms_pick_task_items` |
| `/wms/returns` | ReturnsPage | Devoluciones | `wms_return_requests`, `wms_return_request_items` |
| `/wms/ingestion` | IngestionWorkflowPage | Ingreso de mercadería (móvil) | `wms_ingestion_requests` |
| `/wms/movements` | MovementsPage | Movimientos de bodega (solo superadmin) | `wms_movements` |
| `/wms/adjustments` | StockAdjustmentsPage | Ajustes de stock | `wms_stock_adjustments` |
| `/wms/transicion` | TransicionPage | Pallets en transición (no ingresados) | `wms_pallets` |
| `/maquila` | MaquilaLandingPage | Maquila (landing) | — |
| `/maquila/inventory` | MaquilaInventoryPage | Inventario de maquila | `maquila_items` |
| `/maquila/movements` | MaquilaMovementsPage | Movimientos de maquila | maquila |
| `/maquila/items` | MaquilaItemsPage | Ítems de maquila | `maquila_items` |
| `/maquila/clients` | MaquilaClientsPage | Clientes de maquila | maquila |
| `/totems` | TotemsPage | Tótems | `totems`, `totem_pickup_orders`, `totem_pickup_order_items` |
| `/totems/cleaning` | CleaningQueuePage | Cola de limpieza de tótems | `totem_cleaning_queue` |
| `/totems/:id` | TotemDetailPage | Detalle de tótem | `totems` |
| `/contabilidad/empresas` | EmpresasPage | Empresas contables | `company` |
| `/contabilidad/diarios` | DiariosPage | Diarios contables | `account_journal` |
| `/contabilidad/cuentas` | CuentasPage | **Plan de cuentas** | `account` |
| `/contabilidad/movimientos` | MovimientosPage | **Movimientos contables** (filtros empresa/diario/estado) | `account_movements`, `account_move_line` |
| `/contabilidad/reportes` | ReportesPage | Índice de reportes | — |
| `/contabilidad/reportes/libro-diario` | LibroDiarioPage | Libro diario | `account_move_line` |
| `/contabilidad/reportes/libro-mayor` | LibroMayorPage | Libro mayor | `account_move_line` |
| `/contabilidad/reportes/balance-8-columnas` | Balance8ColumnasPage | Balance 8 columnas | `account` |
| `/contabilidad/reportes/estado-situacion` | BalanceSheetPage | Balance / estado de situación | `account` |
| `/contabilidad/reportes/estado-resultados` | IncomeStatementPage | Estado de resultados | `account` |
| `/contabilidad/reportes/validacion-cxc` | ValidacionCxcPage | Validación cuentas por cobrar | varias |
| `/contabilidad/reportes/auditoria` | AuditLogPage | Log de auditoría | auditoría |
| `/contabilidad/configuracion` | ConfiguracionPage | Configuración contable | `account_classification_group` |
| `/contabilidad/configuracion/mapeo` | MapeoCuentasPage | Mapeo de cuentas | `account_mapping`, `account_mapping_template` |
| `/contabilidad/configuracion/grupos-cuenta` | GruposCuentaPage | Grupos de cuenta | `account_classification_group` |

**Total rutas mapeadas: ~95** (incluyendo subrutas y rutas con parámetros).

## Resumen por sección (qué se puede consultar)

### Pagos
- **Resumen de pagos** (`/payments-summary`): totales por rango de fecha, método, banco; gráfico de distribución; export Excel/BI. Tabla `payments`.
- **Pagos no identificados** (`/unidentified-payments`): pagos sin asignar a cliente; permite asignarlos.
- **Cheques** (`/cheques`): estado de cheques (en cartera, depositado, cobrado), fechas, búsqueda y filtros.
- **Pagos atrasados** (`/late-payments`): vencidos + intereses proporcionales, agrupados por tramo de atraso.
- **Pago manual** (`/manual-payments`): formulario de registro.

### Ventas / Notas de Venta
- **Notas de venta** (`/sales-notes`): vista Kanban por estado o tabla. Estado, estado de pago, factura asociada. Es la vista central del flujo.
- **Metas de venta** (`/metas-de-venta`): meta vs real por vendedor, por cliente y por canal (RPCs).
- **Dashboard de ventas por cliente** (`/ventas/clientes-dashboard`).

### Facturas
- **Facturas** (`/facturas/visualizar`): facturas con pagos, estadísticas, export.
- **BSale** (`/facturas/bsale`): DTEs directos de BSale con estado SII y PDF.
- **Cuentas por cobrar** (`/facturas/cuentas-por-cobrar`): facturas manuales pendientes.

### Clientes
- **Clientes** (`/clients`): listado completo (RUT, vendedor, condición de venta, canal). Búsqueda, filtro por vendedor, import/export Excel.
- **Detalle de cliente** (`/clients/:id`): direcciones, deuda, condiciones.

### Compras / Purchase Orders
- **Órdenes de compra** (`/purchasing/orders`): con filtros de estado/tipo/proveedor.
- **Proveedores** (`/purchasing/suppliers`).
- **Stock de ingredientes** (`/purchasing/stock`): aceites y materias primas por planta.

### Bodega / WMS
- **Consulta de stock** (`/wms/stock-consultation`): buscar por SKU/nombre/código de barras/lote/posición.
- **Stock consolidado** (`/wms/consolidated-stock`): productos/insumos por planta (P1/P2).
- **Ubicaciones** (`/wms/ubicaciones`): grilla de inventario por bodega.
- Pallets, picking, devoluciones, ingreso, movimientos, ajustes.

### Metas de venta
- `/metas-de-venta`: pestañas Por Vendedor / Por Vendedor-Cliente / Por Canal. Compara meta vs venta real del mes (RPC).

### Contabilidad
- Plan de cuentas (`/cuentas`), movimientos (`/movimientos`), diarios, empresas.
- Reportes: libro diario, libro mayor, balance 8 columnas, estado de situación, estado de resultados, validación CxC, auditoría.

### Deudas / Cobranza
- **Deudas** (`/deudas`): por cliente a fecha de corte; tabs vencida / por vencer / sana. Fórmula: `precio_con_iva - notas_de_credito - pagos_verificados`. Solo cuenta notas de venta con factura (bsale_number no nulo) en estados accepted/in_transit/delivered.
- Snapshots diarios de deuda y recordatorios de cobranza.

## Notas para extracción de datos
- La app es una **SPA**: navegar a la URL no garantiza que la tabla esté cargada. Esperar a que aparezcan filas (`table tbody tr`) o a que desaparezca "Cargando".
- Muchas vistas tienen **filtros y rango de fecha por defecto** (ej. PaymentsSummary arranca en "Este mes"). Ajustar filtros si se necesitan otros períodos.
- `/sales-notes` por defecto está en vista **Kanban** (cards, no tabla). Para tabla, cambiar `viewMode` a tabla en la UI.
- Algunas vistas (`/payment-dashboard`, `/payment-requests`) usan datos mock parciales — no son fuente confiable.
- Las tablas reales de origen están en Supabase (project `mdrvhekhimhcwydrpueo`); si se necesita extracción masiva/confiable, conviene consultar Supabase directo en vez de raspar el DOM.

---
tags: [empresa, aliace]
actualizado: 2026-06-13
---

# 21 — ALIACE

- **Sector:** aceites vegetales. Marca propia **Maxifrits**.
- **Web:** www.aliace.cl
- **Rol de Nico:** Director / Socio · ~15 personas.
- **Logística:** importa ~1.500 t/mes Argentina → Chile (procurement de aceite).

## Ficha formal (datos verificados · jun 2026)
- **Razón social:** ALIMENTOS Y ACEITES SpA.
- **RUT:** 76.505.808-2.
- **Giro:** elaboración de productos alimenticios NCP.
- **Comuna:** Quilicura, RM.
- *Nota: el dominio aliace.cl figura registrado a nombre de Felipe Lyon y la cara comercial pública es Eduardo Araos; el rol societario de Nico no consta en registros públicos.*

## Dolores / prioridades
- **Comportamiento comercial (dolor clave):** los vendedores venden por **precio y volumen**, no por relación ni valor de marca. *"¿Dónde está el valor de marca? Los vendedores solo hablan precio."*
  - Riesgo: commoditización de Maxifrits, márgenes comprimidos, pérdida de posicionamiento premium.
- **Comisiones manuales** (hay que automatizarlas — ver [[44 — Comisiones automáticas]]).
- **Visibilidad financiera** en tiempo real (transversal a todo el grupo).

## Lo que se está construyendo aquí (es el campo de pruebas)
ALIACE es donde nacen los prototipos que luego se replican:
- [[42 — Alí]] — agente GG de ALIACE conectado a Supabase (el prototipo replicable).
- [[49 — Comité comercial ALIACE]] — desempeño "en una hoja".
- Plataforma de clientes con acceso para vendedores; ventas ancladas a la **fuente oficial** (Power BI) — margen reportado 76,18% en el año.

## Procurement IA (proyecto avanzado, ~85%)
Modelo que recomienda cuándo comprar aceite (3 versiones en producción, 12 variables de mercado, cron 2x/día). Stack: Next.js + Supabase + Anthropic. Hit rate ~67,6%, ahorro ~USD 87/t.

Relacionado: [[42 — Alí]] · [[49 — Comité comercial ALIACE]] · [[44 — Comisiones automáticas]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[62 — HANDOFF Nexus v2]], [[65 — PDR ejecutivos (8-11 jun)]], [[68 — Tablero GM (dashboard_gm.jsx)]].

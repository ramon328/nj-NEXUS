---
tags: [empresas, moc]
actualizado: 2026-06-13
---

# 20 — Empresas (mapa)

Nico es Gerente General / socio-director de un grupo de empresas. Aquí el mapa rápido; cada una tiene su nota.

| Empresa | Sector | Web | Rol | Empleados (est.) |
|---|---|---|---|---|
| [[21 — ALIACE]] | Aceites vegetales (marca Maxifrits) | www.aliace.cl | Director/Socio | ~15 |
| [[22 — IMPOMIN]] | Distribución equipamiento minero/vial | www.impomin.cl | Director/Socio | ~8 |
| [[23 — HN]] | Seguridad de vehículos industriales (fábrica) | www.importhn.cl | Director/Socio | ~20 |
| [[24 — MALLORCAUTOS]] | Autos usados + motorsport | www.mallorcautos.cl | Director/Socio | ~5 |
| [[25 — ACE SpA]] | Tecnología (GoAuto, GetNexor.ai, consultoría) | — | Director/Socio | ~10 |
| [[26 — Food Expert SpA]] | Alimentos (?) | — | Socio Director | ~3 |
| [[27 — Ana Clara SpA e Inversiones Baleares]] | Holding / inversiones | — | Socio | — |

## Sinergias clave
- **IMPOMIN + HN** = activo único: catálogo importado + fabricación metalmecánica certificada + instalación, bajo una sola gestión. Hoy se comunica fragmentado (ver [[22 — IMPOMIN]]).
- **MALLORCAUTOS + ACE (GoAuto)** = autos usados + tecnología de inteligencia de autos (ver [[47 — Sourcing de autos (Autos Intel)]]).
- **Flujo intercompany Odoo:** IMPOMIN se abastece automáticamente desde la importadora HN.

## Datos societarios (RUT visibles en fuentes)
- 76.106.636-6 IMP JURI Y FONTENA ASOCIADOS
- 76.867.554-6 IMPORTACIONES MINERAS SPA
- 76.188.898-6 IMPORTADORA JURI Y JURI LIMITADA
- 77.271.121-2 ANA CLARA SPA
- 76.715.392-9 ACE SPA
- 78.226.167-3 PLATAFORMAS DIGITALES GOAUTO SPA
- RUT persona (representante): 16.978.152-4

> Las "5 empresas" que se repiten para finanzas/SII/comisiones son típicamente: ALIACE, IMPOMIN, HN, MALLORCAUTOS y FOOD EXPERT. El holding y las inversiones son la capa de gobierno (ver [[35 — Gobierno de activos personales vs empresa]]).

Fuentes: [[61 — HANDOFF Nexus v1]], [[68 — Tablero GM (dashboard_gm.jsx)]].

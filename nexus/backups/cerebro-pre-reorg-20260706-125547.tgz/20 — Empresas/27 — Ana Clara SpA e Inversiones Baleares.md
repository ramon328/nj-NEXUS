---
tags: [empresa, holding, inversiones]
actualizado: 2026-06-13
---

# 27 — Ana Clara SpA e Inversiones Baleares

Dos vehículos de la **capa de gobierno / patrimonio** del grupo (no operativos como las demás).

## Ana Clara SpA (RUT 77.271.121-2)
- **Rol:** holding. En las fuentes se menciona asociada a **reestructuración de deuda**.
- Nico figura como **Socio**.
- *(inferido)* El nombre combina los de dos de sus hijas (Ana Nicole y Clara) — coherente con que sea el vehículo familiar/patrimonial. Ver [[11 — Biografía y familia]].

### Ficha formal (datos verificados · jun 2026)
- **RUT verificado:** 77.271.121-2 (dígito verificador válido y concordante en registro).
- **Razón social:** ANA CLARA SPA · Sociedad por Acciones.
- **Giro:** venta de vehículos automotores nuevos/usados (451002) + fondos y sociedades de inversión (643000).
- **Dirección:** Caupolicán 9291, Lote 4, **Quilicura**, RM (mismo domicilio que [[22 — IMPOMIN]] / [[23 — HN]]).
- **Participación clave:** es accionista del **14,5% de [[21 — ALIACE]]** (Alimentos y Aceites SpA) — esto ancla su pertenencia al grupo.
- *Los registros públicos no nombran a Nico como socio de Ana Clara; el vínculo se confirma por domicilio compartido + participación en Aliace.*

## Inversiones Baleares
- **Rol:** inversiones. Nico figura como **Socio**.
- *(inferido)* El nombre remite a las Islas Baleares (Mallorca), de donde es la familia de su esposa Ana Palma — igual que [[24 — MALLORCAUTOS]].
- ⚠️ **No verificado (jun 2026):** en registros públicos chilenos las sociedades llamadas "Inversiones Baleares" (una SpA constituida 2022 de Inversiones Diezman; una S.A. de los años 90, RUT 96.652.030-2) **pertenecen a terceros**, sin vínculo con Juri. No se halló una "Inversiones Baleares" del grupo. Hay una "Inversiones Mallorca SpA" (RUT 77.546.068-7, Las Condes) temáticamente cercana pero tampoco confirmada. **Pendiente:** confirmar con Nico el nombre/RUT exacto del vehículo.

## Por qué importan para el cerebro
- Son la frontera entre lo **personal/familiar** y lo **operativo**. Cualquier agente que actúe sobre finanzas debe entender que aquí hay socios y patrimonio, no solo operación. Ver [[35 — Gobierno de activos personales vs empresa]].

Relacionado: [[35 — Gobierno de activos personales vs empresa]] · [[20 — Empresas (mapa)]]

Fuentes: [[61 — HANDOFF Nexus v1]].

---
tipo: indice
tags: [sii]
---

# 🧾 SII — Índice (Servicio de Impuestos Internos · Chile)

Accesos estándar del SII. Los mismos enlaces están en el Hub → sección **Enlaces**.

## Accesos principales
- **Mi SII (portal personal/empresa):** https://misiir.sii.cl/cgi_misii/siihome.cgi
- **Inicio SII:** https://www.sii.cl
- **Clave tributaria / login:** https://zeusr.sii.cl/AUT2000/InicioAutenticacion/IngresoRutClave.html

## Facturación electrónica
- **Factura electrónica (portal MIPYME):** https://www4.sii.cl/consdcvinternetui/
- **Emisión de documentos / sistema de facturación gratuito:** https://www4.sii.cl/dtepymeui/
- **Registro de Compras y Ventas (RCV):** https://www4.sii.cl/consdcvinternetui/

## Declaraciones y pagos
- **F29 (IVA mensual):** https://www4.sii.cl/propuestaf29ui/
- **F22 (Renta anual):** https://www4.sii.cl/declaracionesrentaui/
- **Pago de impuestos / boletas de pago:** https://www.sii.cl/servicios_online/

## Boletas
- **Boleta de honorarios electrónica:** https://www.sii.cl/servicios_online/1040-.html
- **Boleta de ventas y servicios electrónica:** https://www.sii.cl/servicios_online/1039-.html

## Consultas
- **Situación tributaria de terceros:** https://zeus.sii.cl/cvc_cgi/stc/getstc
- **Verificar DTE recibido:** https://www4.sii.cl/consultadterecibidosui/

---

## Procedimientos propios (rellena)

### Cómo presentar el F29 del mes
1.
2.

### Cómo descargar folios / CAF
1.
2.

> 💡 Cada vez que resuelvas un trámite, anótalo aquí como paso a paso. Eso entrena al agente.

---
tipo: plaud-resumen
tags: [plaud, resumen]
autor: plaud
fecha: 2026-06-19
---

# Conversación informal: Día de playa, compras y organización familiar

Speaker 1: Así nos dio solución vamos que ahora llegamos, nos vamos a esta zona vamos avanzando ahí van a jugar con el agua,
Speaker 2: La arena.
Speaker 2: What are you doing?
Speaker 1: La hora que.
Speaker 3: Es podría ser mucho Peor.
Speaker 4: Me gusta la sal.
Speaker 1: Gracias. Cuando hubiera otra sal.
Speaker 1: Me quedo en una hueva.
Speaker 1: Toda la vida. Una salsa aparte de la salsa? Pues bueno, que lo paga el poquito.
Speaker 2: La Selva donde yo vivo, cerca.
Speaker 1: Esto hay que bajarlo porque aquí no pasa nada.
Speaker 5: Yo no escondería, Si.
Speaker 1: No, porque bajo el asiento. Pásame la. Tu tablet clara. No, pero ponlo así po, mi amor. Para que no quede suelta.
Speaker 5: Pásame Tu tablet.
Speaker 1: Estamos al lado del señor, del guardia, y las voy a dejar escondidas ahí abajo hay es muy obvio vamos que las voy a poner debajo de la chombra que no se ve de afuera no se nota ahí de afuera no se va a notar.
Speaker 6: Claro.
Speaker 6: Pero qué? No sé.
Speaker 2: A mí.
Speaker 1: Tiene la.
Speaker 1: Clara.
Speaker 1: Tómalos bien, no de las Afuera.
Speaker 1: Porque La ley lo dice.
Speaker 6: No me lo cierra.
Speaker 6: Esta es una playa.
Speaker 6: Es una mezcla. Tierra mezclada con piedra.
Speaker 1: Y con arena ahí.
Speaker 1: Sí, porque como es muy blanco con el sol, pleno fuerte y duele la vista.
Speaker 6: Su gorra?
Speaker 1: Sí.
Speaker 1: Por quieres meterme brillos?
Speaker 6: Yo se conozco esto, casa.
Speaker 1: Wow, una sandidota. Para traer una sanditota.
Speaker 1: Melones, piñas, mango, vitaminas.
Speaker 1: Muy bien.
Speaker 1: Lones, mango, piña, vitaminas, sandía. Dedos de Clara, pensé que era más alto.
Speaker 1: Pensé que era más alto que yo, era más bajo. Esa es la verdad. Mira, lones, mango, vitaminas. Manzana, naranja, sombillas.
Speaker 1: Y de.
Speaker 6: Donde Clara.
Speaker 6: La sombrilla. Hola. Hay sombrilla?
Speaker 5: Que vuelven los viejos tiempos. Sí.
Speaker 7: Mira la sombrilla que me queda, la del medio 15 o a 20 la grande. La grande?
Speaker 5: La grande, una grande y con ese mecanismo.
Speaker 1: Con la cosa esa, mensual de 5 euros. Vale.
Speaker 1: Si, si llevas 60 y tú ¿Tú tienes? Sí, tengo 20 Ah, no, bueno, yo también,
Speaker 2: Ya vengo ¿Qué es esto?
Speaker 7: Aprovechan Denuncias Y si las pasamos por ahí se las cobro, ¿sabes? Y cada denuncia que nos meten aquí pues son de 1500 a ellos ¡Uf! Que si nos echan cuatro o cinco al mes Claro,
Speaker 1: Mejor quedarse en la casa.
Speaker 7: Nos prefiere uno no. No trabajada. Exacto. De esta manera pues te sirve. Esa está muy buena. Muy buena. Esta es la mejor que hay en todo el coso este ¿Vale?
Speaker 1: Certificada.
Speaker 7: Te lo juro ¿Eh? Esto es que mira tú esto que tienes Distinta.
Speaker 1: Ah vale. Un poco.
Speaker 7: El tacto de ese entonces no.
Speaker 3: Tiene nada. Entonces las.
Speaker 1: Que están así son paloguiris. Eso es para los que viven aquí y a otra cosa.
Speaker 7: Yo a lo mejor se lo doy a los míos y lo pego a los otros. Es más caro. Claro, no, por el mismo dinero. Pero cuánto vale esto? Pues eso tiene que valer fácilmente 25 o 26 pavos.
Speaker 1: No, No, pero ¿aquí cuánto cuesta eso y eso? Esto 25 euros. Y eso?
Speaker 7: Por esto.
Speaker 5: Que Nos tiene que bastar para la fruta.
Speaker 7: Mira la fruta, escucha, me dice que tu marido a mí me cobre bien, porque esa pega a palos puercas a los giros y sabe. Maike.
Speaker 5: Don Michael.
Speaker 7: Me ha dicho Maike que me cobre bien. Que si no te va a meter unos chalazos.
Speaker 5: Y Su señora que se llama?
Speaker 7: Loraira.
Speaker 7: Don Michael.
Speaker 1: Yo soy de Chile.
Speaker 1: Vivimos en Chile, pero venimos siempre. A ver a la familia.
Speaker 7: Y que es tan bonito, eso va a querido.
Speaker 1: Son cosas diferentes, pero por playa, aquí lo mejor. De América incluso, del Centroamérica, del Caribe, es mejor aquí. Pero tiene su belleza también Chile en el sur, está la Patagonia, que es muy lindo, tiene la montaña con nieve espectacular. Si compensa.
Speaker 7: Una por otra, pues compensa, fíjense. Exactamente. Vale, pues pasa buen día. Muchas gracias. Hasta luego.
Speaker 1: Selene.
Speaker 1: Dile, dile, hacienda la trenca, hacienda de Chile. Dile, dile. Dile tú.
Speaker 7: Pero esto no están caído tan bien como vosotros, la verdad.
Speaker 1: Que llega a equipo. Así que me atiende bien a los chilones y a los mallorquines, ¿vale?
Speaker 1: Chao.
Speaker 1: No, no, no.
Speaker 1: Tenía efectivo?
Speaker 6: Ya, tenía efectivo.
Speaker 1: Toma, Yo te paso.
Speaker 6: Sí, Tengo cuenta acá. Pero cuánto vale? Que te vayas.
Speaker 1: A gastar entre vez. No, pero ahí me haces una transferencia. Sí, pues te hago visu, pero tenéis teléfono.
Speaker 6: Yo tengo.
Speaker 1: Yo la ocupo para. Aquí le vivimos, pero es que la familia vive aquí. Tenemos en verano, en invierno,
Speaker 3: Pasamos aquí mucho tiempo.
Speaker 3: Igual un dedo.
Speaker 6: Gracias. Chao, disfruten.
Speaker 3: Primera Vez acá?
Speaker 6: Yo vivo en España. En Linares.
Speaker 1: Nosotros vivimos en Santiago, pero mi mujer es de aquí de toda la vida.
Speaker 6: De mayor tipo.
Speaker 1: La familia está aquí, toda la familia materna.
Speaker 5: Qué maravilloso. Te gusta Chile? Sí, estás feliz.
Speaker 1: Está bien la cosa. Disfruten, chao. Chao amigos.
Speaker 1: Don Michael, el cachete, igual no me cayeron tan bien como ustedes. Porque llegaran así como de mala hostia. Te das cuenta que uno tiene que andar de buena hostia siempre? Es gratis.
Speaker 1: Y a lo más te toca un pesado.
Speaker 1: No, pero si. Y con tarjeta no seas jugar mucho.
Speaker 5: Lo va a explicar, tengo 15 o 20 años.
Speaker 1: Oh el bebé ¿Te ayudo con una mochila?
Speaker 6: Apúrate con la mochila.
Speaker 1: Don Michael que es don Michael o sea todo es no no estoy seguro si yo me acordaría del camino. Recógela, recógela, no porque te vaya a quemar. Es como turquesa, mira si la mira así las gafas, está de turquesa.
Speaker 1: Elena no te quedes atrás. Te gustó la arena?
Speaker 1: Qué delgadita, no? Es como la sal fina.
Speaker 1: Se trae al taladro sí para hacer el hoyo para que no se vuelva.
Speaker 6: Ah, Pero hay harta cosa negras.
Speaker 6: Por ahí.
Speaker 1: Te gustó?
Speaker 1: Te gusta el color? Es bonito? Es color turquesa, ¿no?
Speaker 1: También una parte se ve como negra, una parte azul de aquí.
Speaker 1: Vamos a buscar un lugar. Ayola, sí. Vamos a buscar un lugar.
Speaker 1: No ni si me pueden hacer biso o no, o por tener números chilenos o no. Porque entiendo que el biso. El biso.
Speaker 1: Sí.
Speaker 1: Este está bueno.
Speaker 1: No, esto es el sol. Pero está filete porque eso no ocupa nada de espacio.
Speaker 1: Aquí ya está lleno. Gracias. Vale, coco, coco el dinero. Dónde, dónde, dónde?
Speaker 6: Escoja Usted.
Speaker 1: No dice dónde.
Speaker 1: Ah? No, acá la mamá no quiere.
Speaker 5: No, es que yo creo que aquí se me va a echar intensiva, ¿verdad? Aquí, como quieran.
Speaker 1: Yo pongo eso, tú ve al niño que tengan sus cositas para ir a jugar y. Se van a ir parece? Me voy a.
Speaker 4: Ir directo a la piscina.
Speaker 1: Dante, por favor, en sus cajitas! Ah, vengan a marcar territorio, rápidamente.
Speaker 6: Nicole, vamos a ir a jugar ahora.
Speaker 1: De la sombra para acá de aquí para acá.
Speaker 5: Mucha otra gente cierrando por ahí atrás más grande que hay ¿No?
Speaker 4: Sí ah ¿Qué? Uy cuidado.
Speaker 6: No está tan bien, vaya a tomar.
Speaker 1: Sol, Esto va a hacer sol, esto no porque está el agua.
Speaker 1: Aquí tenemos un poquito de sombra.
Speaker 2: Aquí me.
Speaker 1: Voy a poner la sombra, esto la estoy poniendo para poner un poquito. Por eso me importa que está al sol porque son los juguetes.
Speaker 1: No, hija. Tiene que tener cuidado de hacer eso porque le salta a la gente. Aquí para que no se les calienten y después no se queman. Estamos a esta.
Speaker 5: Ah? Tome temprano.
Speaker 1: Sus Juguetes están Ahí.
Speaker 6: Ah, a ver qué protección.
Speaker 1: Trájelo ahora, me acordé. Para meternos y sacarles fotos. Las traje aquí. Me acordé del otro día, pero voy a ver qué protección tienen ante el.
Speaker 1: El agua ¿A quién? Qué vamos a ver? Unas cosas así las contra.
Speaker 6: El agua.
Speaker 5: Como les cambia el humor cuando ven que las cosas son bonitas.
Speaker 5: Como les cambia enseguida el humor cuando ven que uno los lleva a un lugar bonito.
Speaker 1: Aquí dice son resistencia al agua y tres, cuatro significa tu casa estarán seguras, aunque lleva ligeramente, te la llevas puesta. Lo único que tendrías que hacer es quitártela cuando puedas, resistencia al agua.
Speaker 1: Resistencia al agua.
Speaker 1: Se pueden a ver con las gafas al meta, haces eso, que le haga gafas hoy en medio de ustedes.
Speaker 1: Sí, de hecho, se puede poner unas tú y unas yo. De las gafas. Yo grabo para allá. Qué bonita unas conchitas. No sé si gris. Saque las dos por si acaso, porque el otro día me acordé que ese estaba bonito.
Speaker 4: We're not taking the Floor.
Speaker 1: Thank you very much. La sombrilla y el flotador, que se van.
Speaker 5: A Nueva York ahora.
Speaker 1: Que lo ganan.
Speaker 5: Hoy Acabamos de comprar una sombrilla.
Speaker 5: Su flotador y todo, ¿dieron las gracias?
Speaker 5: Ala, pues enjoy, pequeñito.
Speaker 5: Esto Será de ella.
Speaker 5: Camina un poco.
Speaker 4: Espera, Elena,
Speaker 5: Elena, Elenita, que hija.
Speaker 6: Listo! ¿Era de ella?
Speaker 6: Se iban a dar cuenta.
Speaker 4: Cuando se pongan a poner las cosas.
Speaker 4: Mira que buena banda.
Speaker 1: Ahora tenemos dos, le compramos un.
Speaker 3: Un taladro y el extraño. Son premios. El oye es parte, parte. Avión.
Speaker 1: Sí. Back to New York. New York. No, esto yo creo que es porque pasa.
Speaker 3: Al poder Piage, donde si estás con esto, capítulo por italiano. Muy poco. Caso Neto. Copetitor. Ah, ya, ya. De aquí parte. Kibola, aquí, glow. Lacha, la solecha, bate, milibri. O visual, este ya de Fadaboi, Mayorco. Ah, sí? Sí, turista que parte. Lacha, lacha. Lacha, lacha, la.
Speaker 3: Es precioso. Ah ya. Es que ha visto el Jehová. Ya, lo deja de regalo.
Speaker 1: Sí, qué bonito. Ah mira, qué buena idea.
Speaker 5: Bueno aquí tenemos los primos y el. Y la.
Speaker 1: No, bueno. Sí po. Pero qué buena idea para la gente en general, es como consentido, cachai? Alguien que se le olvidó, que no lo compró, que no tiene plata, que es como les pasó a ellos, que tiene tarjeta.
Speaker 5: Esta subió una pizza y se la han traído.
Speaker 5: Se pensaban que era una pizza grande.
Speaker 1: Oye, mierda. Tu teléfono? Sí. Tú lo tomaste. Yo te estaba preguntando sobre la caja.
Speaker 1: Para flotar en el mar. Así mira.
Speaker 1: En el mar se lo pasaron. Ah, de unas gafas que nos regalaron estas. Todo lo que tenían.
Speaker 1: Pero para ella seguramente. No, para ella, para ellos. No, pero había sido para ellos para echarse. Igual es choro tirarse aquí en el agua.
Speaker 1: Anda tú pues nadando, mira, yo cuando era pequeño nadaba en esto, te pones de guatita y te pones a nadar así. Y esto se pone en la muñeca.
Speaker 1: Eso se llama Body.
Speaker 1: Bueno, qué suerte hemos tenido.
Speaker 1: Es mi amor?
Speaker 1: Sí, tranquila que te vamos a poner la crema.
Speaker 1: Este pin a quién se le salió?
Speaker 1: Este pin de quién era?
Speaker 5: Elenita e hija tienen que. Oye, papá, si no se ponen crema nos vamos al tiro.
Speaker 1: No, no, si con esa crema sí o sí.
Speaker 5: Mírame hija, yo así no puedo, hija.
Speaker 1: Ah vale, pero estaba ahí pues hija.
Speaker 8: Sí, pero tenía el jovencito.
Speaker 1: Ahí.
Speaker 1: Se ve muy bonito el helado, mira. Están bonitos como tú.
Speaker 1: Se puede poner? Sí, se puede poner. Le gusta la pizza? Está buena la pizza?
Speaker 1: Sí.
Speaker 2: Lo guarda,
Speaker 5: Esto escóndelo bien, el teléfono bien. Si te quedes con el trae más la cara, este te va a quedar más fácil de restregar.
Speaker 1: No es muy densa?
Speaker 5: No, ponte de líquida. No tiene efecto ni maquillar, como se ve ahí. No tiene? Te la has de restregar bien no más.
Speaker 1: No sé si me tengo que poner donde no me tapan las gafas, si las gafas tiran me curan acá.
Speaker 5: Aprovecha de estirarte en el cuello y en el cecho, guardarla.
Speaker 4: Cómo venir aquí? No aparezca.
Speaker 2: Thank you so much.
Speaker 1: Uh, unas conchitas muy bonitas.
Speaker 1: Acá?
Speaker 1: No sé cuál es la tuya, Amber?
Speaker 1: Como tu regadera?
Speaker 1: No, yo no he metido nada. Esta regadera de quién es?
Speaker 1: Ah, ¿la tuya es la verde? Sí. Esta es la tuya porque esta es la de que mira. Esta es la de la clara?
Speaker 1: Ah, tu rascadaste la cuenta ahí, ya.
Speaker 2: Vale.
Speaker 1: Es un trocito de la concha.
Speaker 2: There are no idea of the power.

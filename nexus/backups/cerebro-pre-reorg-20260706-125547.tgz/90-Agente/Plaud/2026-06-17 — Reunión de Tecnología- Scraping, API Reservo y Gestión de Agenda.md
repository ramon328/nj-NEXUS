---
tipo: plaud-resumen
tags: [plaud, resumen]
autor: plaud
fecha: 2026-06-17
---

# Reunión de Tecnología: Scraping, API Reservo y Gestión de Agenda

Voz 1: Discusión sobre el color amarillo y la calle. Es necesario informar sobre la API para scrapear datos y descargar documentos. La prevencionista de HN e IMPOMIL podría ser contratada por pituto, pero su disponibilidad la maneja un tercero. Es necesario investigar si se puede hacer "scraping" de la página para extraer datos o, alternativamente, encontrar una API económica y estable. El presupuesto está listo para ser ejecutado; se necesita avanzar y no seguir perdiendo el tiempo. Ramón está grabando la sesión para tener los resúmenes.
Voz 2: Hola.
Voz 1: Dónde está?
Voz 2: Ya, baja la escalera.
Voz 1: Sí.
Hombre: Ya. No me pudieran hacer la wea, así que les dije que les mandé una foto de mi pasaporte, dije que esta es la wea y me lo mandan por mail. Chao. Y si no, vengo otro día. que ahora tenían el ticket, pero con el ticket no sabían cómo hacerlo porque se hacía automático el ticket con el pago y la aguanta. Qué está bajando? Ahora porque me había pasado de la escala, ahora voy a coger. La escala de las Crows, eh, cosa pasa. Me estoy devolviendo porque me había pasado de largo para ayer. Sabía que querían ir a eso. Yo lo sabía. Pero yo no les voy a comprar nada. Vale, bien chao. Vamos. A pasarlo bien, a disfrutar, a ser felices. a llorar, a sufrir. Eso de que ponías una canción. Qué patúa. Dice que yo ponía una canción y ¿qué pasó? grabamos pero cuando se acabe la canción ya nos vamos a hacer la mitad de la canción la mitad bueno van a mirar cosas o no? no sé, ya lo voy a pensar hola! vayan a mirar cositas que quieren a ver no. No puede ser que todos los días se me compre. Star Wars. Qué quieres? me caben otras. andan todo por el lado distinto, necesito que estén juntas. Vamos viendo todos los pasillos pero ordenaditos. Por acá primero mira, venga. Clara. Vamos a ver todos los pasillos, primero este, después el otro, pero ordenaditos por favor. Y este es el Paco Hola, linda de Disney. Son de Disney, esto. Voy el de Stitch? Ya vimos. Me quieren avanzar por este pasillo? Quieren avanzar por este pasillo? De Zootopia? Clara! Nicole, todos por el mismo pasillo por favor. Mira este es como el que costó tanto encontrar a la mamá o no? No lo puede romper de nuevo viste? Oh my goodness! No, pero no, ya ves tremendas, gigantadas. Papá, esas cosas sí que no se pueden llevar. Tienes que poner reglas si vas a hacer eso. Qué? Qué reglas si no voy a hacer nada? Eso ni digas que se le ocurrió a tu hermana loca. Pues nada. A tu hermana loca, loca. Por las pequeñas. Qué? Por sus, por sus eras tú. Por las pequeñas? La última vez que lo haces por unos días. No se lo voy a pensar. No, dije que lo voy a pensar nada más. Vamos a qué? Ninguno. Porque estamos mirando cosas, no puede ser que todos los días venga a comprarles algo, no puede ser eso. Así no funciona la vida. No, pero eso fue ayer y a ti te compraron otra cosa que tu pediste, un osito de no sé qué cosa. Este para que aprendas. Cuidado con la señora que está trabajando. Pa, ¿por qué no te gusta que me compre esto? No, yo te compré una lotería. No nos queda un pasillo por acá, hacer este pasillo para allá. Un despertador para ponerle en el culete, o sea. Una lámpara. Una pampara. Oye, dije por el mismo pasillo todos, porque si no. se me pierden. No. Por qué no? Porque no quiero. Es que no puede ser que cada vez que salgan de la casa le tenga que comprar algo, eso es un problema. Papi, vi algo de papi, vi algo de EEE. Dónde están las olas pequeñas? Porque tienen peludos. Mi ventilador. Por favor. Si me quieres que me piense lo que me lo dice de hacer esto del congustio en el nudo. Mira, si me lo sigues preguntando, la respuesta va a ser no. Si me dejas tranquilito, durante el día, pensarlo, veremos. Si no pueden salir. Quieres ir al baño? Vamos a mostrar las manos. No sé si lo pienso no lo voy a pensar en un día, pero durante todo el día. voy a llamar con calma, si tu me preguntas a cada rato te voy a decir que me voy a ver la espera. Ah, sí, espera, te voy a llamar la mamá. Dónde quieres ir? Ah, pues yo te veo de acá pues. Pero puedo salir. Estoy llamando tu mamá. Mi amor, aló. Hola. Elena que quiere ir al baño puede salir. No lo puede llevar si hay familiares aquí. Hay familiares aquí? Sí, sí. Estoy en el probador. Vale. Ya, chao. Yo voy al baño porque la mamá decide tener familiares. Bueno, vamos a ver todo el mar. Ah, pero primero voy a llegar al baño de tu hermana. Voy a jugar acá después. Primero vamos al baño. Está la canción. donde hay baño de familiares. Van los familiares como están por aquí. A pasar? Y yo solo que una entrada aquí. Creo que aquí no hay. Hay en el baño de arriba. Aquí creo que es todo eso. Ah. Estaba ayer un baño familiar? No, arriba. En el mismo que el curso de arriba. Ok, gracias. Vamos pequeña. A ver, está solo de lactancia. Vamos a entrar acá. A ver, ¿cómo hacemos? Querés hacer pipinos, Elena? Entramos al de hombre, pero entran así. Ah? Los familiares de arriba, pues. Nos vamos a demorar y se va a hacer pipí esta. Estremo esto. Y nos limpiemos ya. No te hacen nada todavía. No te hacen nada. Perfecto, por favor. Cancel. Programa. Chicos. No van a jugar ahí? Te acuerdas de mí que te vende ayer en las cross? Está cerrado. No, no, que ha habido un problema con la llave pero ya se ha abierto. Ah, porque mira, al final las de las de ellas, de las pequeñas se las puse a ellas. Las de ellas quedaron pequeñas, entonces ella quiere ahora de lejos también, entonces le voy a cambiar esta por una de lejos. Vale, ya está allí ella. Ahora sí? Sí, ya se las cambió. Ella me vendió ayer. Tenía razón. Pero tenía razón. Son muy guapas tus hijos. Gracias. Tenía razón, ellas no le iban a ir. Porque las de ellas quedaron aquí pequeñas y las de ellas las puso allá. Se quedó con las de Bluey que quería de lejos. Ella no. Ella no tiene para Leo. Pero las de Bluey, mira, son una pasada y acaban de llegar, ¿vale? Nuevas. Sí, nos vemos chicos. Muchas gracias, chao. Ya, abrieron las crocs. Vamos a buscar las crocs. No? Juegan un rato acá. Ya. Juegan un rato acá. Acá mirando, sí. Apreta la Elena. Que le tienen que ayudar a la Elena para subir, pues a ver. No pueden solita ya. Esperen a la Elena. Esperen a la Elena que sube. Espera, espera. No se pongan ahí que va a bajar alguien. No puedo here because someone, we will go down, ¿no? English, Spanish, German. No, entonces juegan al otro lado. Yo voy a hacer una consulta que jueguen ahí, pero juntita a las tres, por favor. Ah, está tu hermana A ver un poco, ¿no? Cuidado, hija Ya, me dejan preguntar una cosilla aquí El cargador tiene los elfos se me. No funciona. Tiene mucha elcar solo en ataque ¿Bro? Puede ser? No los tengo acá, pero si veo la cajita no puedo identificar aquí. Adiós. Espérame hija. Eres muy poquito. Grabamos. Llaman a Elena? Sí, sí. Dulces no. Cuidado. Quieren agua? No, yo quiero dejar una tontería porque eso es. Es agua? Sí, ya. la tontería porque ese tiene el mono ese y solo por eso pasamos por acá a pagar. Hola. Eso y. perdón. Tres veces. No saques las cositas por favor. Pues son siete con treinta. Uy, qué rico se ve esto. Yo te ayudo, espérame hija. Vengan acá, no abrimos, vengan. Niñas, vengan, yo les ayudo. Tomen agua primero, deberían tomar agua, pero hija, no suben la tapa, si se abre y toma. La tuya de Stitch y las tuyas de los de Stitch. bueno y yo no tengo nada. Ven acá, venga. Bien Nicole, muy bien. Nada, nada es imposible. Fuerza, brazo. Casi, casi. Es complicado, sí. Los hermanos no le están creando. relojes. Estará claro, no son de los otros? Los venden? Mira Elena, ¿dónde estás ahí? Vale, vale. Te falta poco. Cuidado, cuidado. Esa es la tuya. La botella acá, la botella acá. Porque si se caen con la botella se pueden golpear. no lo tires hija. Muy ten cuidado. No la tengo yo, la tiene mamá. Hija, no lo tengo yo, lo tiene mamá. No, ahí no podemos salir al baño, vamos al baño. Arena, Arena. Ahora tú, se ponen de acuerdo. Busca la Elena para que vamos juntos. Dele a Elena que venga para que vamos juntos. Ahí arriba. Baja, por favor. Por ahí, baja por ahí. Baja por ahí por favor. Vamos que quiero ir al baño la Clara ahora. Llamamos a la Clara al baño ahora. Bueno, ahora vamos a llevar a la Clara. Uy! Sí, mi amor, podemos. Ya, vamos. Vienen hacia adelante. Vamos, vamos, pollitos. Y David. De verdad? Muy bien! Madre mía, lleva tres Premio, con el pañal fuera, ¿no? Muy bien! Felicitaciones! ¡Muy bien! ¡Adiós! Aló. Hola. Aló. Hola. Después se le ocurrió a la Clarida del baño, buenas tardes. Se tuve que ir al baño. Venga. Venga hija. Para qué baño estás papi? Elena, no botes eso. No, recoge eso. Recógelo. Estamos afuera del Belros, justo hay un baño ahí. Recoge eso. Y tráelo a la basura. Elena, tráelo a la basura. Estamos al lado del Belrose, donde hay un juegos, que la Clara ahora quiere ir al baño, entonces fui al baño, no te podía contestar y cuando te contesté no contestabas. No metas la mano, solo tire eso ahí. Acá está la mamá, vengan. Vengan, niñas. Perdón. Perdóname a mí. Tan pequeñita que no te vi. Ya, vengan. Ya, vamos. Cuidado, cuidado con el señor. Cuidado con la señora. Ahora, Anita. Ahora abrieron el. Ahora abrieron el Crocs. Ahora me avisaron, sí. Más cómodo. Mira, lo que compres con Tax Street, cómpralo con Scoucha, y lo que compres con cosas así de esas, con la de la plandeja casa. compraste un montón de cuevas patio pa la niña. Hija, ¿Quieres ir a escoger algo por ahí? Mamá, acércate a una silla pequeña, David. Esa silla. Esa hija cualquiera de ahí. Esa. Bueno. Anda a buscar servilletas ahora, espera la mamá. Con la boca cerrada, hasta dos gritas. Clara, clara. A tu miss, yo no tengo el contacto de A tu miss. Mientras comen, yo necesito preguntar ahí en una tienda si tienen unas cositas. Entonces terminan de comer, me pasan a buscar y vamos a las crocs, vale? Se me falló la cajita, no los ando trayendo acá pero yo sé que estos son los últimos creo y no era así la cajita. Estos son. Cuántas generaciones puede ser? Estos los compré hace un año o en noviembre por ahí. Son los que tradujo, pero no es esa la cajita que necesito, necesito la anterior. Puede ser cuántas generaciones hay. No lo sé, hago frente a uno de nosotros Ah, ahí sale Estos son, es la caja de los Pro 3 Estos, yo necesito anterior a eso Pro 2 debe ser. solo la cajita que tengo murió la caja, o mejor lo traigo acá y. pero quiero saber si tienen al menos solo cajitas. Cajitas de generación 2, no son los largos, son así como estos, la forma del. la forma del audífono que yo tengo es igual a este, es igual, la forma. parece que es más corto pero no son esos largos. Vale, ahora mismo no hay en ninguna tienda de palma, los de la cajita de los productos. Vale, muchas gracias. Qué dice que fuera que me pase? 80 euros el gramo. Ahora me van a pagar el 70 por el euro más caro. Creo que sí. Estas niñas puede haber sido con los zapatos de ella, no sé. Espérate esta que tiene que ser tu número es doce. Doce. Cómo que te tenés la de lejos? No, yo te compré una grande. Sí. Tiene que comprar muchos. Ven aquí. Estas son dos, si estas también. Estas las veo más chicas. De esas las que te compré, sí, pero déjalas ahí. Está bien o tiene que ser una más grande? Dejen ahí esas cosas. Me gustaron más esas. Esas son rositas. Nicole, por favor. Nicole, deja las cosas ahí. Esa o un número más grande? Segura? Te queda bien? No te va a quedar pequeña en.? y esta queda bien. Es por eso, pero la diferencia es casi la misma, que son casi iguales. Estás segura que no es una talla más? Bueno, quiero que te queden pequeñas en. A ver ponerte hacia adelante. Sin esto, déjame hacia adelante. Mete el pie, hasta lo más adelante que puedas. Saca el disco. Pruébetela como la usas tú. Qué grande? Sí. Te incomoda? Segura? Deja, deja eso ahí, por favor. Segura? Sí, enorme, me queda, enorme grande. Dónde? Yo soy doce. Cómo estás? Próxima llegaron tres. Están tallados y todavía. No, pero ahora déjame decir que te queda el chica. Esa? No? Cómo así? Esa, entonces. Dijo la Tali, dijo la Tali que tenía Jones de Pi. Que no comparantes, por favor? Puedo hacer un cambio, por favor? 23 euros puntos. Pato importante. Gracias. Adiós. Vale. Listo, hola Nicole. Mira, mira este, mira. Pues no los tomen de que los hay. La tía Tali dijo que ni un pin, porque tenía exceso. Yo vi unas de acá que las encontre echaras pa ti po. Esa, esa. Esta que no tienen tan lindo. Te la quieres poner al tiro, Nicole? Ah? Échame el agua. Hay que lavarla, señor. Va. Hija, hija, no se mueva. Ahora, ahora tendrás crooks moradas. Bueno, vamos todos de crocs nuevas. Con Bluey. Con Bluey y con Lego. Elena me está rompiendo a mí. Elena me está rompiendo. Dombo? Creo que me está rompiendo. Elena. No pasa lo mismo que la Elena. Creo que ya sé por qué. Viendo la correa, así parece que me he enciado bastante con una paja. Hola, buenas. Te puedo molestar? Sí, lo pedí por favor. Tú tienes que esta para el dinero? No, porque no trabajamos por gramo. Qué haces? No, mi amor. Gracias. Qué tal? Está lleno pero el lobo me recomendó venga está en Mallorca bajemos aquí para ver si la compra ahí de afuera a Oro Charro, Puerta del Solo Ah, no, esos van para abrir Ahí está. Si, o sea al frente del Carrefour Mira, aaah Joyería Weinler Jaime tercero, joyería Sugar Jaime tercero, JF Joyeros Quick Gold, me dejo con eso, hace un cuánto te paga uno y se raí, entonces tengo que visitar cinco lugares, Voy, vayan con la mamá que llamen ahora. Voy con la mamá a esa tienda. A. Hola, qué buena consulta. Me quedan que frente a como un chino para comprar una cosa. Sí, está justamente en el medio. Me das el restaurante, está ahí, vale. Muchas gracias. Hola, se les hace estas básculas pequeñitas que son para pesar 200, 500 gramos para joyas, para pesar de cocina y eso. Dónde? el agua es. Pero qué? Si el agua es azul ¿Cómo no se tira? Si el azul no se tira? Gracias. Sí, pues yo lo compré. aquí del. Están bonitos, ¿no? No? O sea, para guardar sus cositas, ¿puede ser? pero. no, de esas no esas. Yo lo compraríamos así, pero que tenga para colgar. No, porque van de lado, ¿eh? Si se fuera a colgar así, ¿cachai? Pero así de este tamaño me quedaría perfecto. Por aquí te acaba un montón de celular. Me puedes grabar? Sí, oye, pero déjala ahí. Ah, que no son tuyas, patrulla. Como 20 lucas, un poquito más de 20 lucas. Pero qué van a guardar? A ver, por ejemplo. Esto es para que esté cerrado, no para que caiga. Los lentes se le caben. Se le caben. Si, les caben los lentes, lo que no les cabe es las cosas de los lentes. Se caben los lentes. Mira el bolsillo de adelante te caben. Podríamos también guardar todo. Pero este no es tan cómodo. Esto es para llevarlo en el brazo. No sé, yo creo que es más cómodo que el otro. Hola. Estas blancas? Blancas no. En El Corte Inglés. No había. No había para allá. Había. no, había una 44 y una 41. Para aquí ni siquiera nos ha llegado blanca. Sí, y algo como esto que se queda por aquí, pero más grande. Si fuera manaja con brillo, me gustaría más. A este no le gusta ninguna? No. Cuál? Ese o ese? Es que este se ocupa en la manga. Esto se ocupa así, ¿no? Sí. Es para llevar tu móvil. Exacto, es impermeable. Es un poco más grande. Ahora, ¿esto no le ensamos? No. Si se cae la piscina? No, no lo puedes sumergir. Es impermeable, no le entra si se cae un par de lo que sea. Pero si se cae la piscina y se hunde? No, flota. Por eso te digo, o sea, no pasaría nada porque el teléfono así. No es que se adelante. Esto hay que procesar así. Y no hay ninguno que sea como esto, pero un poquito más grande. Tal vez de este tamaño, pero que se pueda, Y a este no se le puede inventar algo. Ya, ¿qué quieren ustedes? Tú quieres naranjo, tú quieres azul, tú quieres. Hay un fucsia también. Mira Elena, el fucsia más bonito para ti allá. Mira, mira. Mira que bonito este. Como tu. Mira más parecido a tus cracks. Cuál prefieres? Te vas a confundir con el de papas. Si, te vas a confundir con el de papas. No. Cuál prefieres? Mira. Se puede hacer más pequeño el rosado? Si, así mira. Esto también se pueden llevar como el. Eso tiene eso y el que lleváis también lo que se parece aquí. Puedes llevarlo así, luego si te vas a caminar por la playa, por ejemplo. Para mí es más cómodo. Depende para donde vayas, claro, te pones así. Claro, te queda súper guachi. Es más cómodo que esto, claro. Para mí sí. A ver, depende, eh. Ya, pero este sistema no se puede hacer con estos más grandes. No, esto es para llevar, esto es para llevar de lado o sería como. le falta ahí unos bolsitos. Yo no me vería muy bien con esos bolsitos, claro. Aquí vas caminando. Es más cómodo, sí. Qué te parece? Espera, se pueden poner así también. Bueno, ya. Cuál quieres? Ese? Y tú, Naranjo? Qué guapo, ese tuyo, del brilli brilli. Pero por qué igual, hija, es que se van a confundir si son iguales. Bueno, ella quiere igual que ella. Ese, iguales no, porque luego se come. Bueno, podéis poner. Iguales no se pueden. Es que no le quedan más de esos. No entendieron. No, no. Es más cómodo para muchas cosas. Las costumbres. Bueno, Elena, nos quedan más de esas, así que es cojo. Quieres esta? Fucsia? A mí me gusta más la fucsia para ti. Es que se lo lleva la Nicole. Este es muy bonito. Uno de cada, claro. Pero hija, mira. Ese como ese. Este es como tus zapatillas, mira. Es como una muchachita que luego se te cae en el suelo. El agua te puede entrar agua, se puede poner. Pero es mejor así porque si se te cae la piscina, porque si le entra un poquito de agua. Este es el mejor. Este es el mejor porque a este no le entra agua, ¿cierto? Claro. Este si se te caga en la piscina, no levanta el agua tu juguete. Ese parece que puede ser que le entre el naranjo y al otro color Pero a este color, no le entra agua Entonces, más seguro para ti, ¿no? Chiquito? Así? Lo pones así, mira, con la manito, una mano Este es chiquito Ah, es que no te pone tan chiquito, mira Todavía no, para ti todavía no se puede porque tú tendrías que achicártelo aquí. El mío estaba muy chiquito. Así viste, así me queda bonito, mira, ahí. Y este, ahí. Sí, porque el color es sección de buenos suetes. Ya, y la mamá, y la mamá se puede. Además, conviene con tu labial, mira. Y la mamá, ¿dónde está? Mamá! ¿Dónde está la mamá? No te gusta? Mi mujer se fue. Desapareció. Ya es costumbre. Con el Tony. Con el Tony? El Tony es el amigo que tiene. El único amigo que tiene. Yo no entiendo. Ya, le voy a dar esta. Estas le gustan? Así? Sí. De marinero? Sí. Para el papá? Sí.
Voz 1: Ya. Con esas puedes embarcarnos para nosotras. No, son para andar en la calle pero. La verdad. Ya. Yo quería las blancas, pero bueno. Bueno, son tres de esos bolsitos. Necesito hasta cortar la etiqueta, así ya de paso. Ya, oye, pasen por ahí. Pasen por aquí. Pasen por ahí niñas, para que las saquen la etiqueta y es una cosa del seguro. Pasen por ahí. Vaya, guapa. Va a ser una foto una outfitti mismo guapa el peque. Pasen por ahí para que le saquen la cosita de la alarma, por favor.
Voz 2: Quiero probar que está pasando.
Voz 1: Eso qué?
Voz 2: Sí, el problema es que si le pones eso, tenta agua. Porque hay que hacerlo. No sé que lo pusieras aquí. Es un naranjo, un lila o un morado. Hasta adentro esto, eso es. Ya Nicole. Este es el de la Nicole. Lo que eres pequeñito, Nicole. Lo que eres pequeñito o más largo? Este es el bosque.
Voz 1: Ahí está bien? Está bien?
Voz 2: Es que tú eres muy pequeña para el modo cinturón, yo creo. Es que no, es que se te va a caer tú. Tenemos esta caña. Y las carnelitas, sí. Muy bien.
Voz 1: Si necesitas más.
Voz 2: Que estaba a salvo, te cabe. No, no, no.
Voz 1: Me cabe aquí. ¿Te cae bien? Más bien. Vale, con eso sería 112,96 con tarjeta.
Voz 2: Con tarjeta, con tarjeta. Venga.
Voz 1: Tienes la aplicación esta, la Govan.
Voz 2: Vale, perro. Si eres muy pequeñita para ponértelo así. Ahora mismo. Son muy pequeñas porque son los modos de cintura, mira. Tendría que ponerte aquí un pinch, un algo, ahí. Buscamos algo en la habitación? Perdón. Ah, perfecto. Ponera de manga corta y pantalón corto. Siempre pasa por encima de mi piel niña. Muchas gracias. Take. Estas pulseritas así no tienen.
Voz 1: De pulseritas no.
Voz 2: Exacto, ¿te puedo dar unas gomitas?
Voz 1: Ah, esto es un pins. No, yo la tengo, sí.
Voz 2: Con vomitas o si tiene que poner mujeres hace unas segundas y detallas, ¿eh? Es que lo que pasa es que para ponérselos de cinturón los podría amarrar con eso. A ellas dos no les calza, entonces la única forma es apretarles con una coleta.
Voz 1: Ah, es como lo que tenía mi esto tenía una cosa, ¿no? Esa esta, por ejemplo, esa que es que la regalo.
Voz 2: A ver, yo te lo busco, yo te lo busco. La de ella es beige. Esa le queda perfecta. Esta mira, qué bonita. Siempre quiere lo que quiere el regio. Dímelo, a ver. Creo que sí. Déjame, mira, es que estás así que voy a tener. Mira, te van rosita para ti, sí. Bueno, para ella tenía de color amarillo, pero lo mayor te da mejor. Es así, sí. Mira, el nuevo correo, gracias. Sí, así se lo arregla para que se lo pongan en el bizcocho.
Voz 1: Esto es lo que huelen los zapatos. No, creo que no. Muy bien. Gracias, muchas gracias. Hasta luego.
Voz 2: Gracias, chicas. Festi arte, todo. A mí también me gusta más así porque le ponen eso. Prefiero a mí. Este color, este es más charo que... que lo haga, no había metal ya de ningún color. Aquí tenían las mitañas en este y otros por la vez, pero este es el que más me queda. Esta es la corte de pelo. Esta la compré. Voy a pensar yo las cosas para tener claro. Pásame el bolsito.
Voz 1: ¿El bolsito negro?
Voz 2: La bolsita negra que te dije. Pásame. No, más tarde. Ah, sí, buen bolso. Oye, qué buen bolso. Papá, ni siquiera hizo el caldo. ¿Qué? Para qué te dedicas el rato? Ya, que te digo que voy a pensar. Y si me repetían más, no lo pensaba más. Me puedo hacer la bolsita? Venga a su sitio. A su sitio, Elena, por fin. Seguro que viene cintita. ¿Quién saco el reloj? ¿Qué saco el reloj? ¿Qué reloj? Yo el reloj lo tenía aquí cargando. ¿Cómo es esto? Por qué el control le quedase a la cara? No, si esto va por delante, clarito, no tenga cosas raras, eh. Ala, te alumbro con la linterna de esto. Ah, tenía linterna, esto no lo sabía, eh. No me tengo menos. No pesa nada. ¿La que pesaba era la otra, no?
Voz 1: Primero la historia de terror? Sí. Y eso qué es? Y el año de la... Ah? El año de la Cocuta. Y lo venden igual, el blanco que el amarillo? Sí. La que pesaba más es la que se cortió.
Voz 2: La que pesaba más, ya veniste en China, ¿no? En Japón. Nada más, aquí. Esa era la que más pesaba realmente. No, no, pero digo de las que te me quedaban. Puede desenredar esto ahora. No, porque tengo que sacar esto porque ese creo que no es de dieciocho. Pa que vea lo otro. Papá lo de las cruces. y el viernes y el sábado, porque acaban de pasar un cantel que están fumigando todos los jardines y eso, tiene que pasar 48 horas. Entonces me juro que todo años han dado la piscina y todo eso. Se han hecho esos porque algún vecino habrá dado aviso todavía. Vale, para que lo tengáis en cuenta. Es el viernes, empiezan a fumar. tú vas a tener six seven porque yo tengo siete, yo tengo yo tengo siete años vas a tener ¿Por qué hacen ese huevo el six seven? Yo no lo entiendo. ¿Qué significa? Cuéntenme po. Ya po, Clara, aguántame. ya pues Nicole pero cuéntame pues Nicole explícame pero ¿Por qué po? pero ¿Por qué haces la broma con el? No tengo ni idea. Mira las mariposas que vimos el otro día. Son una invasión que están llegando del desierto del Sahara.
Voz 1: Cuánto te tardas fácil nada. Todavía tengo el ¿cuánto me demoro de decir? Six seven. Cuánto me demoro decir? Six seven. en verdad ¿Cuánto quitan? Quién es? O sea que va a venir la policía. Y ahora almorzando. M tercero 17. Por ejemplo, con este casi corto, se cambian ya. Yo creo que eso cancela weón entonces. Porque yo anda encima le dije, esto va a cansar poquito, como 200 de pasta. 2. How should I come on? Hola, ¿Cómo están? Yo manejando. Se pueden conectar por mientras y ven lo relacionado a lo que ve Ramón de tecnología, porfa. Ya, que la quiero estar acá. ¿Llegó la llave? No, te la quiero dejar acá. Ya. <mark style="background-color: #F9EDD4">Está bonita la calle, los colores amarillos.</mark> Saca las patas llega de mierda, pero está bonita. Ay llegó Nico.
Voz 3: Hola Nico.
Voz 4: Hola.
Voz 3: Tiene rico, quedarme en pelea.
Voz 4: Sí, en serio.
Voz 3: ¿En serio? Oye que mira yo ahora tengo que entrar a ver una cuestión pero podrían avanzar revisando lo que hizo Ramón para que lo reconfirmen que esté todo bien por mientras avanzar con él. a ver qué posibilidades hay de de integrarse al ¿Cómo se llama? ¿Atienda? No, se me olvidó. ¿Cómo se llama? Eso, reservo. Y eso que que avancen con eso por mientras pues cosa que yo voy a seguir conectado pero porque estoy con el y después tengo el resumen listo tú también tenías el ¿Estamos?
Voz 4: Sí. Ahora.
Voz 3: Si estáis con el y estáis con los audífonos, Yo creo diría que te conviene sacarte los audífonos y poner el blood desktop. Bájate del escritorio y yo lo bajé en mi computador y funciona espectacular. Y así dejamos el... como todo no hay que tomar notas, cachai. Quedan todas las notas automáticas. entonces yo voy a apagar mi cámara pero voy a estar conectado escuchando pero voy a apagar mi cámara mientras para que avancen con eso primero lo de la plataforma de cómo se llama de la que ya se comenzó po sacar las dudas, variedad, no sé qué y después vemos la posibilidad de conexión con atiendo, atiendo no me acuerdo la cuesta ¿Cómo se llama? Reserva, reserva, reserva. Esa wea, reserva. Ya? Pero estoy aquí, usando cámara, pero estoy aquí. Gracias Nico.
Voz 4: Ya, vale. Vamos entonces a probar unas cositas. Bueno, en teoría me podrían decir dónde están esos datos de que me decían? De que está el reservo? Lo que me dicen que lo de las citas
Voz 3: No, cuando entras como por tu perfil
Voz 4: Voy a iniciar que cambié a computar entonces no tengo el reservo.cl ¿no?
Voz 3: Sí
Voz 4: Y ahí en iniciar sesión. Dieguito ¿En qué lado me dicen que ahora esté eso? En estadísticas
Voz 3: En estadísticas
Voz 4: Entonces acá por ejemplo lo que dice la cari es que pone desde arriba en la fecha
Voz 3: Por ejemplo si queremos revisar mayo entonces pone desde el primero de mayo al 31 de mayo
Voz 4: Arriba y ahí lo calcula. Esa no? Ahí, sí. Y en las flechitas corres los meses?
Voz 3: Desde el 1 de mayo este? Sí, al revés, al revés. En el desde el 1 del 5 o también lo puedes poner manual?
Voz 4: Ah, ok. Desde el 1 hasta el 5 no?
Voz 3: Hasta el 31 del 5
Voz 4: El 31 del 5. Ahí, y ahí tú pinchas calcular y todo ese Dashwall va a cambiar. Y ahí esos números, por ejemplo, que te aparecen con cada uno y desocupación total por profesionales, te dice la cantidad de horas, la cantidad que tiene ese profesional por su horario, la cantidad de horas que se bloquearon y la disponibilidad de, Entonces esa información yo la saco de ahí, pero no me aparece, me aparece así, no me aparece como en una tabla que yo pueda copiarte esa poco que le pueda de ahí, pero no puedo descargarla.
Voz 4: Ya, entonces lo que vamos a hacer, vamos es lo que les comentaba, que conmigo lo que estamos haciendo es como algo similar de que la inteligencia artificial entra a la página y ver si puede sacar estos datos, que es una especie de que entre con las credenciales que tenemos y pueda lograr salirlas, como la página no es tan bacán entre comillas, no tiene tanta seguridad en el tema de bouts así que espero que podamos pasar con eso.
Voz 3: Quizás lo que nosotros pensábamos era que si esta escala luego no podemos ir haciendo análisis profesional por profesional entonces por ejemplo no sé quizás tener cortes como los profesionales que están bajo el 15% de ocupación, los profesionales que están bajo el 50% o los profesionales que están sobre el 50% de ocupación. Porque ahí sale en porcentaje
Voz 4: Ya perfecto
Voz 3: Y ese debería ser el porcentaje de ocupación efectiva
Voz 4: Ya, entiendo perfecto Entonces esto no necesitan que lo pueden descargar en TDF
Voz 3: No, no les podemos descargar el volta
Voz 4: Ya perfecto Ok, entonces agreganle eso más.
Voz 3: Hay otra parte Nico, o sea Nico, perdón, Ramón, mira, se te mueve un poquito más para el lado izquierdo, en la parte azul, es que no sé si se ve que hay una parte que dice citas parece ahí al lado también.
Voz 4: Ah, claro que es como estoy en el. Sí, sí va ahí, pero.
Voz 3: Ahí sí, no, pero.
Voz 4: Qué pasa?
Voz 3: 6 citas, aprieta citas ahí. Si dashport, ¿cuánto ayuda? Dice dashport y abajo dice "citas", y recuerdo dice "ay en citas". Y ahí yo también saco otra cosa que es "citas por agenda".
Voz 4: Citas por ejemplo.
Voz 3: Yo, asiento de aquí, tengo que también la fecha, colocar el consumo y colocar el consumo uno, y el... y ahí te dice toda la cantidad de citas y el estado de las citas por cada box, eso también lo saco y lo saco así, de esa manera, como que tampoco te permite descargarlo con esos números.
Voz 5: Cami lo puede ver porque ella descarga la planilla total de citas y ahí tú puedes filtrar por box, puedes contar después para abajo, pero no te da los números así como en una planilla así como aquí, eso mismo con los siete box.
Voz 4: acá hay que acceder a Box por Box y en el descargar cita que es el archivo que yo te mandé el que subimos al otro lado es igual todo lo que sucede en el mes y desde ahí también se puede acceder como saca todo lo que pasó en el box uno, todas las que son atendidas, suspendidas, como en el en el archivo que que ya tú conoces.
Voz 5: Sí.
Voz 3: Pero solo que acá lo hace manual Box por Box entonces por eso pensábamos que en el...
Voz 5: Número igual.
Voz 3: Sí pero en el otro igual.
Voz 5: En el otro igual, como te va a decir cuántas son, si las filtra, si él le pide buscar el box 1 de mayo, te va a sacar esto, cuáles son las atendidas, cuáles son confirmadas. Va a salir con nombre, de paciente, de todo.
Voz 3: No, o sea va a salir, pero lo que nosotros queremos es el dato del estado de la cita, que es esto, esto también sale desde ahí mismo.
Voz 4: Sí, pero no necesita, solo te dice un número, no te dice el... el daño de la persona, nada de nadie.
Voz 3: Por eso, mira, si yo comparto, no sé cómo puedo...
Voz 4: No, yo dejo para transmitir, espera.
Voz 3: Ya, gracias. Eh. Bienvenías. Hoy. Si yo voy acá, que es la planilla en general, y estas son todas las atenciones por ejemplo de febrero, y voy acá a la tablcita. Muchísimas gracias. Hola. Y luego como las estadísticas de lo que. Este es el archivo que tú ya tienes, por eso digo que usted desde ahí mismo. Entonces yo atrás puedo filtrar. Muchísimas gracias, muy amable. Puede sentar aquí? Sí, señor, no tengo. Estoy acá... que apenas estoy seguro, si es decir. Ya que se cita y voy a estudiar los atendidos y ahí me va a dar el número.
Voz 4: Ya, perfecto.
Voz 3: Me va a dar este número, yo solo necesito el estado de la cita y me va tocar este número total de todos los atendidos. ¿Cómo se llama? De todos los atendidos que son 812 y de esos, ¿cuáles son en el box determinado que,
Voz 4: Quizás lo que te podemos dar como de esto es la columna que tiene que ir a buscar.
Voz 3: Tiene que ir a buscar en agenda todas las del box 1 y el estado de cita.
Voz 4: Bien, perfecto.
Voz 3: El box 1 y estado de cita.
Voz 4: El box y estado de cita.
Voz 3: Sí, el box y estado de cita.
Voz 4: Entonces que es la columna de agenda y la de estado de cita. Bien, entonces ustedes necesitan un apartado en la página donde, puedan ver esta casi esta misma tabla donde esté el box, el estado de la cita, y el total del las citas en esa box.
Voz 3: Sí, pero que tiene que ir metiéndose box por box.
Voz 4: Ya, perfecto. Ya, ok, sí se puede. Entonces, hay que ir, voy a notar si lo puedo hacer sin eso. Ah bueno, pero si estamos en la API. Voy a ver si puedo hacerlo sin la API. El número en total.
Voz 3: Claro, todo este dato como 5 datos, sino que me diga fueron 100 atendidas y 5 suspendidas.
Voz 4: Sí, sí, ya voy a ver si lo puedo hacer sin lápiz, si logra hacerlo sin lápiz le informo al tiro cuando lo logre.
Voz 3: Yo creo que si puedes porque... el archivo que ya está arriba, como ya el archivo que ya está arriba en la plataforma ya te hace filtrar los que son atendidos porque esos son los que se les paga. Entonces ya filtra por profesional y por estado de cita, entonces ahora tendríamos que filtrar por box y estado de cita.
Voz 4: Igual en lo que tiene que hacer la cari eso lo tiene que hacer todo a final de mes, ¿verdad? Ya, entonces ya, entonces sí se puede solucionar porque se tendría que esperar a que se suban los documentos de a final de mes, se guarden y de ahí se genera, ya sí se puede, perfecto, ya entonces eso más necesitan y dentro de la plataforma habíamos hablado que eso bueno lo deja que empezar a implementar ya esta semana me lo dejo como meta. <mark style="background-color: #F9EDD4">creo que en eso estaríamos con el tema de la misma tecnología ver, necesito que me vayan como informando igual qué tal la API, si voy a lograr igual tratar de hacer lo mismo como de scrapear y ver si podemos sacar datos y descargar documentos, etcétera, así la API
Voz 3: Super y en el pantallazo que yo te mandé con los KPI, sale quizás como la data hacia atrás, Entonces que quizás igual eso no sirve para ir con barato como lo hicimos con lo de venta.</mark>
Voz 4: Perfecto, perfecto. Ok, creo que eso es todo para la tecnología, ¿no? O no faltó.
Voz 3: Eso es lo de agenda, pero ¿en qué quedaron con lo otro? Ya está 100% comprobado la parte de...
Voz 4: Es que en lo otro no he podido, el avance nuevo no he podido avanzar tanto Nico. no pude meterle una manito estos días.
Voz 3: No, pero por parte de ellas, ¿Tienen alguna duda? Ah, ¿El lápiz? No, no, solo que ahora Ramón nos dijo que no se podía acceder como trochamente a... No, no. Entonces. No, no de lápiz. No de lápiz, yo les digo, la plataforma que hizo Ramón para el cálculo de las personas, ¿Cómo le llaman ustedes? Los reportes.
Voz 4: Los reportes, esos.
Voz 3: Ya no hay más dudas, ya está todo claro, está validado.
Voz 5: Sí, estamos cliendo. Vamos a hacer un pre y ahora a mitad de mes y después a fin de mes.
Voz 3: Ah, vale. Ahora con los profesionales que terminaron y que se van de vacaciones, con los que ya cerraron podemos hacer como un pre a fin de mes. Entonces yo voy a sacar el listado con los que ya podríamos hacerlo, para comprobarlo. Respecto al banco, para la tasación y para toda esa parte, ¿cómo van?
Voz 3: Nunca me digo, eh. No, porque fuera de que me contó que iba a estudiar en el avión.
Voz 4: Ah, no lo estudié, te mentí.
Voz 3: Sí. quedamos ahí, que íbamos a mandar ese correo como a todos los bancos, entonces yo te mandé ahí el.
Voz 4: Ah ya, mala mía, yo lo estudio.
Voz 3: El correíto que queríamos mandar y y porque nos acordamos de la opción también del también lo puse ahí por si es que o no sé para que veamos qué correo mandamos y... y nos faltaban los datos del escucho Vani Santander que nos dijiste que...
Voz 4: Entonces.
Voz 3: Que te recordara.
Voz 4: Tarea para mí lo hago yo y ¿qué más teníamos pendiente?
Voz 3: Nosotros teníamos que ver la parte legal de los contratos y hablé con el Hernán. Ah ya vi cachai laboral. Entonces. Dijo que se dedicaba y... vamos a mandar todos los reglamentos internos.
Voz 4: Eso es reglamento interno.
Voz 3: Los protocolos de atención.
Voz 4: De todas maneras. Los protocolos de atención. De todas maneras, por donde se le mire. De todos modos, la mejor opción es que se haga su propia SPA cada uno y te facturen. Esa es la mejor forma, la más limpia que vamos a ordenar. O sea, la gente dice otra cosa.
Voz 3: No, no, no, si no está eso. pero que esa figura además crece como sujeta a un arriendo de Vox, que es lo que siempre hemos hablado, pero que el arriendo de Vox, el pago sea el porcentaje de lo atendido. Como para poder tener más lineamiento en que la figura es arriendo de Vox también.
Voz 4: Pero cuánto paga? Ocho 500. Vale. Como por la cantidad de horas de uso, o lo que a veces te decíamos como pucha, un profesional se un vende.
Voz 3: Como para estar respaldados en eso. si teniendo el reglamento interno y todo eso están listos.
Voz 4: Sí, entonces le vamos a mandar todo eso y nos abrimos la próxima semana que modifique los convenios, porque claro, estos convenios partieron cuando éramos cinco personas. Entonces han cambiado muchas cosas.
Voz 3: Claro.
Voz 4: Espérame. mañana. Ahora sí.
Voz 3: Sí po. Ha cambiado mucho las cosas que contesté pero estaba con el silencio. Sí pues entonces lo que pasaba ahí inicialmente ni siquiera teníamos médicos entonces es muy distinto al escenario actual.
Voz 4: Sí claro. Y el pensionista ya tiene. Y el pensionista va a ir el el jueves pero el Ramón también me dio un dato entonces, ahí vamos a a ver con ellos. Un dato de la zona.
Voz 3: Porque también pueden hablar con mi hermano y pueden usar a la prevencionista de riesgo nuestra, se lo pagan ustedes aparte, pero obviamente va a tener un mejor trato porque ella trabaja con nosotros.
Voz 4: Sí, era un dato de la zona, como pensé que era importante como que conociera el espacio.
<mark style="background-color: #F9EDD4">Voz 3: No, por eso digo que tal vez puede ser la prevencionista nuestra de HN, de Impomil, y se lo pagan como pituto, y a lo mejor a ella le conviene ir una vez al mes.</mark> Pero eso pregúntenle a mi hermano, porque yo no dispongo del tiempo de ella porque eso lo maneja él.
Voz 4: Ya.
Voz 3: Así que en eso hemos avanzado, en la reunión con los profesionales creemos que no le vamos a tener hasta que tengamos listos los convenios nuevos con el equipo.
Voz 4: Ya, ¿y esos convenios tienen fecha? Hay que ponerle fecha, plazo y todo.
Voz 3: Sí, nos quedó una semana para revisar los documentos y la próxima semana nos reunimos. De aquí a la próxima semana yo tengo que tener solucionados mis pendientes del banco, ¿de qué manera?
Voz 4: Mío por mi lado? No, lo del banco. Te mandamos el flujo de caja, todo eso.
Voz 3: Por el lado de Ramón entonces es ver si que con una API podemos entrar a gendo, a reservo, si además pueden optimizar el cálculo de... Perdón, la tengo de cuando tenía 8 años. Es un año.
Voz 1: Es verdad, entonces, ¿qué dije? <mark style="background-color: #F9EDD4">De que por mi parte tengo que ver si puedo como escapear entre comillas la página y a ver si podemos sacar datos en, Y de lo contrario a ver si hay alguna API que no sea cara, pero que sea estable y que nos solucione el tema, pues, cachai.</mark> Y entonces con esos pendientes.
Voz 2: Nos cuesta subir al plan Enterprise, que es el que habilita la API.
Voz 1: Ah, ¿cuánto? Ah ya, es que yo me acuerdo que pagaban muy poco para exigirle mucho, si ese era el tema. Que recuerdo que pagaban muy poco cuando vimos el precio, yo te dije bueno, tampoco se les puede exigir tanto si para lo que pagan. En una de esas subir al Enterprise conviene porque teniendo la API Ramón pueden anclarse rápido a solucionar todos los pocachos.
Voz 2: Sí, entonces yo les mandé ese correo para subir a ese plan.
Voz 1: Ya entonces creo que los pendientes son de parte de ustedes, que Reservo nos confirme el Enterprise y con eso Ramón puede ver la forma de acceder para mejorar el proceso y eficientar el agendamiento, que la cosa de los cálculos de comisiones y esto de los, no me acuerdo el nombre que le ponen a ustedes, están 100% seguros que está, van a hacer un pre cierre el Hernán que les confirme la información respecto a los convenios y todo eso. Ahora yo insisto y exijanles que hagan su propia SPA y tengan su contabilidad y hagan su pega porque es súper fácil que te hagan la pega y por mi parte revisar lo del banco que lo voy a revisar hoy sin falta y eso creo que serían los pendientes que vamos avanzando, así como claro, habían un par de cosas que ustedes habían dicho que iban a comprar, que iban a comprar, que iban a comprar que la Cari decía "sí, ah ya, la has comprado". Clarísimo, porque el presupuesto está.
<mark style="background-color: #F9EDD4">Voz 2: que esa es la web porque el por supuesto está hay que ejecutar todo seguir perdiendo el tiempo no.</mark>
Voz 1: También también que trabajo en la Dávila me dijo esto que que le estaban haciendo mutar entonces quiero pedir cómo son los convenios en otros lados igual para tener algún formato de eso.
Voz 2: Pero yo te puedo conseguir con la Tali porque ella tiene los convenios con la alemana por ejemplo y tenía antes con la Dávila los debe tener guardados. la podemos pedir a ella.
Voz 1: Ya.
Voz 2: Supo, pero quizás ahora están haciendo estos cambios de que sean estos pegados.
Voz 1: No, no. Me dijo como ya lo voy a tener que hacer por acá con todos colores. Ah, ya. No, pero si la Cali tiene. La Cali lo hace por por empresa, ¿cachai? Y la Lore, la clínica Los Andes, y la gringa las cosas también. Ya. Entonces, ahí que creía que van a quedar marcaditos los paniados. Hay que transitar hacia allá.
Voz 2: Ya. Bueno, cortito, preciso, apretadito, no anotes nada porque está quedando todo registrado en inteligencia artificial y te va a mandar el resumen inmediato.
Voz 1: Maravilloso, ya disfruta por favor.
Voz 2: Estoy tratando. Ayer trabajé hasta como a las cuatro y media entre trabajar y esperar que Ramón me dijera que llegó a su casa porque el hueón me dijo voy en camino llegando y nunca me avisó pensé que lo habían matado.
Voz 3: Ah. Perdón.
Voz 2: Cuarenta y cinco.
Voz 3: Estoy asustado yo porque pensé que algo les había pasado a ustedes que no no contestaban.
Voz 2: Estaba tanto en mi casa ahí en esa bolsa guardado y le dije. Espérame un segundo.
Voz 1: tenía tanto en mi casa guardado que dije. pa qué? Lo silencié.
Voz 3: Gracias. Amigo. A ver. Espérenme un segundo. Eh cuarenta y uno. Esperemos esperemos. Ya está? Sí, en silencio.
Voz 2: Oye Ramón no sé si ahí te mandamos como un paso a paso de lo que mostramos recién. O está bien con eso.
Voz 1: No, está bien. Sí, también lo estoy probando en esta ocasión. <mark style="background-color: #F9EDD4">Así que después me hacen los resumen y ya tengo mejor estructurado que fuese a ser como los consexuales.</mark>
Voz 2: Bueno entonces creería que ahí esperería que ahí dimos el repaso de todos los pendientes ¿no?
Voz 1: Sí.
Voz 2: Ochocientos cincuenta.
Voz 1: El otro pendiente es que descanses pues hoy y disfrutes.
Voz 2: Ya vale.
Voz 3: a todos anótatelo gracias a ustedes ya entonces eran 800 son 4555 ya y puedes subir un poquito para no ir a otro lugar pero donde va a 4600 si quieres 50 4700 para no ir a otro lugar tengo que no perder tiempo espera espera a ver si me cuadra porque tiene que cuadrar se le cuadra.
Voz 4: seguro que te cuadra tiene que cuadrar mínimo 50 euros este señor me acaba de vender ciento y pico de gramos está súper contento yo vendí la otra cadena que pensaba 115 gramos en 8.500 euros
Voz 3: 115 gramos
Voz 4: 115 en 8.500 euros en noviembre que fui a esto es, Esto. mira, me acaba de vender 120 gramos en el pagado 9.550. Dale, vale, gracias.
Voz 3: Porque desde noviembre ahora hizo un.
Voz 4: espera, yo no sé, por eso he venido aquí porque el otro sitio ayer me querían engañar. Mira, yo no he ido a ningún lugar.
Voz 3: Me querían, pero me han visto las cartas y no han dicho este.
Voz 4: Mira, la blanca. Vamos a meterle. No, tú no, tú no. no allí es donde yo fui pues yo soy de la parte de acá yo vivo en Chile mi mujer es de aquí mi familia del lado de ella de aquí vengo dos tres veces por año y en noviembre pasé por Madrid y andaba con una cadena de 115 que la verdad es que ya no la uso y pasé por un lugar y me pagaron 8.500 euros
Voz 3: engañado venga va 4.700 5.700 y yo estoy aquí aún esperando por qué.
Voz 4: Ah, todavía no cierra, no lo he pagado ya todo, me está haciendo una súper reseña.
Voz 3: No, no, léela, que léela, que tiene te da la reseña.
Voz 4: Qué has puesto algo mal?
Voz 3: Te puedo hacer una reseña?
Voz 4: Hombre, claro que me vas a hacer una reseña y esto no calculé nada. A cuánto me estás pagando el gramo de 18 limpios para ti
Voz 3: a 75
Voz 4: hubiese esperado entre 78 y 83, ese era mi número.
Voz 3: Bueno, imposiblemente lo has bajado.
Voz 4: Yo le creo, no se preocupe. Pero piensa que una cosa. Yo la verdad, ella lo sabe, venga. Yo no fui a ningún lado.
Voz 3: Esto piensa que es de ningún lado. Mira, tengo de seis sitios de compro oro.
Voz 4: Ah, usted hizo el trabajo, yo no hice la tarea.
Voz 3: Y yo tengo una talita. La talita es que pesa oro.
Voz 4: Exacto.
Voz 3: Y yo lo tengo todo apuntado aquí de lo que he ido. En todos los sitios no han querido robar, por eso se llama robar. ¿Cuánto? 10 euros menos. En total le ofrecían 1000 euros menos. Eso es robar, porque sobre 9000, el 20% es un robo.
Voz 4: Esto yo creo que no, porque, mire, esto tiene un diamante aquí, un brillante, un ¿cómo se llama? Otro de esto, que usted no lo va a valorar.
Voz 3: No, cuando es pequeñito, yo soy sin oro.
Voz 4: Esto no sé si es de oro.
Voz 3: Bueno, lo probamos.
Voz 4: Yo tampoco sé si es de oro. Y cuánto pesa?
Voz 3: Lo probamos? Bueno, si con eso llegamos a los 600. 6000 dólares. Ya esto sería. Yo estoy esperando aquí por 50 euros.
Voz 4: Mira, y este reloj es de diamantes completo.
Voz 3: Pues no lo enseñes mucho para aquí amigo, te lo digo en serio.
Voz 4: Por qué? Yo tengo un número de diamantes. Pero si me lo quieren quitar, lo entrego.
Voz 3: A mí me lo he intentado quitar y mira como me dejaron la mano.
Voz 4: No, no, y si yo lo entrego.
Voz 3: No te pongas eso así. Cójate una, yo tengo.
Voz 4: No, si tengo. Pero para no llamar la atención, ¿me escuchas?
Voz 3: No es que vas aquí a y compras las pulseras estas de tenis y lo pones debajo para que no te llamen.
Voz 4: No, pero mira yo, por ejemplo.
Voz 3: Que él no lo entenderá. No se puede. Lo que pasa es que ahora hay muchos personas. Yo soy racista, pero muchos artistas, palestinos, marroquíes. Yo soy malorquín. No lo creo. Yo soy malorquín y malorquín están bien probando.
Voz 4: Quiénes también probando?
Voz 3: Bueno, malorquín. Los únicos que me han agredido y me han robado han sido paquistaníes, marroquíes, y la última vez fue un palestino que me empujó así, era bisutería.
Voz 4: A mí en Inglaterra casi me matan, nos subieron una. Yo tuve la mala suerte, casi me mataron, me dejaron botado en la calle sin conciencia, en Inglaterra, en Victoria Station.
Voz 3: Es que cuando han estado en Inglaterra. Bueno, esto fue hace 20 200 años.
Voz 4: Por qué pasa?
Voz 3: Por esto dos, porque son de oro. Eran 5007, 5008, o sea, perdón, 4007, 400. Y estoy aquí escuchando, eh. 4700 más 200.
Voz 4: No, yo estoy escuchándome, esperando lo mío, a ver.
Voz 3: 7 Qué es lo tuyo. Míralo, este me está ahí. 5000? No, imposible. Agarrar todo. Qué va, esto pesa 3 gramos, cariño. No te van a pagar, también. Esto cuánto vale? La piedra te la doy si quieres, eh.
Voz 4: No, que voy a ver. A ver si no queda ropa. Mira, ¿qué tal? Ayuda a soltar las cosas que no uso. Esto es lo que he vendido aquí.
Voz 3: Mira, es que me enteré 25 años. Tuve una novia que estaba súper enamorada de mí. Súper enamorada de mí. Bueno, lo dejamos. Escúchame! Cuando lo dejamos, estuvo dos años en. Cómo se llama? Tratamiento. Y me regaló.
Voz 4: Psicológico o tratamiento físico?
Voz 3: No, no. Tratamiento de puta.
Voz 4: Psicológico?
Voz 3: No. Psiquiátrico. Perdón, perdón. Psiquiátrico. Psiquiátrico, psiquiátrico. Coño, tomaba, yo me acuerdo, unas pastillas que me dijeron que eran malísimas Prozact, que eso es lo peor que hay. Me ha regalado una esclava, una esclava.
Voz 4: Yo he tenido una esclava de cartel.
Voz 3: Pues la vendí hace el año pasado.
Voz 4: De cartel?
Voz 3: De cartel del diez. De 14, de 14 era. Ah, no. No era de Cartier, era de 14. No era la esclava de Cartier que es. Pues yo no, yo digo. Mira, el reloj. Yo tengo mi. Me compré con mi primer sueldo.
Voz 4: Y no lo usa.
Voz 3: Joder, lo he usado por todo. Pero ¿y ahora por quién me dice que anda con eso? Coño, porque me intentaron robar y no. escúchame, yo me podría comprar otro, pero ese reloj de los 20 años ha estado conmigo en todo el mundo. Yo me toco la lotería, Y ese reloj es mi vida. Es un reloj de oro y acero de la esfera azul. Precioso. No tiene diamantes. Yo he dicho diamantes, no tiene diamantes. Es el de oro de acero. Es precioso. Es un. Mira, a mí, el guía. Esto parece. Delante de Jaime. De Galento, que era ante Calebía. Eh! Y era un melorquíde. Ahora, ahora. Le metí, le metí. Le metí y me fui y me estuvieron buscado 3 meses porque yo no soy de pega. Tú sabes que hay el collar que tiene? Pero buena bala. Claro. Ese es el mejor medicamento para que la gente no haga eso. Soy de La Vega porque casi no me dejan entrar. Me hizo así como el tío, eh, costumbre. Menos mal que el rolex tiene doble. Me hizo así tan rápido, niño. Justamente yo venía de vacaciones. Tú sabes que cuando haces gimnasia esto se hace grande. A mí me quitaba y me ponía cuando hacía mucha gimnasia, esto se hace grande, te pones. Y me acuerdo que lo tenía así. Eh! Más. Fidel, mucho, tío, saco con las bolsas. Es que ya me debía estar mirando. Tú me estabas así y me haces así, desde atrás. Y de aquí él llevaba algo, porque yo no tenía algo duro. Así, metido así y me tiro al suelo, tío, porque menos mal que el rolex. No se rompió. No, porque se rompe la sangrilla. Pero no se rompió. Pero me hizo un daño, tío. A cero. A cero bueno. Era a cero y oro. Me tiro al suelo, me hizo daño. Cuando estuvo al suelo, el tío. Yo me quedé. Tío, nunca me había pasado esto. Mira que tenía tres discotecas que habíais visto. Mira, esto es un botellazo. Pero cosas, si no te la. Espera, yo no sabía si. Y el tío intentó, cuando vio que no podía, cogió. Justamente, con un bar que sirven desayunos, había caído no sé qué y el tío resbaló. Y yo fui de tal de él, fui de tal de él, le di, le pedí una patada en la boca. Yo solamente vi. Cómo se llama? Sangre. Sangre y cosas blancas. Y salió en el periódico eso. Qué te digo? Y te digo, si me llegan a robar ese, ese, me lo voy a poder comprar otro. Pero ese es el mío de esta madre. El sentimiento, tío. Me entiendes?
Voz 4: Sí, sí, sí, yo lo entiendo. Y ahora, si como están, las cosas hay que ir con cuidado. Bueno, entonces, ¿cuánto vale la otra cosita que le doy?
Voz 3: Te sale 4.970.
Voz 4: Tú escúchame que estoy esperando unos 50 euros pero veo que no. Pero no veo 5000 5050 para pagar el parque.
Voz 3: No, nada. Espérate, pero yo no iba contento. El proyecto te interesa? Esto tendrías que venir mañana porque mi relojero gemólogo está de baja. Gemólogo? Exceptada. Sí, sí, por eso, pero es el eleguario. Sí, él está, pero mañana, te lo dirán, si puedes pasarte mañana.
Voz 4: Ya me dieron un susto ustedes con esto.
Voz 3: No, lo que he dicho, que vayas ahora aquí de Kathlon.
Voz 4: No, yo creo que para andarlo tapado, cómo voy a ver la hora y tener que hacer así.
Voz 3: Pero qué prefieres hacer así o qué te digan? No tiene que ver aprender la hora con el sol. Lo que yo te digo no es mentira, amigo, y más hoy en día, tío. Hoy en día hay gente preparada que te preparada para ver que son. No, claro, porque son estos buenos y no lo hacen los chicos, los chicos, eso. Lo se lo dicen a los grandes. Estos son tíos grandes. Lo que pasa es que aquí son tíos grandes.
Voz 4: Solo en diamantes aquí hay como 20.000 dolares en diamantes. Ellos saben. Yo tengo una cosa en Estados Unidos. Una cosa en Estados Unidos que cuando llegué a Estados Unidos me dijo. Me dijeron en la cosa más. En la bubana cuando pasas. Me dijeron "This will". Mentira, mentira. Sabes dónde me lo dijeron? Que digamos. La primera vez que estuve en el 2008 llegamos en el Bellagio.
Voz 3: Ya, las velas. Muy bonito, El Show de Luces. Yo la última vez que fui fue hace 10 años.
Voz 4: Y después ya lo veía. 2016. Como tú, como yo, que hemos visto lo mejor. Que se murió, se pudrió. Delincuencia.
Voz 3: El director del Bellagio, no sé cómo. Bueno, el Ateca es el sitio más controlado del mundo, ¿eh? Nosotros no nos dejamos una bolsa en el Rito. No pasa nada. en el Hilton. Y al día siguiente dice mi compañero. Nos llegaba una bolsa en el Hilton y me dice, uno que había estado digo que. Vamos a ir y va a estar en el mismo sitio. Y digo, que va a estar en el mismo sitio. Dice, con la posta de una ciudad y yo digo, me he puesto 200 dólares. equipo y dices, vale, muy bien, nos fuimos de allí y no pedimos nada, fuimos al sitio donde habíamos festejado para la cual, allí estaba la luz, preciosa, no habían tocado nada. Bueno, pues allí me dijeron, porque allí lo miran todo, el del Bellagio, cuando bajamos, entonces era real. Lo que lleva aquí is real or spake? The Cloud. Le vamos a dar un "save" y le recomendamos que lo de "save". Escúchame. Y ahora está, tío, ahora hay mucho cuidado. Así también? Has visto mi esto no? Qué pone? Que tengo mala leche.
Voz 4: Es un crack. Yo tengo mala leche.
Voz 3: No por qué poner. Que el café era muy bueno. Claro, lo mejor de la tienda. No has bebido el café. Por eso, no, no. Pero te lo podemos ofrecer el café.
Voz 4: No, no, no. Dame tu. Bueno, cinco mil cincuenta, vamos.
Voz 3: No, cinco mil. Y mañana tu marido va a ser feliz con esto.
Voz 4: No le des nada porque te va a regalar lo que tú ibas a vender.
Voz 3: A mí me ha regalado lo mismo. Qué te regalo esto? Me dice, me das tanto y te regalo las pulseras. Digo, no, te doy menos y te las regalo. Pero las pulseras. Para que veas. Escucha, me da. Pero este era de 18 años.
Voz 4: Sí, todo es de 18, excepto esto. Esto es un baño. Y esto no es, no vale nada, es un baño. Se lo regalas a quien quieras, al perro.
Voz 3: exactamente no vale absolutamente
Voz 4: esto me lo regalaron cuando hice mi primera comunión o sea qué
Voz 3: pero un invitado
Voz 4: no no me acuerdo solo me acuerdo de eso porque venía con esa que está ahí con ese cuadradito que está ahí pues el cuadradito sí que son
Voz 3: sí claro, y venía con esto esto no es a ver, yo aún no he puesto lo que me has puesto aquí eh aquí tienes el Santander, puedes actualizarlo ah, claro, no está puesto aquí claro, tienes que ir ahora a la libreta y está puesto tú tienes la aplicación.
Voz 4: Yo no tengo nada, el logro de traje. Yo tengo aplicación de Santa Red. Por eso, yo creo que sale el dinero directo.
Voz 3: Claro, pero él está con la libreta. Eso es de mi madre, yo no me voy a decir mentira. Lo de mi madre es de mi madre, lo mío es mío, ¿sabes? Mi madre y mi madre, digo yo, mi madre me ha venido porque mi madre la que pasa. Ayer la traje, y aquí quería que. Siempre hiciste la tarea y ya fuiste a todos lados, yo no fui a ningún lado. Mira, mi madre, que sepas que él ha ido por.
Voz 4: Yo solo confío en ti porque me. Te doy confianza, me gusta tu energía. Y eso vale más que un euro más menos. Y te digo una cosa, la primera vez que me vine aquí y vi el perro. Y vi el perro. El perro trabaja aquí y vi que trabaja. Mira, yo soy una persona que de los 5 años se me muerden los perros. Es una cosa que la gente de mi perro no lo sabe. Por qué? No me lo digas. Él te ha dado cuenta, que sí, tú le das, y sí.
Voz 3: Sí, yo lo siente.
Voz 4: Lo siente? El miedo.
Voz 3: Siente el miedo. Lo sientes cada vez que venía?
Voz 4: A mí no, porque a mí me. No te ve a ti. A mí me gusta mucho.
Voz 3: Él es un pastor Illinois.
Voz 4: Cómo? Illinois?
Voz 3: Sí, un pastor belga Illinois. Malinois. muy inteligente y cuando y cuando es muy tranquilo pero cuando se activa para estos son animas de llamar tío está entrenado para la guerra estos son K9
Voz 4: claro claro
Voz 3: los dueños tienen que entrenarlos a tope porque si no
Voz 4: está perfecto y aparte es muy amorosa muy lindo para la parada
Voz 3: ¿sí? siente la energía ¿no?
Voz 1: No, pero si alguien anda fuerte. Sí, no, él sí, otra gente está todo. Sí, pero. Antes de que ha venido, se ha levantado por otra persona, pero siempre aquí.
Voz 2: Porque sabe que tengo miedo.
Voz 1: A mí me muerden todos los vidas.
Voz 2: Yo llegué y me fue a recibir.
Voz 1: Sí, pero ¿dónde han ido después?
Voz 2: No me hace nada, pero porque yo me quedo así. Yo desde los 5 años tengo mala suerte, tío. Con los perros. Tú te ríes, pero.
Voz 1: No, pero marazote con los perros, no, marazote.
Voz 2: Sí, aquí con los seis años nos fuimos a robar cosas. Había un resto de gallinas de huevos. Cómo se llama? Una huevería. Claro. Luego un sitio que hacen que vendieron huevos para después repartir y había Dobermanes. Éramos diez chavales. A quién mordió el puta Doberman? ¿A quién mordió? ¿A mí? Bueno, aquí siempre íbamos a algún sitio que haya, puta perro pequeño que a veces, y ya me dice entonces y siempre, siempre me molesta.
Voz 1: No me lo sé, pero aquí te dejo apuntar los dos.
Voz 2: Una pregunta. Yo he ido al baño urgentemente. Pero cuidado con el perrochillo, por favor.
Voz 1: Cuenta.
Voz 2: ¿Ese?
Voz 1: Oye, el Ivan, sí. Ah, y el perro trabaja aquí. Eh, chorro. O sea, trabaja, claro. Para los que no venden oro. Para los que no... los que no aceptan nuestro precio, lo lanzamos y... y ahí aceptan, rápidamente.
Voz 2: Eso. Súper. Del Santander. Sí, cuando puedas, ahora viene un clip. ¿Cómo se llama?
Voz 1: Eye?
Voz 2: Gracias.
Voz 1: Con K, A, C. K-A-T-I Latina.
Voz 2: ¿Perdón?
Voz 1: ¿De aquí o de Chile?
Voz 2: No, de aquí.
Voz 1: Ah, es que aquí estoy en un hotel. Hotel Caballero.
Voz 2: Sí, Hotel Caballero de ahí.
Voz 1: Sí, por ahí es Campastilla, creo. Campastilla creo. ¿Así?
Voz 2: No. Cloud?
Voz 1: Ah, en Clouds. En Clouds, puse, porque en Madrid hice lo mismo, y le pregunté dónde eran los tres o cuatro lugares para ir. Y me salió este, uno que está enfrente, Piña Grau, y algo más. Y Queen Gold, ¿no? ¿Puede ser?
Voz 2: Te los muestro. Te lo muestro. Yo también uso mucho Clouder.
Voz 1: Piña Grau, Joyería Weyler, Quick Gold, Joyería Swear, ahora solo viene esta. No alcancé al resto.
Voz 2: No, no, no, vi que voy a Jaime tercero, y esta es la que me estacioné ahí donde está el cante. Este es de las ensaimadas y... me ayudó a canjar, me sale ahí, miré y dije, ah se me quiere acercar, me fui caminando. Y la verdad que...
Voz 1: ¿Y probaste la selva?
Voz 2: Sí, espectacular. Bueno, me voy ya. Me voy porque veo que el café y los 50 euros, nada.
Voz 1: ¿Quiere hacer café? Así.
Voz 2: Yo tomo un café ahora. Increíble. La Santa. La Santa es un sitio que trabajé el año pasado y este año me voy a hacer horas y como hoy empiezo con la noche ya viniendo ya con... Yo me tomo un café ahora y tengo que coger un helicóptero. Me tomo un café ahora, cojo mi coche y vamos. Cuando me llego a casa, que son los 30 kilómetros, tengo 200kg en muy casual.
Voz 1: Claro, lo podéis ir mal de chino. ¿Cómo se escribe el nombre de ella?
Voz 2: T-A-G-I-O.
Voz 1: C-I-O? Tailus! ¡Tailus! ¡Lexar es el perro! Les penetre, me acuerdo porque son palabras iguales que por aquí, penetre, penetre, ¿no? Talla. Lo ves? Bueno, lo que pasa es... y yo, yo tengo miedo ni de rozarme, que a lo mejor no haya nada.
Voz 2: Sí, pero chucha, taicha. Uy, que me he corrido ahora tan solo en Chile. Los veo por las cámaras, que los van a ver el pelo, a darle comida, para hacer. Esos perros, el baliná, a que los tenéis que tener entrenados cada día, tienen que hacer mucho deporte, ¿a que sí?
Voz 1: Yo lo sé, yo lo sé, yo he estudiado mucho. Tengo un amigo, tengo un amigo, un amigo, un amigo que empezó esto hace muchos años y ahora tiene en Manacor, es, o sea, es como se llama entrenador de perros, no es entrenador de perros y he visto un par de vídeos en su casa. Ostia, estos perros están hechos de aposta, vale, para policía, o sea, para los más, no policías normales y corrientes, no, los cuerpos superiores de todos los ejércitos de las policías no tienen miedo a nada, eso sí. Tienen que entrenar cada día, cada día, cada día.
Voz 2: ¿Por qué? Porque si no les gana al dueño.
Voz 1: Exacto. Lo dijo a mí, dice que tienes que ser una persona que se dedique. Son muy guapos y son los mejores, porque estos son muy inteligentes y hacen lo que dicen. Tienes que pasar mucho tiempo con ellos y entrenarlos mucho, porque lo necesitan ellos. Está tranquilito a tu lado, tranquilito, que ha estado abierto y estaba estaba. Ahí apareció incluso la foto de Tatya. Puse que era lo segundo mejor de la tienda después de Katia es Taiya.
Voz 2: Yo he puesto un nombre. Creo que es la primera vez que hacen fotos de tema.
Voz 1: Mira, mira, ¿cómo va? Ella va a atender ahora, ¿no?
Voz 3 (Katia): Hola, ¿qué tal? Muy bien.
Voz 2: Hola, todo yo. Me voy. Katia, un segundo. Ella, ella siempre, ella siempre va y... no sé, para decir hola a todo el mundo. No, no, pero ella siempre va y recibe a quien llega, o si tú le dices que no. No, no, ella hace lo que le dice él. Concebir que tiene miedo, se tiene aquí y no se va a saludar todo el mundo.
Voz 1: Una firmita tuya aquí, porfa.
Voz 2: Donde fui tonto yo. Sabes donde fui tonto yo? Me arrepiento. Estuve el 2009 en República Dominicana, ¿verdad? Y solo. Y allí quedé con una prima de... de la mujer. Antes de ir allí, estuve... tarjetas el juegos. Antes de ir allí, no lo conocía y llamé, a ver qué tal. Porque hay que ir allí. Un español allí, tú sabes. Es que toda la isla española.
Voz 1: No, pero un tío solo.
Voz 2: No, por eso, todos los dueños de los hoteles son españoles y las mujeres. Pero un tío solo. En el hotel, blanco, aunque vaya a hacer negocios, todo el mundo se piensa en...
Voz 1: Claro, por eso te digo, y las mujeres. Y las mujeres estaban solas.
Voz 2: Yo de eso nunca he pasado hambre. ¿Me entiendes? Yo tenía discoteca.
Voz 1: Y a lo mejor te lo digo. Y la verdad. ¿Tienes tres hijas?
Voz 2: Eh? Tenía tres discoteca.
Voz 1: Ah, tres discotecas.
Voz 2: Aquí, en la parte Ciro, sacó Macaldo. Y eso de que a los guapos no los dejaban entrar. Eso es verdad. El día que hubo un hijo, tú también levantó una vida y digo, le dije al portero, aquí guapo, ni un niño. Ay, cartón, yo soy guapo, tú cuando tengas. Y amigos ni todos que nos dejaban entrar. Acá si hay alguno que sea competencia se queda fuera. Acá solo, chica. Cuando tenía 22 años, tenía una discoteca que puta madre.
Voz 1: Te creo, y siempre los he pasado.
Voz 2: Y yo tenía dinero y da igual, pero... y por lo que le hacía. Bueno, tú ya me entiendes. Entonces me dijo que fue allí, mira, de puta madre estuve tres semanas en otras cinco estrellas, tuve suerte, tuve mucha suerte, y miro esta y con la niña. No quería aclarar a la niña, una niña pequeñita, preciosa, con el pelo más fácil, tenía igual de dos. Y yo hablando ahora le digo, mira, yo voy a estar dos semanas, Si fuera uno o fuera algo feo. Yo quiero estar que sea al Sahona. Yo sabía lo que quería. Vamos a estar juntos. Si surge algo, un poquillo de verdad. Yo aún no la tengo amigas. Yo nunca. Yo no soy guapo, pero yo te hablo sin idiomas y tengo muchas alas. Nunca he pasado.
Voz 1: El don de la palabra.
Voz 2: Y el don de otras cosas. Nunca. No sé si me dices, te muevas aquí si digo, me voy a pasar pan. Nunca he pasado hambre de eso. Y se nota en el hombre. Había que me leía y tú has pasado mal hambre, de pan. Yo nunca de eso no he pasado nunca cambio y eso era un punto muy a cambio de los nombres. Es que se nota cuando uno está tranquilo.
Voz 1: Se nota así, se nota.
Voz 2: Entonces yo quería ir ahí tranquilo y yo le digo, mira, digo, si pasa algo. Yo sé, yo he visto fotos, eso lo conté a todos. Partimos un rondaño hablando por el teléfono de la entidad. Pero hablando de esto me dice. Pero y la niña, la niña me dijo yo, no, yo vi una foto de la niña. La niña no, la niña te la tenía que traer, preciosa, tenía cinco a dos. El pelo azul, preciosa. Antes que no me lo va a servir. Bueno, la historia. Según los cinco están allí de puta madre. Fuera un poco. Pero bueno.
Voz 1: No, escúchame. Bueno, pues poco, porque la niña...
Voz 2: Ah, bueno.
Voz 1: Dos niñas. Al lado de la mala.
Voz 2: No. Era un king size, dos por dos. A ella le pusieron una camita. Pero fue muy natural todo, tío. Sí, pero más que nada chupao. Y no hace ruido. Qué buenas! No, a mí me gusta más. Es verdad. Pero esto es cosa personal, ¿no? Me voy a... Estamos en...
Voz 1: ¿Donde van todos? ¿En La Sabana?
Voz 2: Punta Cana.
Voz 1: Ah, Punta Cana! Pues yo fui La Sabona y Sabanar. Por el día, en Catamanal.
Voz 2: Por el día, sí. Nosotros estamos en Punta Cana. Que es donde está el más fuerte Bayahíbe y Punta Cana son los lugares más... Y hay gente Varadero, Varadero y Punta Cana, hay un... había un centro comercial. Esto te cuento el domingo 9.
Voz 1: ¿Manadero en Cuba? No, no. Cómo se llama?
Voz 2: Santo Domingo. Hay otra cosa que se llama... Santo Domingo, Bayahíbe, Punta Cana. ¿Qué más? Al lado, Perón. No, y está... Hay otro que también empieza con V. No recuerdo. Bueno. Punta Cana. Sí, vaya y ve. Punta Cara. Porque al lado, ahí, se llama Perón, u otro nombre también, no tan conocido, entre Punta Cara y Perón, un segundo te corto.
Voz 1: Cinco mil cincuenta, ¿no? ¡Cinco mil! Nooo.
Voz 2: Sí, no. Voy a tener que borrar el...
Voz 1: Ya los tienes en el...
Voz 2: No, aún no. Ay, con mi amor. Mi atención espectacular, Katia, muy sincera, simple, cariñosa.
Voz 3 (Katia): Ay, muchas gracias.
Voz 2: Porque este me ha dicho que soy una mala leche. Una forma de tratar mi simple grave para un vendedor sensión. Comentable para cualquier que quiera acercarse de manera siempre, alegre y entretenerme.
Voz 3 (Katia): Muchas gracias. Ay, ya, ya te sale, los 50 me lo dan en efectivo, ya tienes el dinero en la cuenta y aquí tienes la refinete de la cuenta.
Voz 2: Sí, ya puedes mirarlo, ya lo tienes.
Voz 3 (Katia): Pero ya está, tienes que hacer la declaración.
Voz 2: Él es de Chile, no tiene que hacer nada.
Voz 3 (Katia): No, pero en la cuenta tengo una cuenta aquí, pues sí, pero no.
Voz 1: Díselo por cual por 5000 euros en el mes del año. Entonces ya no trabajo aquí?
Voz 3 (Katia): No, no, no era así niña.
Voz 1: ¿Aunque no sea residente? Aquí me callo, pero tú... escúchame, yo no te voy a decir mentiras. Te has llegado. Aquí yo no conozco. Pregúntalo, ¿por qué?
Voz 2: No, si a ti te ha llegado el dinero, perfecto.
Voz 1: Pregúntalos porque te van a meter en el pago, te lo digo. Infórmate, pero pregunta a Chanchi PT.
Voz 2: O como llegué aquí con Clau. Yo le pregunto todo. Le pregunto a los 50 euros donde los retiro. Los 50 euros donde se retiran? Me quedé sin nada. Ah, bueno, con la que no era de oro. La que no es de oro. ¿De verdad le interesa? Yo le voy a hacer una foto, si quieres, envíame un WhatsApp con tu número, así yo te digo mañana.
Voz 1: Ya que me voy.
Voz 2: Ah, no, entonces nada porque me vine con eso puesto, no tenía pensado venderlo. Tengo caja de papeles, sí, pero en Chile.
Voz 1: ¿De qué año es el reloj?
Voz 2: 15 relojes.
Voz 1: No, el año, el año.
Voz 2: No, por eso creo que no sé de qué año. Ya se acordará.
Voz 1: Pero esto, no es broma lo que te he dicho, vale lo que ella te dice, pero infórmate, porque yo me he informado y si se te olvida te pegan unos pagos, además, a partir de 6.000 son 19, más de 6.000 ya se valen 25% te lo digo porque no sé yo que me metieron en un tamo más. Lo preguntas.
Voz 1: Ah, súper. Mira, yo se lo he enviado a él ahora. Eso, eso lo he empezado. Es súper bonito. Es súper bonito, sí. Y los cupos solo en Mallorca. Pero. O sea, los que me dicen que lo esconda yo. En Chile no lo uso, los cupos en Mallorca. ¿Los diamantes son aftermarket o no? Sí, es un Datejust.
Voz 2: Sí, me ha dicho after.
Voz 1: Es un Datejust comprado en Nueva York.
Voz 2: Bueno, aftermarket, todo el. Mira, creo que la.
Voz 1: Desde luego, no es raro que la gente diga que los gustos existen.
Voz 2: Sí, claro, para gustos los colores.
Voz 1: No te enfades, escúchame. Pero si no te gusta, está bien. A mí no me gusta nada este pequeño. Pero escúchame, no es nada personal.
Voz 2: No, pero a ti te gusta que sí.
Voz 1: A mí sí. A mí me lo regalan.
Voz 2: Es una. Es una forma de hablar. ¿Pero a ti te gusta mucho? O sea, en verano lo cuento de verano. No lo había visto nunca a este. ¿Te das cuenta?
Voz 1: No, no, me voy, me voy, lo siento, me voy. Caja y Paperes, lo has dicho, pero en Chile.
Voz 2: Dile que no, porque en Chile. La verdad que te miento porque no lo no lo voy a ir a buscar.
Voz 1: No, ya lo sé. Creo que tengo. A ver, yo me puedo ir por ahí, me he pagado los 50 minutos entonces una vez que a mí me da hoy me voy. Te quería decir, gracias. Eso es por. Eso es. Eh, la calona. Eso sí es por el. ¿Cómo se habla con Frentagios? Gracias. Mala leche. No, pues al final te lo he puesto yo.
Voz 2: Ya lo sé.
Voz 1: Mira, mira. Oiga, para, para, cuché. Cualquier cosa para ya. Bueno, puedes ir si quieres a los otros sitios, pero al final no entras a mí. ¿Qué cogió yo en el otro sitio? Que casi la mano ayer. Cuando vi que me ponía 118 que me había pitado 25 gramos. Casi pegó fuego a la aire.
Voz 2: Ah! ¿Te lo pesaron con trampa?
Voz 1: Yo tengo una planita. Yo lo tengo todo pesado. Una cosa es que te paguen menos y otra cosa es que ya te. No, y me quitaron por la caja, porque era un. claro, como te he dicho, una caja. caja. Y has visto que. Como la caja me quitaban 15 y casi 17 gramos por la caja. O sea, no es barbaridad, coño. ¿Y yo cuando te he quitado? Me he quitado 10. ¿Has visto? A ver, yo te quería decir una cosa, a ver, ¿tú me puedo ir a mirar? Porque ahora mi madre me va a llamar. Santander está aquí, cariño. Le quieren? Espera, déjame coger mis llaves. 50 aros y eso. No. 100 porque le faltan 50 para mí. Esta se va a acordar repito, la vida. Cuando me meta por aquí le dirá Mario: "No, vete tú". Si, si enseño en qué clase. Mira, que enseño. Eh, adiós, muchas gracias, amigo. Hasta luego. Te enseño. And then saying that here. Yeah, four. Please. There's no, you know, there you parked to be more time. Santander. Es un fenómeno este hombre, pero muy majo, muy majo. Muy simpático, es muy agradable, muy muy agradable.
Voz 2: ¿Me tienes un WhatsApp?
Voz 1: Sí, ahora mismo, espérate, voy a cojo mi teléfono y me escribo un WhatsApp.
Voz 2: Me dice más o menos cuánto quieres por él.
Voz 1: No, mira, yo te pregunté, yo te dije a ti cuánto me das por el.
Voz 2: Sí, vale, no te olvides el pasaporte. Mira que si no, yo sé que lo tengo complicado.
Voz 1: No, dime tú al revés, no hice la tarea igual que con el oro, no hice la tarea y creo que vine al lugar correcto.
Voz 2: Vale, pues mira, lo que él va ahora a mirar y yo te enviaré un WhatsApp si te va bien, espera. Déjame grabar primero tu número. Ahí estoy guardando. Yuri J-U-R-I.
Voz 1: Valestino, aunque te moleste. Vosotras soy chileno, pero mi antecesor era.
Voz 2: Sí, pero no me molesta. A mí, yo no soy nada de eso. Hay de todo el ladrón, sinvergüenza.
Voz 1: Exacto, hay franceses, hay franceses, hay de todo. De todos lados se cuecen.
Voz 2: De todo, lo que pasa es que. ¿Sabes qué pasa? Que vienen las pintas y te vienen y te. ¿Sabes qué? Pero y aquí, y aquí, y aquí. ¿Te ha pasado alto?
Voz 1: No, aquí intentaron una vez, pero como vieron a la perra. Te explico, no sabes qué hace la perra, es que la perra te avisa a ti, no se queda así, se pone así de pie y te mira con intimidación y se te queda así. Entonces el tío me dice que la perra me está mirando mal. Bueno, vaya, si quieres que te diga, allí te lo pone bien claro, hay un perro de seguridad.
Voz 2: Ah, verdad.
Voz 1: Es para protegerla, porque si mañana me pasa algo, el ladrón, si ella lo ataca.
Voz 2: Sí, lo mata.
Voz 1: Me puede venir en contra mía. Pero él podría no entrar. Y con esto me la protege.
Voz 2: Ah, claro, porque por eso él puede decir yo no entro porque hay un perro.
Voz 1: Y ella, y el tío ya se empezó a poner chulo y le digo, mira, le digo, una palabra y la perra te mata. Así que tú verás. Tú verás. Y ella empezó. ¿Sabes? Y claro, ella impresiona porque bueno, eso no es no es un perrito, ¿sabes? No, aparte que el que sabe de perros sabe que esa raza es muy tranquila, pero cuando ataca lo bueno de esta raza comparado a otros perros y que cuando le dices suelta, suelta, que otros perros no sueltan, cuando Berman no te suelta, porque tú le dices, aunque lo agarré a patar, ella le dice suelta, suelta. Bueno, pero esta adiestrada también por el jefe de policía de aquí de Palma. de la Guardia Civil y de la Policía Nacional. Estoy guardando las fotos para mandarte para que tengas los números de serie.
Voz 2: Si me escribes muy WhatsApp y por eso ahora mismo te lo escribo.
Voz 1: Te voy a dejar ahí la información que tengo.
Voz 2: Perfecto, así dame todo, así yo se lo envío a él y él me dirá.
Voz 1: Ahí va a poder ver los números de serie del reloj.
Voz 2: Perfecto, sí. Así en fin, una foto genial. Tengo esa foto. Si te fijas ahí. se puede mirar el número.
Voz 1: Sí, sí, por eso. Uno JP772. OK, con eso puede ver su originalidad. Perfecto.
Voz 2: Estamos aquí está aftermarket el brillante.
Voz 1: Por eso él me ha dicho enseguida aftermarket porque bueno, está tan acostumbrado a. Pero el reloj es original, pero lo has añadido en Estados Unidos. Muchas gracias, Nicolás.
Voz 2: Igualmente, cuando quieras y te digo cosas de reloj y así pues, si eso te vuelves a bajar. Chao.
Voz 1: Oh, gracias por venir, muy linda tú, muy cariñosa. Nos vemos mañana, por favor.
Voz 2: Exacto, si nos compras. Cuando siente la persona, yo tengo 3 y los amo, los adoro los perros. Perfecto, gracias, encantada.
Voz 1: Hoy querían comer o buscar un sitio donde. Hola, ¿dónde queda eso? El Alaska.
Voz 3: Sí, ¿cuál es ese? A la esquina de Seiya, ¿sabes cuál es Seiya?
Voz 1: No, no, pero del auto. ¿Bajaste a Juan Jaime III? A Jaime III Ya, y ahí.
Voz 3: Hasta la esquina de Seiya.
Voz 1: No sé qué es lo que es Seiya, mi amor. como si fueras a cruzar a.
Voz 3: Ah, pero por eso, baja del auto a la izquierda.
Voz 1: Ya. Fueron caminando, fueron caminando. Cómo? Aló. Perdón? Nada. Ya. Pero qué haces tú weón? Puta yo estoy en España weón. Te vas a decir que ir. voy a ir a la Segura a pedirles más información, no sé qué. ir a firme con cuánto como para no perder el día, el viaje, todo el hueveo. Si vamos y no cerramos, cuánto me cuesta la gracia? que esas 80 lucas mensuales, ¿son 80 lucas mensuales o supongo? Son menos de un millón en el año, se les va a eficientar, puta, basta con que ya las reservas se hagan automáticas sin la necesidad de esta señora que anda preguntando weas, que no tiene que preguntar porque están en una tabla, o sea, si viene un niño de tanta edad, de tantos años y con tal problema, ya está estipulado cual es el profesional que lo atiende, si todo eso está estandarizado y está en tablas de datos, en un excel, en un da lo mismo, en una data, puta es que es la eficiente van a vuelta hasta despedir a esa persona quizás, entonces no guarda relación con el costo, con el beneficio y además te va a eficientar las horas seguro porque probablemente estás perdiendo un montón de pacientes producto de de la mala gestión de la, sin querer tirarle a partir a la señora pero seguramente su gestión es muy mala. y por eso tienen el 50% de ocupación yo creería que pagando esas 80 lucas más la eficiencia en tecnología que ya estamos implementando más algunas cositas financieras que les voy aportando creería que van a tener 75% de ocupación y el nivel de eficiencia putas sobre la base actual mucho más de un 90% entonces se google trader mega paga. Mira como se marcaran a las niñas.
Persona 1: Sí, chao me dio para cotizar. Era la primera weá. Estaba cerrada, encima con citas, ya chao pico. Crucé la calle y estaba la segunda opción. Me cayeron las rajas los weones, así que. No sé. No sé, no me acuerdo hablando. Pero hice una reseña y todo, me pidieron en Google, no sé qué. Era más o menos lo que esperaba? Antes yo pensaba que era más. tenían hambre y aquí le hacemos cortizas. Es que tenemos apuro? No. Comida rápida, entonces menos pía que se vayan a aburrir, mutarse amor. Y llegaron a devorar. Claro, que la cara me la pidió sin pan, pero como te ponen el pánico esto. Pues mira que se va metiendo, lo hemos hecho guardado que se puede bailar. Creo que esto estaba por arriba de Jaime Tercero. Llegué a la esquina. Caminé hacia la derecha. Hacia el Saratoga o hacia el otro lado. Del Saratoga. Caminé hace como una cuadra. Ahí está otra. Lo han depositado en tu cuenta directa. Esto te gusta? Qué Hemi, que son de las lechas estas hamburguesas aliñadas con pimienta y a ti no te he olvidado. Preferías completo. Está rica. Usted se pida otra. Yo no quiero. No tiene nada. No queda nadie, hija. Por favor, se puede saltar bien Clara, que no tiene que andar mostrando tan galletas. Otra salchicha? Se la comió sola? y una coca-cola por favor. No se come el pan la niña. Yo creería que si habíamos algún problema ahí no eran inyectores, yo creería que hubiese sido de la parte baja, los metales, no hay inyectores, pero bueno, igual vale la pena probar todo. Mira, te puse un tarde. Muchas gracias. Por lo menos que. Que lo acompañe con algo. Parece un plato combinado. Gracias. Ah, espere, y le tengo que pagar. Mi amor, paga este lo otro. Falta pagar esto. Perdón. Sí. ya me iba tan tranquilo. Gracias. Agarra el plato? Claro, le pusieron las patitas ahí. En lugar del franquito. Para que no se vea tan pobre. Comparte las patitas. Está coja de la mesa, me botaron todo así que mejor que lo tengo así. Te quedaron bien para caminar los zapatillos o no? Pero como que la botella no te quiero mirar. Quédate sentada, no te muevas más. para probar la salchicha? Está bueno. Un poco picante, preferido David. Había un ballarquín ahí, un señor, si estás algo bueno. Soy cliente, me reí con el weón. Bueno pa' hablar conchetumadre. Bueno pero bueno pa' hablar, no paraba. La señora me quería tratar de hablar de que el weón seguía, seguía, seguía. Pero era simpático. Antonio pa' venir, ¿ah? No, también estaba vendiendo. Me dijo, yo le dije la verdad, no había ni un lugar más, así que ya me parece bien. El weón me sacó un bolso, mira, todo esto es de mi madre, que está mayor, dijo. Siete cotizaciones tengo. Esta es la mejor, no pierdas tiempo. Y saco todos los papeles, todo el agua. No po, ya había ido a todos lados. Y aquí había venido ayer con la mamá. Entonces ya vino como a cerrar. Me apoyó y ya hice el trabajo. En algunos lados me pesaron de menos, me querían estafar. En otros lados me pagaban una mierda. Al final, mira, me mostró todos los papeles. Aquí tenés, quédate aquí, no vayas a otro lugar. Dile que sí, dile que la verdad que a mí también me da paja de ir para otro lado. Así que. Súbete unos 100 euritos y cerramos en 5.000 Porque eran, no sé, 4.930. Sí po, yo le dije que te hace cerrar en 5.000 para que no. Ya si me dejas en 5.000. O sea, hasta que estén guardados en la casa ahí. Una tontera. Siete. Siete, cinco y tres. Sí. Sí, lleva un año. Siete, cinco, tres. Ella que tiene ocho horas. Tiene cinco recién cumplieron y ella cumple los cuatro. Se enseñaron por poquito todas. con ella me pasó así. Con la segunda y tercera, claro. Ya está, ya está allá. Para qué me acompaña a mí uno? No, me quedo con las mujeres. Me quedo con las mujeres, aquí tengo mi acompañante de viaje. Tiene su. Dale por tres. Estas tienen cinco y ya empezaron. Mucha moda, mucha. Claro, todos queremos todos, deseos infinitos, la señal del ser humano. Yo tengo mi pulsera nueva? Glamurosa? Con cinco mil. A mi nada, no tengo nada. No, y le dije, oye, y mañana vengo con el reloj. Mañana vengo con tiempo y no me voy a certificar con el reloj. Me dijo, son todos brillantes, todos brillantes. Está certificado, está certificado. Pero ando sin papel, sin cara, ni una weá. Porque me vine de vacaciones, no pensé en meterlo. Pero como vi que vendían relojes usados. Me dan quince mil euros, diez mil euros. Si vale más po. Te has puesto que mira, se me dan 10 mil? No, para wea. Tengo 10 más en la casa. Bueno, trata de agarrarlo. Esto deben de castigar mucho, sin café sin certificados. La caja no tanto, porque la caja tiene un valor. La caja vale. Le mostré la foto, le dije, mira. Tengo esta foto, tengo el certificado de las gemas, de todo. Pero lo tengo en Chile. La caja también la tengo en Chile, pero la caja vale lo que vale, vale 300 euros. O sea, si me dan 10 es 9.007 por la caja. Y aparte que aquí con el turismo, esta weá la paga cualquier weón, porque es como de playa, si yo al final la ocupo cuando vengo para acá nomás. Y en Chile a veces la ocupo en verano. A mi no te gusta, a mi si me gustan los cuatro bonitos? Esto los cuatro bonitos? Pero los cuatro bonitos? No, es original. Ah, eso sí po, eso. After market. O sea, el reloj es original, pero está tuneado, pero es original y los brillantes son brillantes y los diamantes son diamantes. Pero claro, vi unas deportivas enteras con piedras más chuples, 39 euros, se vende esas súper mega caras. Las tomé así, vivianitas. Si pesan mucho y caga la hueva. Claro, pero me venden cómodas y pesan poco. A ver, salió el colegio que tenía yo, de primero, de segundo, de allá, 13 años, 12 años. Te grabó de cuarto, suerte. No fue la primera de eso? También. A mí no me dijeron eso. Él está dentro del ayuntamiento. Un año, un año no es nada en la vida. cuando cumpla cuando cumpla 30 va a decir para que me estresé es mejor un año tranquilo que la por eso Ah mira viste? más valor le dio porque le costó cuando cuestan las cosas más. Vale, igual, gracias. Familia. Venezuela. Seguro. 100% Pero nada de Caracas. Cubana podría ser también, pero. Ella se levantaba así. Papá mía. Y si era cubana, no era de La Habana. Corazón, no era de La Habana. Cómo es que se siente los partes? No, si yo te dije. Aquí sí voy a ir al Sunglass Hut, que está en. Bien perrito, voy a ir al Sunglass Hut, que sí está en la esquina de Jaime que hacer ahora cuando vamos de vuelta. Pero no se dejan tomar. Porque les da miedo, no les gusta. Oye, tenían un perro guardián ahí en la joyería. Pero de verdad, un pastor belga de Malina. No, pues el hueón, tú entrai, el tiro va, ¿cachai? y empezamos a conversar sobre el perro, el perro se me echó en los pies, se me ponía así, le empezó a hacer cariño, suavecita, más rica y me decía estos huelen al tiro, a los que le tienen miedo a los perros y a los que vienen con mala vibra me dice la otra vez se le entró uno que ya el perro olía que y los perros marcan, está entrenado. No, no, y el perro marca, y yo le digo como marca, se pone al lado o qué, se sienta adelante y lo mira y no lo deja mirar al ojo y no lo deja mirar al ojo y no lo deja y no lo deja y que uno le dijo el perro me está intimidando y él dice ahí en la puerta dice que tenemos un perro de seguridad, si no le parece se puede retirar y que el weón como que se haya exaltado un poco y el perro es así. Ah, que rompes con la hugueza para la chicha. una perrita más mugrosa que la chucha, o sea te va a recibir con las orejitas abajo y todo, pero huele a algo así raro y modo guerra al toque. No conmigo cuando me fui a ir, cuando cachó que me despedí del entrenador, de él como el dueño dueño, él le da las instrucciones, me despedí de él, y cuando cachó que me despedí, se me tiró de encima, así. Para la webial, más rica la weá. Una perrita, la señora se reía. decía mira como marca la diferencia, que recién le tenía miedo, el buena onda, dice a mi me han mordido todos los perros de los 9 años, siempre un perro me muerde, recién les tiene miedo, y el perro ni lo pescaba, ni lo acercaba, ni estaba por ahí, y cuando llegué yo se me echó en la espalda. No po, el que te conté que era buena onda, y que hablaba, que hablaba, que hablaba. Pues es que lo he visto tiene franculerías a Antonio. No po, ahí en la joyería. Papá. Me gusta el perro inciano. Me hice una foto. Me gusta. Un pastor. Él es un pastor belga. Malga. Después me puedes llevar a verlo. Yo fui a. Me puedes llevar a verlo? No, porque no fue a jugar con un perrito que no. Es que yo dice en la reseña. Ahí está, ahí está. No, ahí no se ve bien en la foto. Porque me hicieron pedir, me pidieron una review, yo le puse una review, y le puse. Lo segundo mejor de la vianda es Talla, Talla es la perrita. Y la señora que me atendió, la Katia, super simpática, así como los típicos hueones de los que quería que sean así como. Tu weá vale la mierda y el resto va el. Todo lo contrato, toda la wena, simpática, cariñosa, así como relajar. Sí, pero en ningún momento me hizo sentir así como incómodo, ¿cachai? Al contrario. Yo por eso hay que no ir a ver a ningún lado. Y ahí salió el viejo, me apoyó y ahí hice el trabajo, faja y me escucha. Ya, ambos que si no se te van a devolucionar. Nos paramos, niñas. Todos los bichos que se muevan. No he quedado claro. Voy a. Subway follería. Ah, swear. No, es que había otra, esa era la que estaba cerrada, que estaba allá y parece que ahí hay otra, pero. Bueno, ya pico ya ni voy a cotizar, para qué se lleva para aquí. Se fue volando. La pulsera! Me pusieron la pulsera como yo, así? Ah no, verdad. Esta? Me quiero poner en un par de sitios. A ver. Ahora yo tengo la casa de la abuela y de ahí partiendo. Aquí a tal y va a traer chuche. Dejen las palomitas. Una paloma encina. No me importan esas ratas voladoras. Son ratas voladoras, literalmente. Sí lo son. La reta cara. Bien la falda como arrugada, mi amor. Es así. Ah, es así. Ah, pensaba que estaba arrugada. Yo también. Una joyería. Falta. Oye pero no dijiste que lo de la hora había que ir a las cuatro y media? Lo del auto por la hora? Cuando salía a comer, pues el piso. Yo te dije que hasta cuándo? Pues el máximo que eran dos euros y como hasta las seis y media. Te dije que. chiquitín como para dónde vamos? corriendo, dos, tres corriendo no ha venido nadie esperamos aquí esperamos aquí. Te gustó el bolsito? Pero no tienes nada adentro. Qué cosas puedes cargar ahí? Por ejemplo. Hay que usarlo para cargar, por ejemplo, si llevas una botella de agua, la pones ahí adentro. Al ir caminando te queda más cómodo. Si te vas a comprar algún camito de esos pequeñitos, te puedes colgar ahí. No te hagas calor que estás? Mira por donde caminas. muy arriba muy arriba acá dice que había una de esas de hawaianas ¿Te gusta? a dónde? cuando llegamos dónde está todo el 50% Ah esa es la. Sí. Dime pues explícame, no te entiendo. Espérate, Anita, que me quieres decir algo con la Clara. pero déjame ¿Qué es lo que quieres? Qué pasa con él? Sí? Y tú le quisieras dar dinero. Por qué? Pero explícame ¿Por qué? Por qué te gustaría darle dinero al señor que está ahí? Si él podría estar trabajando, por ejemplo. Si él podría estar trabajando. Si dice el bueno, bueno, eso está muy bien. Ayudar a la gente también está muy bien. Pero, y si él por ejemplo estuviera aquí limpiando las motos y se ganara un dinerito trabajando, ¿no sería mejor? O ahora si le faltara un pie, un brazo, a lo mejor. Imagínate si yo digo que le quiero comprar un bolsito de eso a mi hija y me pongo aquí, me siento y me pongo a pedir diferente. Te parecería bien? Entonces, ¿tú crees que es mejor? Dime tú la verdad, hija, lo que tú piensas. Lo que tú piensas y lo que tú sientas. Qué es lo que sientes? Qué es lo que sientes, pues? Entonces el día quiere dinero que te va a llevar ahí en una esquina y hacer así para que te lo vean. No, cierto. Cómo vas a trabajar? Claro. En vez del que dejarme en esos ratos porque es el momento cuando se le puede poner aviso. La conversación que sabe. Para lo bueno y para lo malo da lo mismo, pero para entender lo que siempre. Este señor limpiando una moto? Le puedo dar dinero? Ahí sí, claro que sí. Ahí sí, si tú lo ves limpiando una moto, trabajando, limpiando un auto. Se llama y qué? Acá está hawaiana. Ah, mira que bonita esa. Con una wea amarrar la puerta. Ah, la pista allá? No hay tanto. Tienen la misma calla, ¿no? Hola. Esta te decía yo Anita. Anita, esta es así. Muchas gracias. Parece que ve más calor pero. Elena. No lo rompas hija. No se mueve así. Ya. Qué querías hacer? Qué? Lo quieres cerrar? Y dónde vas a llevar la botella? Ah? Yo la llevo conectarse tu bolso para qué es para llevar nada. Nada po. Me pidieron cruzar el descuento acá. Ah, y también me dijeron que estaban robando mucho. Acá, no para acá. Que Nataly dijo allá donde estábamos nosotros. Acá en esta calle. Yo creería que más, en esta casa yo creería que es más la noche que. Pero eso se da cuenta o oscaradamente? No, el. En la casa de los abuelos. A tu mamá y nos vamos. cómo? yo te respondí Elena. son geniales ¿Qué pasa Clara? Qué hora es? 40 ¿El tiene sala? 6 6 Ah bueno. La muerda de tus papás ahora? Qué será el amigo, tu abuelo? Qué? Buenas luchas que grandes. Una cucaracha que hay. Pero como una cucaracha menos fea. Espera el fallero amigo de tu abuelo? Pues mira. 30% de descuento del oro ¿Será? Tiene el oro rosa. Solo blanco y amarillo. Es realmente descuento? Sí, claro. Sí, porque mi jefa se jubila. A ver, mi amor. Sí, claro. Puedo mirar un poquito? Qué sé, mira. De hombre? O solo de mi mujer? De hombre tengo alianzas? No tengo. Por cierto. Solo. Y lo que me tiene así. queda en cuarenta centímetros que es gargantilla de cuero. Tiene que ser de fuerza. Ya, ya, pero que ya no nos queda. Hemos tenido eh, lo que pasa es que con los de la liquidación se han vendido. Y desde que hay liquidación para que se jubila la dueña. Desde que realmente está liquidación en brillante. Sí? Brillante tienen? Sí, todos esos escaparates son brillantes. Y también tienen liquidación? Sí, menos el 30. A ella le gustan los brillantes? Quieres mirar? Sí, claro. Todo lo que ya queda, todo está ya en este escaparate. Ah, eso solo lo lleva ya. Y la tiendita esta? También es de la muñeca? No. Este es el negocio, la tienda. Sí, correcto, ya es lo que nos queda. Nos queda lo que hay aquí. Sí, porque ya llevamos un año y medio. Y ya es lo que queda. Bastante. Y todavía se tiene que vender todo el escaparate. Si no, no se va a dar jubilada. Si no se jubila. No, no, si no, no se jubila. Y, y el otro a la fundición, ¿no le conviene? Ya, pero como ella siempre ha trabajado de todas formas. No, no te digo, de seguir pagando el alquiler. Ya, y los gastos. Por eso. Se toma todo y lo. Ya, yo lo haría. Y más que ella tiene 77 años. Por eso te digo. Porque ella tendría estar ya descansando. Le van a pagar 70 euros el gramo y van a tener 20 kilos. Cuánto tendrá?
Doctor: Todo esto. Yo ya lo hubiera hecho.
Paciente: Es que yo haría también. Porque ella no se va a llevar nada.
Doctor: Pues esto te digo, esto se va a regular mucho. Ella con esta en bus y esta actriz con toda su vida, ¿sabes?
Paciente: Es como que no.
Doctor: Es de 40, sí.
Paciente: Sí, es que el test tuya, mira, esta es 40. Esta podría ser buena para mí, pero exactamente, para chicos sí, y no se podría. ¿Y no tienen una pulsera que sea igual?
Doctor: No, no, porque el calibre es diferente. Cambia el… Es más chiquitito que el especial.
Paciente: ¿No? ¿Cuál es la que te gusta?
Doctor: Ya. A qué te lo ponen difícil el descuento? Hasta luego, gracias.
Paciente: Gracias a vosotros, que vaya bien. Gracias. Adiós.
Paciente: Hay que conocer a la señora que se está jubilando. Porque debe tener unas riendas, están regalados y toda la vida ahí. Y yo le pregunté y le dije, ¿y esto?
Doctor: No pues yo le pregunté el locales de ella y conoceron la vida. Tenía una renta que paga buenos chauchas, por eso sigue vendiendo.
Paciente: No, te digo que no puede ceder. El contrato tú lo puedes ceder, ¿cachai? Renovar acceso. Por aquí se siente como… puede renovar la sesión D.
Doctor: Pero claro, si yo fuera la señora agarro todos los 20 o 30 kilos de oro que tienen los tiros al… agarro todas las joyas, voy a la joyería al lado y le digo mira, toma, la jubilo, a la mierda.
Paciente: Por eso te digo, entre pagar el alquiler, el sueldo, las cuentas, el contrador, declarar los impuestos, y dice que lleva un año y medio, liquidando. O sea, lo que le queda ahí es demorar 3 años en venderlo. Por eso te digo.
Paciente: Oye, ¿cómo venía un helado de fresa?
Doctor: ¿Para llevar?
Paciente: Para llevar a…
Paciente: No sé. Voy a conseguir el número de la señora para decir que cumplo toda la tienda. Al precio.
Doctor: No.
Paciente: ¿Me ha dicho? La dueña? ¿Por qué? ¿Por qué creen saber?
Paciente: Yo le diría. Oye, ¿y el auto no estaba aquí?
Doctor: Ah, bueno, yo le diría, señora, mire. El euro al kilo aquí cuesta… Aquí el euro por gramo, o sea, el gramo de oro vale 50 por poner el ejemplo. Yo le compro todo el euro que tiene, en 25, se lo pago al tipo y se fue de la mañana. Agarro, todas las weas las iba a vender y me gano. ¿O no? Me deposito 300.000 euros, se ve la chica. Y yo los transformo en 600. Aparte que esa wea, al tiempo que lo debe tener ahí, debe haber patrón.
Paciente: Voy a comprar la creatina, con el sarmiento.
Paciente: Hola.
Vendedor: Hola.
Paciente: ¿Puedes sacar una creatina? Hay una de estas que viene como en una bolsita. Hay una creatina que viene como en un pack como esto. ¿Cómo se llama?
Vendedor: Creaput.
Paciente: ¿Estas no lo tienen?
Vendedor: No.
Paciente: ¿Y esta sí?
Vendedor: Bueno, tampoco.
Paciente: ¿Cuál es la que sí? Es que yo he comprado esa aquí. Esta, esta y esta. A mí me parece que compré…
Vendedor: En bolsita no viene, creo.
Paciente: No, o sea esa, pero esa es con sabores, ¿no?
Vendedor: Claro, si no la misma marca es esta, que esta sí tiene creapure. Esta tiene 5 gramos por porción.
Paciente: Como la misma marca.
Vendedor: Cuatro nutrición, mismo nutrición. Y la diferencia es… Que esta no tiene sabor, tiene sello creapure y tiene 5 gramos por porción y esta tiene, menos.
Paciente: ¿Y esta cuánto quedan?
Vendedor: Tres, todos vienen entre tres y cinco.
Paciente: Ah, y esa seguro cinco por porción.
Vendedor: ¿Cómo? Que traen entre tres a cinco gramos por porción y esa sí trae cinco gramos.
Paciente: Sí. ¿Y cuántas pastillas son cinco gramos por porción?
Vendedor: De esas son seis, de estas son cinco.
Paciente: Ya, igual es que en general la gente toma tres gramos porque con tres gramos ya estás bien. ¿Viene con la palita?
Vendedor: Sí.
Paciente: ¿Hydroxicat tiene?
Vendedor: ¿Cómo?
Paciente: Hay un Hydroxicat, que es un quemador de grasa.
Vendedor: No. ¿Maxintek puede ser?
Paciente: No, yo creo que lo compré acá también.
Vendedor: Sí, pero de la marca Masentek. No me quedó, americanos tengo.
Paciente: ¿Pero esos son para quemar grasa o para otras cosas?
Vendedor: Sí, también son… solo me bajo. Y por ejemplo estos son dipectofías, los de abajo del todo son quema grasas. Estas son testosteronas.
Cliente 2: Hola.
Paciente: ¿Eso es en polvo?
Vendedor: Sí.
Paciente: ¿De quién mejor? ¿Polvo o la cápsula?
Vendedor: No, es lo mismo.
Paciente: ¿Y cuál recomendai tomas? Ya tomaste quema grasa, antes me hiciste. Tenía mucha cafeína, ¿te acordás, más o menos?
Paciente: Sí, pero yo tomo café, no… Sí, me da lo mismo que tengo. No me hace daño.
Vendedor: Es muy fuerte, pero si no estás acostumbrado a los estantes. La cafeína sí, más que estimulante. Esto, el estimulante es la cafeína, o taurina. Bueno, sí, tiene cafeína, taurina. Extracto de guaraná, extracto de café verde.
Paciente: No sé, ¿no será el más caro? ¿O justamente será el más caro?
Vendedor: No, hay más caros.
Paciente: ¿Y eso por qué? ¿Cuál es el motivo? ¿Por la marca solamente o porque tiene algún…?
Vendedor: Bueno, es la marca y también es muy buen producto.
Paciente: ¿Por qué?
Vendedor: La composición está bastante bien, tiene muchas cosas también, pero técnicamente igual genera mejor efecto. Bueno este por ejemplo, es que pone water shedding complex, es que también te hace cargo de líquidos.
Paciente: Ah, te ayuda un poco a la retención de líquidos.
Vendedor: O sea, tiene cositas que lo hacen mejor de hondo.
Paciente: Probemos eso entonces.
Vendedor: ¿Este?
Paciente: Probemos eso si tú me dices que es mejor. O sea es más caro y es mejor, no es que sea más caro solo porque…
Vendedor: No, no, no.
Paciente: Ya, lo que a veces es algo más caro solo por la marcha y vale. Válido, pero… Yo trato de comer… Una vez al día.
Vendedor: Perfecto.
Paciente: Una vez.
Vendedor: Me hago quemar grasa obligada.
Paciente: Sí, vale comer al menos, a veces no ayuda.
Vendedor: O sea, a mí me ayuda a quemar grasa.
Paciente: ¿Quieres una bolsa?
Vendedor: No, gracias, porque tengo los coches ahí. Tené cuidado igual con eso, porque vos para tener energía, para quemar la grasa necesitas comer pues no, no pasa energía, entonces a veces comer menos no es lo mejor.
Paciente: O sea, a mí me ayuda porque si como mucho, lo que pasa es que me aletardo.
Vendedor: Sí, quizás no sea tanto la cantidad, pero también la cantidad de veces, porque no comer una vez al día, hay que comer dos o tres.
Paciente: Me paso el día hasta las 6 o 7, y ahí como. Ahora en vacaciones distinta, pero en el año normal.
Vendedor: Ah, okay.
Paciente: Sí, todo. En el año entre el trabajo, no sé qué. Nada, al contrario. Cuando voy a almorzar, a comer, que son pocas veces, después de comer estoy como cansado, potable. Y cuando no como estoy, pero estoy hiperactivo. ¿Está okay?
Vendedor: Sí.
Paciente: Vale, gracias, chao.
Paciente: Están buenos, el agua es buena. Pero estos galletes tienen buenos, pues. Lo dejo rojo.
Paciente: Estamos en esta tienda, tiene ropa chol, así como accesorios chelos. Uno cerca de la casa de tu codo, allá del frente. Carpintero.
Paciente: Bueno no había nadie en chanje donde salgo para pedir en el iPhone. Si me conviene irme para allá. Sí. ¿O no? Me conviene para allá que pa acá.
Paciente: Aquí está la tienda. Eh. Chucho era por aquí. La tienda que viene po, esa. Oro, plata, joya de avance, relojes de vaca antigüedad, monedas, lingote. No venda nada, se hace el paso. A lo mejor tarea de cargar.
Paciente: Estaba contando cuántos éramos si almorzábamos el domingo. 15, 11, 12, 13, 14, son 14, como 15. Mis papás si no se urgen porque quieren invitar a tus papás a la casa, a comer y esto, pero ya somos muchos. Yo creo que somos 14 o 15, contando mi balance. Somos 5K, son 5 son 10, 11, 12, 11, 12, 13, 14, 10. En eso estaba. Entonces al final ya con la familia tan grande, va a estar tomando calor, incomodidad.
Paciente: Yo antes de que mi mamá se adelantara a decir nada, le dije, oye, cómo va a estar muy solo, porque, el domingo. Recién conseguí hacerla, porque no.
Paciente: Yo le dije a Tali llama tú, porque en llamadas no puedo hacer llamadas. Y cada vez que estaba con ella saltaba a buzón lleno, a buzón lleno, a buzón lleno y no se podía. Y ahora le escribí un mensaje por Instagram y me dijo que llevo días tratando de llamar para una reserva. Dicen que este es el WhatsApp de reserva de Gojoe, lo que habíamos pillado eso. Me lo acaban de confirmar.
Paciente: Podríamos vender Nexon. Nexon nos podría hacer todas las reservas de todas las horas, de toda la web. ¿Desde cuántos adultos y cuántos niños son? Cinco niños. Diez adultos, cinco niños.
Paciente: Ah, ¿y tu tía no ha ido para allá también o a qué es?
Acompañante: ¿Qué tía?
Paciente: Tu tía es tu tía? Sara.
Acompañante: Hola, otra… Ana.
Paciente: ¿No?
Acompañante: No, el sábado iremos a la playa, no sé a qué playa iremos, cualquiera.
Paciente: ¿Y la Sara?
Acompañante: La Sara, yo le llamó para confirmar mañana donde nos juntábamos, le digo, mira, yo para conocer a la niña en una cafetería o algo así, a la rápida no estoy. Creo que lo más cómodo es que vengáis vosotros al hotel, que hay espacio de sobra, podemos estar el tiempo que quieran. Si necesitas cambiar a la niña o lo que sea, subes a mi habitación y además podemos comer ahí tranquilamente.
Paciente: A su casa no te invita.
Acompañante: Se acaba de dejar la casa. A mí ni me ha preguntado, pero ni siquiera le he dicho yo nada. Y pienso que si están en gantas y todo el rollo, menos, vamos a decir. Son más raros. El perro verde.
Paciente: Bueno, voy a tener más oportunidades de sacarle la película al Juan.
Acompañante: ¿Hay más o no hay?
Paciente: De sacarle la película.
Acompañante: Sí, pero ¿cómo? Que ahí vas a tener más oportunidades porque tú apenas no has conversado nada con él.
Paciente: No, ahora.
Acompañante: Ahí después darás tus apreciaciones, si es una web o no.
Paciente: O sea, que puede ser que sea muy vivo.
Acompañante: ¿Queda muy vivo?
Paciente: Sí. Pero es que ese muy vivo son los que hacen trampa, y empezar a meter el forro. El muy hueón y el muy vivo son los problemas.
Acompañante: Bueno, yo no sé si me haría preocuparte por la sala. Tu primo Guiñe era muy vivo en su momento, que miren los forros que te metías. Esto era muy vivo, yo busco lo encontré. Vamos, porque se la llevaba astuto de que hacía plata y que no sé qué. Y mira los picos que se metieron. Pasó a lo que voy, ¿cachai? A mí por eso siempre me dio miedo a todos. Siempre encontramos que no era trigo limpio lo que hacía. Pero si se me fue muy inquieto desde pequeño, dije voy a vender esto y dije a la madre, aquí puesto una noción tal, dejar de venderlo. Que eso mal manejamos peligroso.
Paciente: Sí po, bien guiado, es lo que hablamos la otra vez con la… con el colegio. Queso bien guiado, bueno, pero.
Acompañante: Sigamos con un gran mate, ¿sí?
Paciente: Sí. Puede hacer unas actividades.
Acompañante: Sí.
Paciente: Anda hoja para practicar los números, perfecto. Yo le voy a pedir un heladito.
Acompañante: No, no la molestes.
Paciente: Yo me quería comer un heladito, pero me lo privaron.
Acompañante: Abuelita, abuelita, qué ojos más grandes tienes.
Paciente: Ya estoy papa.
Paciente: Esto no me lo vas a vender, ¿verdad? Aparte que por los diamantes siempre te hace sentir. Pero el oro es lo que vale. El resto es puro pin, perder plata. El resto es plata el hoyo.
Paciente: Aquí es, ¿no?
Acompañante: No.
Paciente: Oye, tengo entendido que la Tali me decía que el Jose tenía todas las joyas de la mamá. Que las había ido a dejar a la joyería del amigo de mi abuelo. Que las había ido a dejar allá porque como no las puede vender en ningún lado, porque no hay certificado, que se las había dejado a la joyería para ver si las puede vencer.
Acompañante: Es el más tonto, le va a meter el… vas a decir basta.
Paciente: No, pero es que es tonto, porque no necesitáis nada. Fíjate que yo se la como.
Acompañante: Por eso, lo que sea oro, vení, agarra la báscula.
Paciente: La mayoría, ella era de piedra, de piedra. Yo, pero debía tener piedras con oro, de tener harta weá de oro.
Paciente: Como si hubiera salido de la ducha.
Acompañante: ¿Qué me estás contando?
Paciente: A lo mejor en la piscina o por aquí, ¿no? Yo creo que va a estar desnudo debajo. A los dos, los dos. Como si fueran de la playa.
Acompañante: ¿Ahí lo puedes girar?
Paciente: No, no voy a girar.
Acompañante: Mi madre urgida porque las niñas te van en pijama.
Paciente: ¡Qué dios, cariño! Esta guan de muelos, ¿eh? La siguiente noche son niñas chiquitillas y nena noche. Pero era lo que el día no las acortizaba por la calle.
Acompañante: Ah, lo que digo.
Paciente: Ya tengo para esta wea, para pintarme la maquinita.
Paciente: Oiga señor, estoy muy desesperado.
Acompañante: ¿Desesperado? ¿Cómo desesperado es? Explícame eso.
Paciente: Ese señor está en calzoncillos. Oh, qué loquillo. Qué loquillo, loquillo.
Paciente: Yo me quisiera comer un bocata al paseo de San Miguel… ¿te llama? San Miguel?
Acompañante: Sí.
Paciente: Mario te dio un dato para comer pescado fresco, rico.
Acompañante: Esa me puedes decir al bocata?
Paciente: Sí, porque es helado. Es el cerca del mercado del Olivar y los Geranios, uno puede incluso comprar el pescado en el mercado del Olivar y lo llevas ahí y te lo hacen sin pantalones que estaban ahí sentados al lado del…
Acompañante: ¿Aquí?
Paciente: ¿Esos dos? ¿Ahí? ¿Los dos?
Acompañante: No.
Paciente: Estaba sentado ahí donde habíamos comido el Frankfurt caminando. Se vinieron caminando para acá.
Acompañante: Yo creo que se vinieron en bus porque vamos. Imposible. Pero tiene una guagüita y está con la madre a punto. ¿Cuánto tendría que ser?
Paciente: ¿Dos? No llevaron los dos años.
Acompañante: Yo también, por eso lo dije, porque me acordé, trabajan en el idioma, me busco la vida.
Paciente: Ya, desabróchese la que se quiera bajar conmigo aunque se desabroche, por ejemplo. Pero el papá se va a estacionar, eh.
Acompañante: Abuelita, abuelita, qué ojos grandes tienes.
Paciente: Porque si no tienes un placer es que eres un hombre.
Acompañante: Abuelita, abuelita, qué ojos…
Paciente: La polera que, mira, esta polera era, era de la tía Kai. Eso parece que la tenía del 80.
Paciente: La llave. Falta la misma por la cresta.

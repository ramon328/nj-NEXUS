---
tipo: plaud-resumen
tags: [plaud, resumen]
autor: plaud
fecha: 2026-06-17
---

# Conversación: Feria de tecnología, gastos comunes y salida al cine

# Transcripción
[Speaker 1]: Miércoles 17.
[Speaker 2]: Comenzamos un nuevo día.
[Speaker 2]: Sonda, los perros,
[Speaker 3]: A la niña.
[Speaker 1]: Hay una feria en agosto que quiero ir?
[Speaker 1]: Global IOS, más expo 26 programada para la app en China, 26/28 de agosto. Desde los modelos de idiomas más grandes LLMs, que son de inteligencia artificial, inteligencia encarnada en robótica humana, hasta RHID, Laura, Edge Computing y Paper y Juguetes, pero especialmente para ver humanoides. La industria de los humanos ahí, la weá viene, yo pensaba que en 3, 5 años, pero pero el que antes,
[Speaker 3]: Gracias, La guía aplicada a la robótica.
[Speaker 1]: Todavía van a pasar cosas frikis.
[Speaker 1]: Si Yo estaba amoroso, no tenía ni idea Todo estaba amoroso Si porque ¿cambiaron? No se quien con Comunidad Feliz era como el portal cuando se pagaba Yo tenía el pago automático Y eran no se quien los cambiaron a Sivan, Divan, no se que bueno Me aburrí de ver como pagar la wea Porque dijeron por favor, No pagan más por comunidad feliz porque cambió. Le avisa a Joaquín porque lo paga la empresa. Y como era poco automático le dije a lo demás, ya listo.
[Speaker 1]: Después apareció otro más, parece. Sabe, sabe lo que quiere. O si vale. Bueno, da lo mismo que anda. Nos aburrimos de mandar mensajes, whatsapp, llamadas, teléfonos. Ay, abrazo. Oye, me decía, weón qué hago. Le digo, bueno, esperemos a ver qué pasa porque yo pregunto en el chat y muchos preguntan lo mismo. Y anoche me escribió el Alex. Me dice, amigo como estai, oye weón, tenía una multa satánica. Chuchi, ¿por qué weón? Porque no pago los gastos comunes que me estai weando. He weado más que la mierda pa' pagar la weá y ya me aburrí po' weón, si no tengo como pagar.
[Speaker 1]: No, si mandaron un mail, chucha, me puse a buscar. Mira weón, el 10 de junio, estamos a 16, o sea, hace 6 días mandaron una weá que yo vengo pidiendo weón meses, le dije, ya pipo. Ya va joquín, le dije weón, págale toda la weá al tiro. Y si hay multas, le dije, paga todas las weas. Y ahí le contesté, le dije, para que todas las weas no quiero tener problemas. Me había llegado estos mails que me iban a cortar las weas, el gas, no sé qué.
[Speaker 1]: Ya me la tomé para la broma, pero dejé el mensaje claro.
[Speaker 1]: Ah?
[Speaker 1]: Que son los nefastos.
[Speaker 1]: No los vecinos Po.
[Speaker 6]: No, venía de antes, lo siguiente.
[Speaker 6]: Aquí.
[Speaker 1]: No pasa nada en el Watzila parece. Se quedó dormido. No, pero estuve leyendo eso también ayer. Se supone que iba a llegar ahora a comer.
[Speaker 1]: Esos eran uno de los weones que administraron, no sé que cuando hicieron el cambio, me dijeron que no pagara por comunidad feliz.
[Speaker 1]: Yo creo que las multas. Quién lo adquirió?
[Speaker 1]: Sí, porque la Alex me dijo.
[Speaker 1]: Me dijo, no, si los weones dejaron laca, acá voy a hablar con la Loreto para ver cómo lo hacemos, porque además saben que yo soy un weón que paga, no sé como dos weones en barsas que no pagan todo el año, pagan en invierno y nunca había tenido un atraso de nada porque estaba automático.
[Speaker 1]: La tengo fácil, ya tengo los hielos.
[Speaker 1]: Y las luces. Ja! Tengo los hielos, las luces.
[Speaker 2]: Buen día de sol,
[Speaker 5]: Dormir, pero ahora vamos a ir despertando. No entendí, ¿entonces el cine lo han estado ya hoy o no?
[Speaker 1]: Tu mamá dijo que el cine en la tarde, tarde, noche, seis, siete por ahí, porque ella tenía turno de mañana. Yo me acuerdo que le hablé con ella de lo del cine, que ella quería ir, no sé ni que película es, pero. Qué historia.
[Speaker 5]: Porque eso es que ahora habías visto.
[Speaker 2]: Tú, pero ya.
[Speaker 7]: Al Chisco le hacía la ilusión verla, pero claro que yo ha dicho que digo bueno, gané un poco lo que quiera la mayoría también podemos ¿Sabes? No sé a qué hora se acomoda por si queréis luego hacer otra cosa o tal.
[Speaker 1]: Vamos cuando vayan todos pues porque la suegra también quería ir.
[Speaker 7]: Sí, pero mamá tiene libre por la tarde.
[Speaker 1]: Eso por la tarde tiene libre, Sí.
[Speaker 7]: Y el chisco.
[Speaker 1]: Ella me dijo.
[Speaker 1]: Ella me dijo como a las seis siete.
[Speaker 8]: Al partido y ya.
[Speaker 7]: Lo ha.
[Speaker 1]: Pasado, y era la seis.
[Speaker 7]: Después de.
[Speaker 9]: La sede. Ahí, si tienes que cenar algo de eso, están medio. Al menos los míos, no sé las vuestras como llevan el ritmo del sueño y salirse a despertar.
[Speaker 1]: A las doce de la noche no se dormían.
[Speaker 9]: Joder, madre mía,
[Speaker 5]: Es que se activan.
[Speaker 9]: Pero Eso es porque también les deben de haber algún azúcar,
[Speaker 1]: Porque el azúcar activa. No, azúcar, azúcar no le vimos cocaína no más, tú no.
[Speaker 7]: No se casa lo que me digáis.
[Speaker 7]: Espera. Story.
[Speaker 1]: Yo estoy más enfermo, yo me quedé trabajando hasta las cuatro y media.
[Speaker 5]: Trabajando hasta las cuatro y media. La siguiente sesión. Cómo se despierta ahora? Es que aunque se va a matar con el coche sin coger coche. La siguiente sesión es a las 19:40.
[Speaker 7]: A las 10?
[Speaker 5]: 19:40.
[Speaker 7]: Diecinueve cuarenta y uno de tarde, ya son las ocho. Por eso.
[Speaker 1]: Ya, Ya antes de eso.
[Speaker 8]: Las seis y cinco.
[Speaker 1]: A veces pedirle al chico que vuele del trabajo.
[Speaker 8]: Sí, tendría que ser las seis y cinco. Tendría que ser la de las seis y cinco.
[Speaker 8]: Yo creo.
[Speaker 1]: Supongo que está en la, Supongo que estás en la calle porque estoy poniéndole la placa a tu súper teléfono, ¿No?
[Speaker 1]: Supongo que estás en la calle que te fuiste a ponerle la placa al súper teléfono, ¿No?
[Speaker 10]: Sí, O sea, yo tengo en tu casa no la ponen.
[Speaker 5]: Está disponible la fila 7, es muy cerca. O sea que está todo muy lleno ya, ¿verdad?
[Speaker 5]: Te mando un pantallazo, mira. Yo creo que tiene que ser la fila 7.
[Speaker 1]: Somos 10, si es que no va Juanma, si va la Andreita somos 11, chúpala entonces, si va Juanma. No va a ir. Somos tiempos?
[Speaker 5]: No va a ir porque tiene trabajo, entreno, dijo que fuéramos no más.
[Speaker 5]: Ahí te va.
[Speaker 1]: Puedes compartir pantallas ahí.
[Speaker 7]: Cualquiera aguanta mamá, ya te lo digo, como sea muy alante. Eso puede ser lo peor.
[Speaker 1]: Te aparece a ti el ¿Has.
[Speaker 5]: Visto lo que te he mandado o no?
[Speaker 10]: A ver.
[Speaker 1]: Ay.
[Speaker 1]: Dónde sale?
[Speaker 7]: Las siete.
[Speaker 7]: Sí. Claro, esa estaría bien, ¿no? Las siete.
[Speaker 1]: Cómo no hay a las seis? Sí. Ah, da lo mismo, la que sea.
[Speaker 1]: Somos diez entonces.
[Speaker 10]: Ya te lo.
[Speaker 1]: Digo eh. No, pues tu papá seríamos Once.
[Speaker 10]: Pero yo no creo. Hola Enrique, ¿qué tal? Buen día.
[Speaker 9]: No sé, son 5 niños, cuatro, 5 adultos, no somos 10, claro.
[Speaker 9]: Buenas matemáticas, Sí.
[Speaker 1]: Los números son los míos.
[Speaker 5]: Tengo la de dedito de aquí, espera.
[Speaker 5]: Ahí tengo los cinco niños, dos, cuatro, cinco. Y luego dos.
[Speaker 10]: Parejas y mamá.
[Speaker 1]: Cinco adultos?
[Speaker 9]: Claro, somos diez.
[Speaker 9]: Sí, por favor, Enrique, gracias.
[Speaker 11]: Porque puedo elegir en qué trabajar y con quién trabajar y nada, un consejo.
[Speaker 10]: Y un 17,
[Speaker 5]: 17, o sea, así en la tarde son las cuatro.
[Speaker 11]: Yo llevo programando desde muy pequeño y hay años de proyectos que nunca, Nadie usó, cierto, proyectos que nunca se rentabilizaron, nunca gané plata o nunca logré armar una empresa de un proyecto.
[Speaker 11]: Pero que finalmente hoy en día siento que después de.
[Speaker 10]: Bueno, me alegro que se haya recuperado.
[Speaker 11]: Años y años de lideración, algo le estoy agarrando más la mano. Salgo a Dubai, ahora vendré, porque puedo ajustarme.
[Speaker 12]: Con inversionista. Vamos, dime.
[Speaker 3]: No lo tengo idea.
[Speaker 3]: Será esa es la cuenta? No, es de la cuenta.
[Speaker 12]: Es la tarjeta?
[Speaker 3]: No sé cómo saber la tarjeta. Aquí.
[Speaker 3]: De hecho.
[Speaker 3]: Dime. Espérate por estar cargando.
[Speaker 5]: Hola? Ya estoy papá. Espera, no estoy comprando, no me va a dictar ni colar los números.
[Speaker 3]: Sí, te los cookies y pego mejor. Cookies y pega.
[Speaker 3]: 954 89 0103 8306 3441.
[Speaker 5]: Caducidad 0631 0631 755.
[Speaker 3]: A ver si me deja Yo.
[Speaker 7]: Me acuerdo que no el año pasado, Por eso no las cojo yo rápido a las siete.
[Speaker 1]: Uff qué calor. Aquí me apareció una operación, eran cuarenta y algo.
[Speaker 5]: 43 está listo.
[Speaker 1]: Aquí me pidió la. Es que aquí no te funciona porque me llega a mí una solicitud de aprobación. Y a lo mejor alguna vez lo hiciste así y no avisaste. Este es como el Santander Pass.
[Speaker 1]: Que lo tengo que aprobar.
[Speaker 5]: Botinax localizador, añadirás.
[Speaker 5]: Ya lo tengo, ¿eh? Hay que avisarle a. Has avisado.
[Speaker 9]: A Nicolás que me pasó ayer que no le pase a él?
[Speaker 5]: No, ahora. Natalí cuando se fue ayer para sus cosas se encontró con una multa en el auto. Aquí. Por haber aparcado.
[Speaker 1]: Aquí.
[Speaker 5]: En Sentido contrario al.
[Speaker 1]: Ah, no, yo siempre me doy la vuelta, me doy la paja y me pongo mirando. Si la wea, me pongo por el lado de allá, me doy la paja. Lo pongo mirando cuando me toca.
[Speaker 1]: Pero por cállate mucho.
[Speaker 10]: El Problema es que yo no tenía ni idea.
[Speaker 1]: No, pero si hay un montón de gente que se pone pal otro lado.
[Speaker 1]: No, no, hay un montón de gente que se pone en el carril del frente mirando hacia el lado contrario, yo lo he visto.
[Speaker 1]: O sea, ayer se.
[Speaker 1]: Ayer se hicieron unos 10.000 euros.
[Speaker 4]: Empresarios que tienen muchas empresas de fondo tú.
[Speaker 1]: Lo estacionaste ayer.
[Speaker 11]: Y además, muchos me han preguntado de mis tratas de trabajo, yo personalmente uso contactor la terminal directamente y Cloud Code. Esto de acá, que creo que alguien lo tiró como talla, pero vamos a empezar a regalar MacBook Pro o MacBook en general de. Sí, espera, espera un poquito.
[Speaker 10]: Esto son a las 6:05.
[Speaker 11]: En el fondo, a nosotros nos queda corto porque reventamos los computadores con terminales, necesitamos mucho RAM, pero son MacBooks que funcionan perfectamente. O sea, que yo creo que para cualquier persona funciona. Y voy a hacer una poligación al respecto, porque queremos que lleguen a las personas que realmente pueden dar un salto cuántico en sus ideas, justamente por tener acceso a MacBooks, que en el punto de la programación yo creo que algo súper relevante.
[Speaker 12]: Déjame ver con Nicolás.
[Speaker 11]: Una de las capacidades principales, yo creo, hoy en día para aprender, es saber preguntar en Google, o Cloud mismo. Yo, para las personas que no son técnicas, lo que haría es, describiría CharGML, les describiría a qué se dedican hoy en día. Tengo un negocio de esto, agua.
[Speaker 2]: Quiero empezar a.
[Speaker 4]: El mandamiento más Años.
[Speaker 2]: En diciembre, la pregunta.
[Speaker 9]: Buenas cabros como están oye les vine a contar un out.
[Speaker 11]: Chita estoy vienen todos weon encuentro esta auto esta otra RZ R86 esta wea es de la casa de un Mustang GTD supongo y hay uno de la U esta wea es como la Ferrari supongo, si la Ferrari.
[Speaker 8]: Y necesariamente en este azul perlado.
[Speaker 11]: Oye por dos, por dos lucas.
[Speaker 7]: Porque el amor de papá merece un regalo a su altura.
[Speaker 2]: Por eso. Este robot despaletizado con.
[Speaker 4]: Si estás.
[Speaker 4]: Ya pueden.
[Speaker 1]: Despertarse, Chupito, ya se.
[Speaker 12]: Pueden despertar.
[Speaker 12]: Entonces algo.
[Speaker 1]: Que tenemos sino para tarde.
[Speaker 1]: Entonces es que quedaron pequeñas, ponemos la diferencia de unos Lego para Nicole.
[Speaker 2]: Y qué más?
[Speaker 1]: Yo quiero ir a tres joyerías a llevar traje toda mi igual de oro.
[Speaker 6]: Bueno, la verdad ya no la metí en el saco.
[Speaker 1]: Pero eso no es la cúpula weon.
[Speaker 2]: Ya tengo.
[Speaker 1]: Como que tengo cuatro compañerías, como en dos clavos.
[Speaker 1]: Igual voy a ir a Piña Grau, que no me conoce.
[Speaker 1]: Porque cuando lo hice el año pasado, cuando fui ahí en Madrid a vender una mesa grande. También lo hice así con Gepepeque en Maragón. Y ahí efectivamente también. Lo que pasa es que te pagan mucho de mano porque lo fundan. Usted me dio la Estrategia.
[Speaker 1]: El primero para a 2 weas, uno en primer tercero.
[Speaker 1]: Le puse que Piñegreón me conocía, me sabia que tenia esta renta hecha en Noviembre del año pasado. Y me dijo que bueno, que me conocieron y que tuviera esa renta recién hecha me servia como negociación porque no me filo. Porque ahora esta mas caro que lo mismo. Te pagan menos lo mismo por gramo.
[Speaker 3]: Okay, that's some mothering wood.
[Speaker 1]: Pero así como veo la cosa, parece que pongo mis cosas y los invito.
[Speaker 6]: De qué? Parece que me pongo la ropa y me desaparezco.
[Speaker 1]: Entiendo como estoy en el infierno.
[Speaker 1]: Que tú decís, aquí no me quedo como si fuera una posible, Así.
[Speaker 2]: Ahí está bien las cositas.
[Speaker 1]: El sol?
[Speaker 13]: El lindo día.
[Speaker 1]: Adiós el sol lo voy a bajar porque si no.
[Speaker 5]: Lo quieren salir del acá abajo porque.
[Speaker 1]: Se está acabando dixiewixy araña!
[Speaker 1]: Pero, pupu, pupu, pupu, tu, tu, tu, tu, tu,
[Speaker 6]: Tu, tu, tu. Ahí está, no se despierta.
[Speaker 1]: Gonara, este, tu, tu, tu, miren las arañitas, a como ve este culito, este culito, culito, este culito, culito, esta aguadita más rica, esta canchica esta rica, este culito, culito, esta aguadita de limón, Y esta otra de Mowgli, ohh mi mamá que comí un mowgli, todos se cambiaron de camita, las facubitas.
[Speaker 1]: Estas manitas tan ricas, de que son, de quien sale estas manitas tan ricas?
[Speaker 1]: De quien sale tan bonitas tan ricas? De un mowgli. De un mowglito tan bonito, de un monito que se parece a moglito.
[Speaker 1]: Un libro de la celda me parece móvil. Es que no eres llevar el moglito, eres un moglito.
[Speaker 14]: Este es un moglito, como monito.
[Speaker 14]: Oye, ¿Qué te pasa? Qué te pasa?
[Speaker 14]: Para allá.
[Speaker 1]: Cómo que para allá?
[Speaker 1]: Y este culito rico, mira este culito rico. Y esta patita rica, de la vaca china, de la vaca, chiqui, chi, ta. Quién quiere ir a ver todavía estoy en el cine hoy?
[Speaker 1]: Ya compramos las entradas.
[Speaker 1]: Quién quiere darte el historio ahí?
[Speaker 1]: Yo no.
[Speaker 14]: Tú no,
[Speaker 1]: Deja eso.
[Speaker 1]: La babaica no va por llorona, la clana no va por gritona, y la Nicole no va por mamona.
[Speaker 14]: Pero qué? Si me quedé en esta cama toda la noche.
[Speaker 1]: Ah bueno, mexicana. No. Saluda como mexicana.
[Speaker 6]: No. Ándale, órale voy. A full. A donde ha llegado, ese me ha llegado, ese mexicano, ese mexicano,
[Speaker 1]: Chiquitito, mexicano, chiquitito, mexicano, chiquitito, chiquitito.
[Speaker 14]: Tan, tan.
[Speaker 1]: Bueno. Se levantan estos puletes serían vistas? Déjate chuparte para ver niña! Y tú déjate de dormir, oye. Déjate dormir, déjate dormir, déjate dormir. Oye, déjate de dormir. La parte de dormir,
[Speaker 14]: La parte de dormir, la parte de dormir, la parte de dormir, la parte de dormir, pa todo dormir.
[Speaker 1]: Tin, tin, cantar, tin, tin, cantar.
[Speaker 1]: Tin, tin, tin, suavecito ese culito.
[Speaker 14]: El culete, así, tin.
[Speaker 1]: Bueno, la que no se levanta lo va a pedir cuello.
[Speaker 1]: La que no se levanta, no ve toda historia.
[Speaker 1]: Ah? Ha visto los ojos ahora? Muñequita. La que no abre los ojos y se mueve el culo, no ve toda historia.
[Speaker 14]: Y se la Llevó.
[Speaker 1]: Se sabe esa canción solo sabe la Clari?
[Speaker 14]: Otro día volverás Así Es.
[Speaker 14]: Ay no.
[Speaker 14]: Y no la salió y se la llevó.
[Speaker 1]: Otra vez.
[Speaker 14]: Deja la chica hasta los veo te voy a llevar a la playa esa ¿Eh?
[Speaker 1]: Mango dedo vitamina te voy a llevar a esa playa mango dedo vitamina, dedo de clara, chiqueteado, con baba.
[Speaker 14]: Sí papá, es una papá, en el culo en la cama qué?
[Speaker 2]: Qué pasa.
[Speaker 1]: Angelita de Dios?
[Speaker 1]: Sí.
[Speaker 1]: Un besito.
[Speaker 14]: Zapote Culo de papote.
[Speaker 14]: Qué te Pasa?
[Speaker 1]: Mexicana. Qué te pasa mexicana?
[Speaker 1]: México lindo y querido, dijo la mexicana. Nicole Yuri Palma.
[Speaker 1]: Ándale cuate.
[Speaker 1]: Ánda! ¡Órale güey!
[Speaker 1]: Ándale Mi chica note!
[Speaker 6]: Voy a chavar el tráiler excesivamente a si tiene más culochera. Era poner así completo con las camisetas así como el.
[Speaker 13]: Vamos ni las perdidas, me voy a desayunar con papito.
[Speaker 13]: Tenemos el bar para Toy Story en la tarde. Sí. Con los primos.
[Speaker 5]: Y eso les digo que incluye.
[Speaker 5]: Les digo que incluye eso. A los abuelos.
[Speaker 5]: La abuela, si el abuelo no le digo que incluye la entrada del cine.
[Speaker 5]: Chucherías.
[Speaker 13]: Y por qué no viene la abuela? La abuela viene. El abuelo luego que no la quiere ver.
[Speaker 2]: El Abuelo es.
[Speaker 2]: I don't know.
[Speaker 5]: Niñas, ilítanse, por favor, no las vamos a esperar.
[Speaker 14]: Mamá, mi mamá. Qué tanta prisa?
[Speaker 14]: Porque se va el día y el desayuno.
[Speaker 4]: Buenos días.
[Speaker 14]: Contesté, ahora lo busco.
[Speaker 2]: Shut up.
[Speaker 2]: Cuando termine.
[Speaker 14]: De hacer lo que estoy haciendo.
[Speaker 13]: Muy bien, la cara, la de col. Vamos, mar, que ni de la cama se mueve, María.
[Speaker 13]: Yo no me.
[Speaker 1]: Levanto ahora,
[Speaker 4]: La llevas a Tirar?
[Speaker 6]: No. Soltadme, no la voy a Soltar.
[Speaker 6]: Sí, sí o no? Sí o no? Gracias papá.
[Speaker 13]: Ese hizo hasta por allá.
[Speaker 13]: Oigan tienen cantidad de ropa ¿No?
[Speaker 1]: Me dejaste el cable es que yo te dije que era para cargar el reloj. Ahí donde me llegó. No, no estamos.
[Speaker 1]: No me dijiste y este cable lo tenías que hacer para cambiar el reloj, de eso lo vi.
[Speaker 1]: Ya. Otro cable más que yo.
[Speaker 2]: Oye, Neto, mira, ¿y ese tiene el cable?
[Speaker 13]: Ven, como de las cosas.
[Speaker 6]: Es que tenía que se rompiera las cositas de arriba.
[Speaker 6]: Sí.
[Speaker 1]: Cuando se te acabe.
[Speaker 5]: Creo que tiene uno puesto, pero se lo voy a sacar y voy a poner este.
[Speaker 14]: Vamos A Sacar.
[Speaker 13]: Estos.
[Speaker 13]: Aquí están. Ahí los tienen. Ahora déjame vestirme. Cuándo ya prevista que vestir a ti?
[Speaker 14]: Esto es el final ahí tenido 120 ml en formato que tiene.
[Speaker 6]: Déjate de repetir, te lo van a buscar cuando lo vamos a hacer.
[Speaker 13]: No, Que uno quien se iba al entreno. Quién se iba al entreno?
[Speaker 13]: Qué polera quieres? A ver el culito no sé hija si ya la usaste pero ya está ella no la puede volver a poner.
[Speaker 14]: A ver, yo no tengo la.
[Speaker 13]: Embestida De cualquier mamá. Tú te llevas Clara? Está limpia esa? Bien.
[Speaker 14]: Mamá, Entonces pongo la cara, no la entusias y no me dejas ocuparla.
[Speaker 14]: Ahí está.
[Speaker 2]: La usó Ayer,
[Speaker 13]: Lareda la usó ayer también. Quién la usó ayer?
[Speaker 13]: Tú con? Clarita, ven estás, Claras. Hola. De dónde sacaste esa? Del closet, ¿cierto? La sacaste del closet. Del closet. No sabes de qué dijo entonces? Tú la usaste ayer?
[Speaker 13]: Y quién la ocupó ayer entonces?
[Speaker 13]: Aquí está la tuya, hija. Era cinco o seis.
[Speaker 13]: Toma, déjame vestirme y no me interrumpas más con esa voz penetrante, por favor.
[Speaker 13]: Ponte La ropa ya.
[Speaker 13]: No la vamos a esperar. No te vamos a esperar.
[Speaker 13]: Por si acaso te lo crees, no te vamos a esperar. En la brocha, en la brocha.
[Speaker 14]: Yo no he peinado el estado. Porque ya tenía peinado.
[Speaker 5]: En el desayuno no van a comer nada con chocolate, por si acaso. Sí.
[Speaker 14]: No. Yo sí, porque en el desayuno nunca comí chocolate.
[Speaker 14]: Clara va con brocha. Me pasé un día a comer el chocolate y yo no. Sí. Es verdad. Es verdad, Clara. Que ya comí yo chocolate, con mi alcohol, pero.
[Speaker 14]: Pero comí yo.
[Speaker 14]: Pero comí chocolate y la capa.
[Speaker 14]: Me dejó papi.
[Speaker 13]: Por fin! tenía que hacer así aplastado.
[Speaker 14]: De mi ropa porque los robaron dos dos.
[Speaker 14]: Pero me he comprado para el viaje de una ropa linda.
[Speaker 14]: Solo Les Falta la.
[Speaker 14]: Quiero que quiero que me sujetes.
[Speaker 13]: Elenita Estas chalitas o no o cuáles?
[Speaker 1]: Pero suéltate, suéltate el niño te lo hago.
[Speaker 5]: La niña no tiene que andar mostrando la guatita. Se ve feo?
[Speaker 5]: Sí, se ve feo.
[Speaker 6]: Maticularmente.
[Speaker 5]: Quiero que me hagas.
[Speaker 12]: Como la Clara.
[Speaker 1]: Quiero dos chaletas como la Clara.
[Speaker 6]: Ella me lo pidió, pues.
[Speaker 1]: Déjale que se dé ridículo.
[Speaker 13]: Hay cantidad de ropa, yo no voy a hacer inventos todos los días ya.
[Speaker 5]: Y nos vamos a la playa ahora.
[Speaker 13]: Están Esperando algo aquí entonces? Sí. Qué nos ha parado entonces? Eh?
[Speaker 14]: Pues Adivina. Ponte los zapatos, los pelos.
[Speaker 14]: Mi fondo de pantalla. De Mario Bros.
[Speaker 3]: De los de.
[Speaker 1]: Los autos. No, no.
[Speaker 13]: Y que buen humor todos, ¿eh? Recuerden que dije el papá. Papá, ¿sabes qué hora es? De qué es?
[Speaker 14]: A mi amor. Y qué están esperando aquí?
[Speaker 13]: Qué quieres?
[Speaker 13]: Avanza.
[Speaker 1]: Estamos con el buen humor por casa.
[Speaker 14]: Cuál es mi fondo de pantalla ahora? Que le estoy diciendo.
[Speaker 1]: Estoy hablándole con las weas.
[Speaker 14]: Papá, ahora de que es hijo de papá.
[Speaker 14]: Es muy lindo y muy triste y muy lluvioso.
[Speaker 14]: De qué es? Qué cosa ahí? Mi fondo de pantalla. Una pantalla triste y triste y muy lluviosa y muy tierna el.
[Speaker 1]: Cuál será, cuál será?
[Speaker 14]: Te rindes?
[Speaker 14]: Te rindes papá? No Cállate ya te lo muestro.
[Speaker 1]: El del osito? El del osito viste?
[Speaker 1]: El del osito.
[Speaker 1]: El Del osito osito regalo.
[Speaker 14]: Ya lo cambié en el fondo es de color rosado y.
[Speaker 14]: Me haces una coleta entera? Bueno.
[Speaker 14]: Me haces una coleta entera. Es algo que me gusta mucho. Gato dije. Déjame, a ti no te dije. Es algo que me gusta mucho. Es el gato. Y es muy peludito.
[Speaker 1]: Un gatito precioso.
[Speaker 1]: Algo que te gusta mucho y que es peludito y que hace miau ¿no?
[Speaker 14]: Y por qué no dijiste caballo?
[Speaker 1]: Ah bueno, tienes razón También.
[Speaker 14]: Me gusta Si,
[Speaker 1]: Y es peludito Y muy cariñoso Tienes razón Tienes razón hija Un.
[Speaker 14]: Poquito salvaje Te digo porque te lo curas de algo, Accidente de caballo que te pasó? A ver, sí, con un caballo y la llevé.
[HARDWARE]: Hubo un recuerdo de un accidente de caballo que le pasó a una persona.
# Resumen
La jornada del miércoles 17 de junio de 2026 comienza con una conversación sobre diversos temas. Uno de los interlocutores (Speaker 1) menciona su interés en asistir a una feria de tecnología en China en agosto para ver avances en robótica humanoide e inteligencia artificial. Este mismo hablante relata un problema administrativo con el pago de los gastos comunes de su comunidad, que cambió de portal de pago de "Comunidad Feliz" a "Sivan". La falta de comunicación clara resultó en una "multa satánica" por impago, a pesar de sus intentos por regularizar la situación. Se entera del problema por un amigo y procede a pagar todo lo adeudado para evitar mayores inconvenientes.
Paralelamente, el grupo familiar planifica una salida al cine para ver "Toy Story" por la tarde. La conversación se centra en coordinar los horarios de todos, incluyendo a la madre que tiene turno de mañana y al "Chisco" que sale del trabajo. Calculan que son un grupo de diez personas (cinco niños y cinco adultos) y debaten sobre la mejor hora, decidiéndose por la función de las 18:05. Se realiza la compra de las entradas en línea, superando una dificultad con la aprobación del pago, que requería una autorización a través de una aplicación similar al "Santander Pass". El coste total de las entradas fue de 43 euros.
A lo largo de la mañana, se entrelazan conversaciones domésticas. Se habla de una multa de tráfico recibida el día anterior, 16 de junio de 2026, por aparcar en sentido contrario. Mientras los adultos organizan el día, interactúan con los niños, despertándolos de manera juguetona, discutiendo sobre la ropa que se van a poner y gestionando sus peticiones para el desayuno, advirtiéndoles que no coman chocolate. <mark style="background-color: #F9EDD4">Una niña recuerda un accidente que alguien tuvo con un caballo, destacándose este recuerdo en la conversación.</mark> Otros temas que surgen incluyen planes de uno de los hablantes para ir a joyerías a vender oro y la intención de otro de regalar MacBooks que ya no utilizan para sus proyectos de programación.

---
tipo: analisis
tags: [plaud, reuniones, analisis, negocio]
mes: 2026-06
---

# Análisis de reuniones (Plaud · 2026-06)

> Destilado por Nexus de las transcripciones crudas (solo lo de negocio). Ver [[40 — Proyectos]].


### 2026-06-17 · Frustración en Sociedad de Negocios + Uso de PLAUS

**Resumen:** Socia expresa agotamiento por carga de trabajo desigual y falta de iniciativa de su compañera. Se considera incorporar un tercer socio como mediador/validador. Además, se registra uso de dispositivo PLAUS para documentar vida diaria en proyecto laboral.

**Decisiones:**
— Evaluar incorporación de tercer socio para mediar y reactivar compromiso de compañera.
— Continuar documentando con PLAUS para proyecto de trabajo.

**Pendientes:**
— Resolver ritmo de trabajo desigual en la sociedad.
— Definir alcance y responsabilidades del posible tercer socio.

**Para Nexus (implementar):**
— Revisar si PLAUS es herramienta corporativa; si no, considerar plataforma de captura/documentación de inteligencia de negocio.
— Crear sistema de seguimiento de tareas/iniciativas para sociedad (validación de cumplimientos, alertas de retrasos).

**Personas/temas:**
— Socia principal (frustrada, sin vacaciones, siente carga principal).
— Compañera de negocio (ritmo de trabajo lento, falta de iniciativa).
— Posible tercer socio (rol mediador/validador).
— Dispositivo: PLAUS (grabación documentación laboral).

---

### 2026-06-17 · Reunión de Tecnología: Scraping, API Reservo y Gestión de Agenda

**Resumen:** Reunión técnica enfocada en soluciones de integración con plataforma Reservo para extracción de datos de agendamiento, reportes de ocupación profesional y gestión de citas. Se evalúa opción de scraping vs API estable. Pendientes administrativos: convenios con profesionales, validación bancaria y contratación de prevencionista de riesgos.

**Decisiones:**
— Avanzar con investigación de scraping en página Reservo como alternativa inmediata.
— Evaluar upgrade a plan Enterprise de Reservo (habilita API) vs solución económica alternativa.
— Ramón trabajará en extracción de datos de citas por box y estado (sin necesidad de API si es posible).
— Implementar tabla en plataforma con filtros: box, estado de cita, total de citas por box (meta: esta semana).
— Revisar convenios laborales con profesionales (plazo: próxima semana).
— Contactar a Prevencionista de Riesgos (HN/Impomil) para inspección (coordinación vía hermano de participante, pago separado).
— Hacer pre-cierre de comisiones a fin de mes con profesionales que se van de vacaciones.

**Pendientes:**
— Ramón: Evaluar scraping y reportar viabilidad/costos de API estable (Reservo u alternativa).
— Ramón: Implementar reporte de ocupación profesional (profesionales <15%, 15-50%, >50% ocupación) — esta semana.
— Hernán (legal): Revisar/modificar convenios (entrega documentos: próxima semana).
— Contacto bancario: Enviar flujo de caja y datos de tasación a bancos (correo ya preparado, faltan datos Vani Santander).
— Confirmar con Reservo upgrade a plan Enterprise y fecha de disponibilidad.
— Cari: Pre-cierre de reportes (comisiones, estado citas).

**Para Nexus (implementar):**
— Desarrollar módulo de scraping automático para Reservo.cl si no se obtiene API (autenticación + extracción de datos de citas y disponibilidad).
— Crear dashboard con estadísticas: ocupación por profesional (rangos %), citas por box y estado (atendidas/suspendidas/confirmadas).
— Integración API Reservo cuando esté disponible (plan Enterprise).
— Automatizar descarga de reportes mensuales sin descarga manual por box.

**Personas/temas:**
— **Ramón:** Responsable desarrollo técnico, scraping/API, reportes automatizados.
— **Nico:** Participante, validación de procesos.
— **Hernán:** Aspectos legales, convenios laborales.
— **Cari:** Descarga/validación de datos mensuales.
— **Prevencionista de Riesgos (HN/Impomil):** Coordinación vía hermano de participante.
— **Plataforma:** Reservo.cl (agendamiento), necesidad de integración API para eficiencia.
— **Temas clave:** Scraping vs API, plan Enterprise, convenios renovados, comisiones profesionales, inspección de riesgos.

---

### 2026-06-18 · Problemas técnicos Ailnest y baneo Chileautos

**Resumen:** La plataforma Ailnest solicita repetidamente agregar correo (impidiendo acceso y nueva cuenta). Al usar la función de visita a Chileautos desde Ailnest, el usuario es baneado por Chileautos al hacer clic en "visitar la página".

**Decisiones:**
— Investigar si el baneo es por VPN o por patrón de scrapping detectado en los clics.
— Re-vincular correos en Ailnest para diagnosticar desincronización.

**Pendientes:**
— Speaker 3: Extender duración de sesión en Ailnest para evitar re-ingreso constante de credenciales.
— Speaker 3: Revisar con Clau la causa del bloqueo en Chileautos (¿VPN, patrón de scrapping, o estructura de acceso?).
— Speaker 1: Re-vincular correos y reportar si se desincronizan nuevamente.

**Para Nexus (implementar):**
— Aumentar tiempo de expiración de sesión / implementar refresh token de larga duración.
— Implementar manejo de re-autenticación sin re-ingreso manual de credenciales.
— Revisar si la redirección a Chileautos genera headers/user-agent que disparan bloqueos anti-bot.

**Personas/temas:**
— Speaker 1 (usuario): frustración con autenticación repetitiva y baneo en Chileautos.
— Speaker 3 (técnico): responsable de soluciones en Ailnest.
— Clau: mencionado para investigación del bloqueo en Chileautos.
— Plataformas: Ailnest (propia), Nikoyuri (del usuario), Chileautos (tercera, con baneo).

---

### 2026-06-18 · Reestructuración del equipo, adopción de Cloud y alineación de ventas

**Resumen:** Reunión sobre restructuración organizacional profunda con reducción de personal, migración a Cloud y realineación de roles de ventas. Se definen salidas de colaboradores y cambio en modelo operativo.

**Decisiones:**
— Migración a Cloud como estrategia operativa central
— Departamento de ventas se transforma a modelo de agentes (retiene: Freya y socio clave)
— Eliminación de posiciones: compradora, asistente de compras, y asistentes de venta (2-3 personas)
— Mantener solo 4 personas en oficina principal: Jesús, Freya, Ana María, y una más
— En bodega: reducir de 4 a 2 personas máximo
— Contrato part-time para Don José con supervisión externa
— Restructuración en cascada: salidas inmediatas en 1-2 meses, después asistentes de venta

**Pendientes:**
— Comunicar a María Fernanda detalles de restructuración —
— Hablar con Don José para alineación y explicar cambio de modelo (contacto: Speaker 2 facilita)
— Definir responsable de implementación de Cloud
— Establecer nuevos KPIs y métrica de eficiencia para roles que permanezcan

**Para Nexus (implementar):**
— Evaluar plataforma Cloud: integración con sistema actual, costos, timeline
— Automatizar procesos de compra/asistencia (eliminar roles manuales)
— Dashboard de eficiencia operativa para monitorear KPIs de personal restante
— Modelo de roles para "agentes de ventas" (automatización/CRM/comisión)

**Personas/temas:**
Decisores: Speaker 2, Speaker 3 (socio operativo), don José (externos/partner). A retener: Freya (ventas), Jesús, Ana María, María Fernanda. Mencionados para salida: Elizabeth, Víctor, Jazmín, asistentes de compras/venta, José de Coberanza. Proyecto cloud mencionado pero sin dueño claro.

---

### 2026-06-25 · Presentación Nexor AI y Gestión Stock Motos BMW — Reunión Ventas PROA

**Resumen:**
Presentación de plataforma Nexor AI (sistemas agénticos para automatización de ventas) al concesionario PROA (Mallorca). Demostración de agente de cualificación de leads con llamadas automáticas, transcripción y trazabilidad. Agenda: demo presencial 26 de junio 10:30 AM con propietario y director comercial. También negociación de posible importación de vehículos a Chile.

**Decisiones:**
— Agendada demo presencial para 26 de junio 2026, 10:30 AM (Mallorca) — reunión con propietario y director comercial de PROA.
— Nexor AI incluye: agente de ventas (prospección/leads), agente de foto-publicación automática, integración con CRM y web, chat multilíngüe (español/inglés/accento configurable).
— Pricing: ~1.000 EUR/mes por 1.000 leads; web incluida sin costo adicional.
— PROA recibe 200-300 leads/mes (Meta Ads, Google, referidos).

**Pendientes:**
— Javier (dir. comercial PROA) revisará documentación y web de Nexor antes de reunión.
— Preparar presentación al propietario + propuesta técnica de implementación.
— Validar configuración de datos internos (stock, precios, marcas múltiples) para integración CRM.
— Explorar modelo de negocio: compra vehículos en Mallorca → exportar a Chile (regulación: vehículos 2026, matriculados con IVA deducible).

**Para Nexus (implementar):**
— Automatización de foto + metadata → publicación multi-plataforma (elimina cuellos de botella).
— Bot de WhatsApp/llamadas con contexto persistente (ID único por contacto, sin pérdida de conversación).
— Integración avanzada con CRM: análisis post-contacto, métricas de conversión, recordatorios automáticos sin intervención humana.
— Multi-lenguaje + acentos regionales (español, chileno, etc.) en IVR/demo.

**Personas/temas:**
— **Javier**: Responsable desarrollo comercial PROA (Mallorca).
— **Mikel** (o similar): Propietario/gestor PROA.
— **Sofía (agente IA)**: Demo en vivo de Nexor AI (voz, tono natural, resuelve consultas de stock).
— **Ian Lee**: Socio técnico/cofundador (25 años, levantó $210M USD a los 22, Examedic vendido).
— PROA: Concesionario familiar, 10 marcas (BMW principal), rental + renting. Ubicación Gran Vía Sima 19, Mallorca.
— Tecnología: **Dropout** (holding de startups), **Nexor AI** (producto estrella), ganador **A16Z Speed Run** (acelerador IA).
— Potencial: importación vehículos Mallorca → Chile (franquicia, regulaciones aduanales).

---

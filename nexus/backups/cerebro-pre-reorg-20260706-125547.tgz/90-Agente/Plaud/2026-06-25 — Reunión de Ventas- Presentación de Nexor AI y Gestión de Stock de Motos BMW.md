---
tipo: plaud-resumen
tags: [plaud, resumen]
autor: plaud
fecha: 2026-06-25
---

# Reunión de Ventas: Presentación de Nexor AI y Gestión de Stock de Motos BMW

Speaker 1: Esto acaba.
Speaker 2: De llegar de recambios, te acabo de escribir. Ah, venía en la moto. Cómo? Venía en la foto. Ah, no, no. Que ya he pedido urgente que mañana lo de coche. No. Tenemos uno, pero se tiene que montar a una moto y le entregamos ahora. Bueno, pero. Yo claro, lo pedí el 24 de junio de 2026, que era festivo. Lo han visto ahora, pero lo van a hacer. Eh? Lo van a hacer. Claro. Sí, esto está en Madrid, lo pide urgente mañana, 26 de junio de 2026. A las 12 como muy tarde está aquí.
Speaker 2: He visto que me has escrito el esto. Bueno, me han mandado la presentación Nexor. No solo multipliamos tu ventala, te transformamos.
Speaker 3: No es lo que te decía a mí de la conversión de los leads,
Speaker 2: Era una locura. Mi socio que está ahora en Dubai, cerró unos contratos.
Speaker 2: Y qué precio me harías? No es súper barato, cuesta como 1000 eur por mes por 1000 leads, es súper barato. Y los leads de dónde los coges? De qué base? De donde tú se los pidas. Por ejemplo, si el tuyo es Pro Bikes de partida, se hace la web de nuevo sin costo, bien hecha a tu medida, como tú lo quieras. Eso va incluido, se hace una web más.
Speaker 2: Amigable, más amistosa, más actualizable. Y ahora estamos haciendo un bot que desde que tú haces la foto.
Speaker 3: Dame un segundo,
Speaker 2: Dame Un segundo. Espera. Ya, Nico. Qué tal? Encantado, mucho gusto. Javier es responsable del desarrollo comercial del grupo A. Sí, claro, y Javi tiene más contacto directo con el director general. Ya le ya le he comentado que tenía una empresa tecnológica en Chile, que te atendemos en Chile, en Perú, en Estados Unidos, y ahora estamos cerrando unos contratos en Dubai y este principalmente, que es uno de los agentes.
Speaker 2: Yo te mandé una cosa que hablaba sobre los sistemas agénticos, que es como para entrar en contexto. Finalmente, los sistemas agénticos son, como lo dice, como una estructura en una empresa donde está el gerente general, el gerente de operaciones, no sé qué, pero cada agente tiene su especialidad. Este caso es un agente específicamente de ventas, que lo que hace que es la prospección y el leads aumenta la probabilidad exponencialmente de conversión y que no se quede ahí. Por ejemplo, a mí me pasó que él me respondió.
Speaker 2: Y el vendedor me respondió cuando yo ya me compré la moto, o sea, yo la moto ya la tenía en mi casa. Entonces probablemente 100. Pero yo soy muy bueno. Sí sé, por eso. Y luego cuando llegué aquí me di cuenta que era el jefe y ahí me cansó todo. Entiendes? Entonces cuando uno no quiere depender de que el jefe esté haciendo eso, están estas herramientas porque hacen todo el trello, hacen todo el embudo, de manera que cuando ya el cierre real se va a concretar, Lo deriva al vendedor que se indique en la data, supervisado por él.
Speaker 2: Pero la acción es inmediata. O sea, si tu hubieses tenido, por ejemplo, esto implementado el día sábado que yo escribí, me habría respondido de inmediato, me habría llamado por teléfono de inmediato.
Speaker 4: Eso te llama también. Todo. Te llama.
Speaker 2: Y todo queda transcribido, queda transcrito en un Whatsapp de lo que te dijo, de lo que te dijo, después te lo manda por mail, deja toda la trazabilidad y mantiene el contexto. Si tú lo llamas hoy, Y se te olvidó algo, luego te metes de nuevo y le dices Sofía se llama el nuestro, Sofía se me olvidó preguntarte esto y le dices hola tu nombre es. Javier. Hola Javier, si dime, no es que le tenga que decir, yo soy Javier el que entró y te preguntó no sé qué, porque cada contacto le pone un ID y eso también es súper relevante, porque nos pasa a los seres humanos también a los vendedores y se llama Javier, el cual Javier, el de la BM no sé qué.
Speaker 3: Ah, Vinieron que es Javier de la BM,
Speaker 2: Cual de los tres. Eso te olvidas, te olvidas de todo eso y haces la eficiencia inmediata. O sea, si a mí él no me respondía, probablemente el lunes a lo mejor hubiese comprado una Honda, no sé. Porque yo le dije yo el lunes quiero pagar y llevar. Y si no me contestaban, a lo mejor el lunes yo iba a venir aquí a caminar y buscar quien me recibía el pago, me entregaba la moto y me iba. Y lo que hace esto es aumentar la conversión de manera exponencial. Eso es lo que hace este agente. Internamente estamos desarrollando nuevos agentes, como por ejemplo el de cuando ustedes hacen una moto aquí y la suben al portal, me imagino que una persona le hace la foto.
Speaker 2: Sí, hay errores porque uno pone de menor a mayor, de menor a manor y de repente se marea o no está actualizado. Estamos haciendo ahora un agente que lo que hace es que cuando la persona que hace la foto la hace, simplemente la envía con una instrucción, Y la gente la sube a las plataformas que las tiene que subir con las condiciones que las tiene que subir, y ahí se acabó el proceso. O sea, se terminó la foto y se acabó el proceso, se preguntó y está la vitrina. Y eso aumenta también el aumento de la probabilidad. Por ejemplo, la moto que yo iba a comprar no está en tu problema.
Speaker 2: Cómo que eso?
Speaker 2: No está. Porque ahí va mi trabajo. No, no, pero no, no, en la que yo venía. Con la que yo venía, que no compré, yo me compré la número, si te la preparé yo aquí está ahí, métete a pro bytes Ah no, en pro bytes no la tengo porque vale, porque en pro bytes hay otra moto Ah bueno, si son los que me dicen al final, si yo tengo cuatro motos del mismo color sí que las puedo subir las cuatro, pero yo tengo una pero es que no hay ninguna 2020, esa era 2026 correcto, no hay ninguna 2026 tengo una 2025.
Speaker 2: Por los 20 centros. Ya, porque la primera vez, ¿cuál tengo que vender primero? Depende. Ya, ya, ya. Porque me rode el cliente, porque mira, yo si me acabo de hacer una 2026. Pero si yo me quiero ir a Chile, y me la quiero llevar a Chile, por lo que te expliqué de la franquicia, a mi en una 2025 no me sirve, porque en Chile no me dejan ingresar. Tiene que ser. Pero si yo me quiero comprar esa, espera, el 85% de la compra hoy día, se hace ahí. O aquí. El 15% de ir a.
Speaker 3: Visitar cómo me atendieron, si me gustó o no me gustó, me terminó de convencer el activo. No hay más.
Speaker 3: Si yo voy,
Speaker 2: Yo soy chileno, vengo mucho aquí porque mi familia, porque las mujeres de aquí, tiene mérito, ha hecho yo.
Speaker 2: Vivo en Chile, pero venimos mucho con la familia, con los abuelos, los tíos, los primos y tengo tres hijos, entonces la relación familiar es muy importante. Entonces, por ejemplo, yo como chileno, Que tengo un negocio de automoción en Chile, además te lo expliqué a él por qué, porque me gusta el hobby de los coches y corro en Porsche y en M 3 y esto. Debería estar, a mí no me ha parecido, claro, porque tú entraste por el portal BMW, la web oficial. No, yo entré por el no, tú entraste por aquí, no, sí, pero si yo entro al que yo te preparé esta moto 2026, claro, tú no la viste en Proabike, entonces debería debería estar, no.
Speaker 2: Sí, sí debería estar. Todos esos como errores los eliminas a cero y donde todos esos mínimos errores a veces limitan la conversión, porque por ejemplo, yo ya que con lo conocí a Mikel, yo ya no meto a ese BMW, meto a Pro-Might y digo ah, voy a comprar esta porque me la puedo llevar a Chile, porque para llevar a Chile un vehículo usado, pero que ingrese como nuevo, tiene que ser del mismo año en curso. O sea, si esa, esa. Usada porque ya se inscribió a nombre de, no sé, de la empresa, creo, no sé.
Speaker 4: No, sí, porque es que es verdad que nosotros sí que tenemos ya como agentes cualificadores, ¿Vale? Que contactan al momento.
Speaker 2: Pero son agentes o son bots?
Speaker 4: Son agentes. Sí. Son agentes que además tienen la información, toda nuestra información interna de stock y y demás. Y al final es verdad que es difícil de implementar porque en en, En configuraciones, por ejemplo, nuevas, es complicado que el nivel de configuración de una moto o de un coche es alto y precios y precios publicados, precios de reales y demás es complicado. Pero por ejemplo, sí que me ha interesado mucho lo que has dicho de que lo hagan mediante de llamadas, porque ahora mismo, a día de hoy.
Speaker 4: Solamente lo tenemos a través de WhatsApp. Entonces, claro, todo aquel, todo aquel cliente que entra, que nosotros, por ejemplo, solemos tener como cómo quiere ser contactado por llamada, por WhatsApp o por email. Y si contesta un WhatsApp, perfecto,
Speaker 2: Lo tienda la gente.
Speaker 4: Si dice llamada, dependemos totalmente de un vendedor o un equipo de cualificador humano, que es lo que eres tú, que te llaman, tienen. 200 leads pendientes y que esto es uno más que entrar en la cola.
Speaker 2: El tema es que acá no hay leads pendientes primero, no hay error a la falla de que se me olvidó el 524 leads porque tenía 2000, entonces eso se me pasó, no existe. Si el leads número 325 me dice justo ahora estoy entrando al médico, llámame en media hora más, te llamo en media hora más. El ejecutivo que está ahí está, Número tres mil se le olvidó el que le dijo y sigue avanzando entonces.
Speaker 4: Si quieres, por ejemplo, quiero esto, me lo reviso, pero si quieres incluso eh y demás el el agente lo tenemos instaurado en ahora mismo oficialmente en pro ocasión.
Speaker 2: Ah, a ver, lo voy a revisar.
Speaker 4: Si tú estás en pro ocasión.
Speaker 2: Está interesado en un coche y tiene concesionales de de web. Sí, sí.
Speaker 4: Pues Si entras en el si entras por el WhatsApp y tú.
Speaker 4: Y Lo puteas. Cómo era tu nombre? Nico. Nico, porque ya tenemos acceso a ver cómo todas las condiciones, entonces puedo entrar a ver un poco a ver cómo te ha ido con él. Y para que tú también veas un poco, pues eso a lo mejor. A nosotros.
Speaker 2: Nos quedan resguardos de todas las conversaciones. Entonces con eso estamos haciendo análisis. Nosotros también en Internet. Tenemos un equipo de desarrolladores que solo están enfocados en qué pasó después. Se contactó, mira, si metes en la web de GetNexon. GetNexon. Yo te mandé el link. Me lo pasaste.
Speaker 2: GetNexon.
Speaker 3: Mira, y ponlo. Talk to Sophie. Sí, pero acá está en español. Y quizás le explica todo lo que hace, pero aquí español.
Speaker 3: Aquí te habla sobre todo lo que hace. Pero por ejemplo, queremos hablar con Sofía. Ah, pero está en inglés. Por qué? Bueno, pero háblale en español.
Speaker 1: Sofi.
Speaker 3: Dile, no sé, nunca lo había visto.
Speaker 2: Que está configurado que fuera de Latinoamérica se active el inglés automático, pero dile, necesito hablar en español. A ver qué dice, no sé, esto es una prueba en vivo, nunca lo he hecho.
Speaker 3: Hasta ahora lo habíamos hecho en, En inglés y en lo que lo hiciéramos cruzar.
Speaker 3: De hecho, lo voy a grabar, por si hay alguna.
Speaker 2: Lo mando de inmediato a los niños para cada vez que hemos encontrado tú. Estás escribiendo mucho, ¿eh?
Speaker 2: Sí, en español estamos. Mira, mira. Cuéntame, ¿a qué se dedica tu negocio y qué estás buscando?
Speaker 3: Vale, cuéntame lo que queráis, dile, pon la prueba en mi voz. Hola, prueba de algo.
Speaker 2: De nuestro negocio. Sí. No, no me. No, de tu negocio. Cuéntame a qué se dedica tu negocio y qué estás buscando mejorar. Así veo cómo te podemos ayudar concretamente. Tu negocio dile de compraventa de motos.
Speaker 2: Concesionario de motos. Gestionamos un concesionario de motos con varias marcas. En Mallorca, en Dile dónde, en Mallorca. España.
Speaker 2: Y ponle el ejemplo, claro, necesitamos gestionar mejor los links porque.
Speaker 4: Ya has dicho que esa era la gente que tenías, que era la gente comercial.
Speaker 2: Este es nuestro agente comercial de nuestra plataforma que vende el producto.
Speaker 4: Cuántos Agentes tienes?
Speaker 2: Bueno, estamos desarrollando una hora que es justamente para la automoción. Y por qué se desarrolló? Porque yo tengo una automotora pequeña, es que una vez que se hagan las fotos, se da la instrucción, Y el resto se hace todo automático,
Speaker 4: No hay nadie que tenga que subir aquí esto, o sea, solo fotos, fotos, la ficha técnica, fotos, el vehículo, el coche, fotos, toda la información en fotos, se le carga la foto, se le da una instrucción y se acabó el problema.
Speaker 2: Justo el tipo de negocio donde Nexo le encaja bien, leads que llegan por web, redes o anuncios y muchas veces se enfrían si no los contactos rápidos. 2 preguntas rápidas, cuántos leads entran más o menos al mes y cómo los estáis captando hoy? Meta Ads, Google referidos a. A motos más o menos podemos estar entre 200.
Speaker 4: Y 300. Bueno, si me puedes pasar el igualmente el PDF que le echo un vistazo y si lo de la lo de las nosotros también lo tenemos algo en marcha, pero no está tampoco aún no está como completado, pero es que con esto yo creo que. Lo que tenemos que conseguir para mí era implementarlo en todos los departamentos, ya no solamente en cualificación.
Speaker 2: Es Lo que yo le decía a Miguel el 24 de junio de 2026 que existe una cosa que se llaman sistemas agénticos. Estos sistemas agénticos se componen de varios agentes especialistas en algo. Dile que te llamen.
Speaker 2: Entonces, finalmente estos sistemas agénticos te hacen el trabajo. Mira, yo participo en 6 empresas. Acá tengo el 89% de la información con un mensaje y con 2 mensajes le mando la información a toda la gente que necesito que esté al teléfono. Le puse nombre. Cómo se llama Ali? Ali, por favor, entrégame esta información todos los días a tal hora.
Speaker 2: Y comparámela versus la proyección versus la meta y cómo nos queda para avanzar el resto del mes para cumplir el objetivo de venta, contribución. Después le digo, ahora envía la, no sé si le llaman igual aquí las cuentas por cobrar. Envíame el detalle de cuentas por cobrar vencidas y cuando el 10% mándale un mensaje específicamente a María Elena, que es la encargada, donde me envío un mail en detalles de por qué yo hago mi tarea, A la hora que sea, cuando yo sea, cuando.
Speaker 4: Sí, el objetivo va a ser ese, como todas esas tareas automáticas y mecanizadas.
Speaker 2: Generalmente de 10. Hicimos un software de lectura de radiología, de dientes, donde se usaban 100 radiólogos, ahora ocupan 2 con el software que dicen, con 2 hacen el trabajo de 100, imagínate, es una locura. O sea, acá no sé, sin desmerecer el trabajo del que está en ventas, pero si aquí tienen, no sé, cinco vendedores, los podría hacer con dos o con uno.
Speaker 4: Por eso tengo.
Speaker 2: No, no, por eso digo, pero del que está ahí. Sí, lo empieza a implementar el beneficio marginal, a costo marginal, es impresionante, porque no necesitas vender más. Sí, y ya está. Pero si ganas mucho más. Y no necesitas esforzarte más y sí,
Speaker 4: Ganas mucho más. El control,
Speaker 2: O sea, el CRM, si estáis usando un CRM, esto que vamos a implementar tu CRM asociado a la página web, a los leads y a esto. Y te lleva a Mario y le puedes decir de inmediato a Mikel, oye, mira, serán, serán quizás.
Speaker 2: Francés. Oye, mira.
Speaker 2: Tuve cuatro que había que y Pepito, Pedrito y Juanito. Claro. Cómo va a poner esto? Cómo va eso otro? Cómo va la Matrícula?
Speaker 2: Cómo va eso? Se entretenó en 24 que si va aquí. Todo esto vale. Tienen varias marcas. Tienen rental los 2 tipos de renta, no entendí la diferencia.
Speaker 4: Hay un alquiler de coches que es el como rent a cable y luego está el pro renting, el renting, que es el super. No se.
Speaker 2: Puede vengar y así están ahí. Todo, todo, todo. Y la implementación es bastante sencilla porque esto finalmente se llama AI Arbor Black en inglés, que es como el empuje de la inteligencia artificial a las empresas que ya funcionan. Pero que le ha faltado implementar la tecnología que hay, esa vivienda en San Francisco, nosotros tenemos sede ahí y es como está en el futuro. En San Francisco tiene sede? Somos unos retrasados mentales, yo digo, somos unos animales. En San Francisco tienes una oficina?
Speaker 2: Sí, ahí sale.
Speaker 4: Pero, ¿En qué zona? Hay quiere que te llame? Dile que te llamen. Esa es una frase muy, de las que yo he sido de la gente, es muy habitual, de, Quiero que me llame un comercial, quiero hablar con alguien.
Speaker 2: Yo Aquí me registré y puse mi teléfono el otro día que me lo pasaste y no te llamó, no, tampoco le dije nada, pero sí que me pedía un teléfono móvil y tal y yo ya lo puse. Bueno, el otro día nos pasó una muy simpática porque habló, por ejemplo, el gerente, habló con Sofía, no sé qué. Mira, dame, claro, te llamo ahora mismo. Ahí te está llamando.
Speaker 2: Está con acento chileno, pero puede estar en acento español, en acento, lo que tú quieras. Perdón, no te he oído bien.
Speaker 5: Soy Sofía de Nexor AI, hablamos hace poco por el tema de gestionar mejor los leads del concesionario de motos. Tienes un momento ahora para comentarlo? Sí, claro.
Speaker 2: Me escuchas a mí? Claro, si escucha, se corte porque siempre que va a interrumpirla. Te escucha, jefe,
Speaker 3: Lo podemos poner?
Speaker 2: Sí, bueno, comentábamos de gestionar los list de mi concesionario.
Speaker 5: Deja tus datos bien trabajados para que veas si tiene sentido contigo. En qué plazo te gustaría empezar a probar algo así, dentro de un par de semanas, un mes, o lo ves más a largo plazo? Si.
Speaker 4: Podría ser hoy?
Speaker 5: Genial, o sea, lo ves para empezar ya, eso ayuda muchísimo. Para encajar bien lo que tienes montado ahora mismo.
Speaker 2: Cuéntale Que está tal persona también contigo en la reunión.
Speaker 2: Pues te te comento, es que estamos Javi, mi compañero, que es el responsable desarrollo de negocio, y yo que soy el responsable del concesionario de motos y estamos gestionando este tema.
Speaker 5: También gusta el stock encima del tema. Y el concesionario como tal? Cómo se llama la empresa?
Speaker 4: Hola Sofía, soy Javier. La empresa se llama PROA, la verdad es que me gustaría probar vuestros servicios y podría ser vernos hoy de aquí a dos horas, por ejemplo.
Speaker 5: Segundo y veo huecos para abrir, así te encajo la delmo lo antes posible. Buenísimo que lo quieran mover rápido. Hoy yo no tengo huecos, pero mañana viernes, 26 de junio de 2026, tengo por ejemplo a las nueve, a las diez y media o a las doce hora de España. Ah, hora.
Speaker 4: Sí, a las a las diez en en Mallorca. Estamos en Gran Vía Sima número diecinueve.
Speaker 4: Perfecto, Mañana viernes, 26 de junio de 2026, a.
Speaker 5: Las 10 de la mañana, hora de Mallorca, que son las 4 de la madrugada en Chile. Asumiendo que.
Speaker 3: Es una videollamada.
Speaker 4: Sí, a las diez y media, a las diez y media, bien. Puede ser el presencial?
Speaker 5: A las diez y media de la mañana hora de Mallorca que son las cuatro y media de la madrugada en Chile la demo solo la hacemos por videollamada, así que será online, te llegará la invitación. Tienen con el enlace.
Speaker 4: Vale, perfecto, Sofía, muchas gracias.
Speaker 4: Bueno, esta. Es muy natural la verdad, tarda un poquito en contestar,
Speaker 2: Pero si la que te espera están. Han estudiado y a propósito porque se supone que ella está revisando en un sistema. Todo lo que tú le preguntas para poder responderte.
Speaker 4: No, y que a lo mejor también la persona puede como volver a decir algo y le deja un poco de tiempo.
Speaker 2: Y el acento está para Chile.
Speaker 4: Sí, Pero el accidente en la acción. Es verdad que no es para nada como muy robótico.
Speaker 2: Pero le podemos pedir acento español, acento alemán, acento inglés.
Speaker 4: No, la verdad es que así como por ejemplo del WhatsApp. Te diría que estamos trabajando en ello y hay que ver como los resultados que tenemos y demás, y quieres incluso probarlo para hacer alguna prueba y demás. Están dentro de la cuota por la ocasión, pero lo de la llamada me parece como,
Speaker 2: Pero métete al por la ocasión, a ver cómo es, porque lo bueno que tiene esto es que si tú te fijas no es que te tengas que enlazar al WhatsApp en la misma web, ya a ver métete al por ocasión, pongo por ocasión y mira. Ocasión Plus, flechicar, auto ocasión y tengo que ir al cuarto. Eso es otra cosa que se ve detrás, es el posicionamiento que tú quieres comunicar, donde tú quieres que llegue la gente. Mira, métete ahí. Eso. Espérate, eso ya retrasa la posibilidad de compra.
Speaker 2: Yo no me meto a ninguna página web que haga eso. De hecho, en mi automotora está así. Están implementando esto ahora hace un mes. Lo que pasa es que porque cuando uno ya hace eso.
Speaker 4: Lo que pasa es que si el cliente desaparece del chat, ya como que se desvincula de.
Speaker 2: No, no, no, porque mira la página de Nexos, si la página de Nexos en tu página tienes esto, en vez de ese link de Whatsapp, todo esto te queda en tu backup, todo.
Speaker 4: Sí, En el cliente no, pero si. Al cliente también,
Speaker 2: Se lo manda por mail y por Whatsapp.
Speaker 2: Sí, Entonces aquí hay el respaldo de Whatsapp para ti, para él y por mail, pero no tienes que entrar a poner, WhatsApp, abrir tu aplicación, eso ya es una traba. Hoy día la gente, mientras menos clics haga para hacer algo, aumenta la conversión. Si yo tengo que comprar, por ejemplo, por Amazon y de repente me aparece que la promoción de no sé qué y si ta la mierda, ya no lo compro, porque finalmente todos estos compras son excedentes del consumidor. No es ninguna necesidad. Yo no necesitaba la moto que te compras.
Speaker 2: No, es excedente del consumidor. Entonces el excedente del consumidor es muy sensible al obstáculo. Cuando hay obstáculo, a gastar el excedente del consumidor, no me lo gasto. No es la necesidad de comer, de dormir. Si estoy muriéndome de hambre, hacer una fila, la hago. Si no estoy muriéndome de hambre, es una fila de algo que me gusta, digo, otro día la como. Esto es lo mismo. Entonces el excedente del consumidor hay que atacarlo de tal manera, que es lo que decís tu, como te vas llevando al trellop y te hace el trellop, para qué, porque después de eso cuando ya está, por ejemplo ahora que tu le pinte la cita para mañana, 26 de junio de 2026, a las 9.
Speaker 2: Una persona. Sí, sí, sí.
Speaker 4: Pues si te si te si tienes como el tiempo de de echarle un vistazo, por ejemplo, a lo que tenemos actualmente y que hagamos un día a lo mejor una reunión de verlo un poco más en detalle.
Speaker 2: Sí. A mí esto me divierte así como sí. Por el mío te decía, prepárame algo que le pueda presentar al al propietario. No te mandes o. Y que podamos interactuar y probarlo a ver.
Speaker 4: Más que nada porque al final nosotros estamos muy, yo no soy informático. Bueno, No, yo no soy ningún ingeniero ni nada, pero tú al menos tienes como un negocio que se dedica concretamente.
Speaker 2: Y pasa,
Speaker 4: Nosotros tenemos un departamento de informática que es grande, o sea, al final son casi 40 o 50 personas trabajando ahí y que ellos son los que han desarrollado esto. Entonces, para mí, que vengo de cero, pasarme a pasarme a esto, ¿sabes? En plan, ya es un avance, pero no sé si estoy muy lejos. De lo que hay fuera.
Speaker 2: Mira, Por ejemplo aquí voy a hacer clic y está con el que a mí no me gusta. Y el 24 de junio de 2026 les dije necesito esto solucionado de aquí a fin de mes. No, esto no puede ser. Yo necesito que cuando haga clic ahí funcione igual que en Excel. Bueno, aquí si tú lo haces te va a contestar una persona, un rock bot también de todo, pero no quiero que pase, porque yo sé que esto baja la probabilidad después de llamar. No, eso es un bot, no es un agente, eso es un bot. Pero estoy implementando esta herramienta de Nexor en mi automotriz.
Speaker 2: Si le presentamos el estado al propietario y yo le digo que eres el propietario de esto y tú no lo tienes. No, no, claro, por eso que Nexor lo tiene, porque Nexor es el propietario realmente. Tú eres de Nexor? No. Yo soy socio de Nexor. Vale, sí, pero esto es mío. Lo que pasa es que yo coincidentemente tengo una cosa de coches. Pero en la empresa de tecnología hacemos así un monexo. El móvil tiene un condicionario de coches. Juliano ha pedido para comprar unos coches e importarlos a Chile. De hecho, sí, ya tengo toda la explicación y ahora voy a ir a una gestoría para hacer la SL porque necesito solamente que tú me hagas una factura y me entregues el euro uno del vehículo que me entregues.
Speaker 2: Y que la factura sea con IVA deducible. Con eso yo lo agarro, lo tomo, lo subo al barco, pero llego. Tiene que ser de ocasión el coche matriculado, no puede ser nuevo. Puede ser mismo también. Pero para ser nuevo y no matricularlo, la compra tiene que ser directamente con la marca. No, no sé. Nosotros al ser concesionario. Claro, pero yo un coche, yo no te puedo vender un coche si no lo matriculo. Tengo que dar retail. Sí, me lo matriculas. No puedo vender un coche. Me lo matriculas a mi SL, a eso a lo que voy. Pero yo ya estudié ese negocio, por ejemplo, conversando con él, vi esa que iba a comprar y le dije, hagamos el ejercicio con una moto pequeña, que es menos riesgo, más barato, te la compro, hagamos el ejercicio de documentación y a lo mejor yo puedo ser un cliente tuyo y tú un proveedor mío, donde a lo mejor te compro 2, 4, 6, 10 vehículos por mes.
Speaker 2: Si yo me abastezco en Chile de vehículos desde acá y todos ganamos.
Speaker 4: Si nos adelantar a todos, es perfecto.
Speaker 2: Y si los números dan, ¿por qué no? Ahora, a mí lo que me agrada de esto, que fue lo que me dijo Mikel, que normalmente cuando estas empresas son muy corporativas, cuesta llegar a hacer estas cosas. Ahora, como la familia es una familia la dueña, a veces son un poquito más permeables a poder hacerlo.
Speaker 4: Ahora es más grande, que por lo tanto sí que hay bastantes corporativos, pero al ser una empresa familiar también, puede ser que es verdad que hay cierta.
Speaker 3: Oye, y tienen Renault. Hay un un RR5 que salió ahora?
Speaker 2: El soporte eléctrico. No, uno que no es L, que es un R5 lo tiene eléctrico. Sí, pero hay uno que salió ahora que era como la versión nueva del histórico, que lo vi hace poco. Puede ser. Claro. Tienes el R5 eléctrico y está también el R4. El R5.
Speaker 4: Eléctrico es uno eléctrico.
Speaker 2: Ah, no, pero salió la versión combustión.
Speaker 4: No, no hubiera sido en especial.
Speaker 2: No, Que yo cuando lo vi dije. También el Twingo. Pero eso. El Tringo? El Tringo lo han vuelto a sacar. El de la Shakira. Shakira lo levantó a la vida, el Tringo, ¿o no? Sí, es verdad. Seguro. Esto Shakira lo golpeó, lo metió en la mente del mundo. Ya, como. Yo casio. Yo llevé a mi hija a ver al recital de Shakira y se sabía la del Twingo, el pique y todo eso. Cuánto tiempo estás por aquí por Mallorca? Yo me voy el 2 de julio.
Speaker 2: Pues tienes toda. Todavía me queda la próxima semana completa y ya está. Y bueno, y fue porque en verdad. Fue anda la conversación, no sé qué, le compré una moto que no venía a ver, le compré otra, me fue a buscar en el hotel, buena onda. No sé por qué la gente dice eso.
Speaker 2: Entonces yo vi que lo hacía bien y entonces empezamos a conversar un poco más de temas y creía que hay hartas cosas que se pueden hacer en beneficio conjunto. La realidad es que no, Nosotros hoy día estamos, esta empresa se postuló a un programa de A16 Z Speed Run, que es un acelerador de inteligencia artificial en Estados Unidos, que es como el Harvard de la IA. Y nos ganamos el premio ahora, recién, hace como un mes y medio. Entonces, también está validada por gente experta. Si tú te metí a la web de A16 Z Speed Run, vaya a ver quiénes son los cabrones de esos y el Abraham.
Speaker 2: No me acuerdo, pero son los que desde la punto com hasta el día de hoy se han mantenido en la cresta de la ola siempre en temas de tecnología. Entonces es un producto realmente muy muy bueno. Y nosotros además hacemos asesorías tecnológicas en general, modernizamos un proceso. Lo hacemos a empresas grandes.
Speaker 4: Si te parece, déjame un par de días también, que yo también investigue un poco por mi cuenta, que me lea un poco lo que le has pasado a Miquel, entre un poco más en la web, porque la llamada. O sea que te va diado, sí. Cuando te va diado. Vemos la semana que viene.
Speaker 2: Tienes una semana más aquí. Yo creo que la mejor forma es leer eso, entrar a la web y hacer la prueba. Y más que eso, yo te digo que el resto es.
Speaker 4: Y si. Y si te va bien por no sana que no vemos nada, nos vemos aquí mismo una habitados y tú también por tu parte dices en plan, oye, hacéis esto, aquí hacemos esto, hacéis esto, nos hacemos esto, pero también es un poco que claro, si así como de primeras, cuando me estabas juntando digo, hostia, yo estaba pensando en plan, todo esto lo tenemos o estamos en marcha, ¿sabes? Pero puede acelerar. Se puede acelerar o se puede mejorar.
Speaker 2: Entonces, El ingenio de esta empresa, el gerente comercial y técnico. Se llama Ian Lee, anótalo y googlealo luego.
Speaker 4: En la empresa de Nexo.
Speaker 2: No hay una empresa que se llama Dropout, que es una empresa de desarrollo tecnológico y Nexo es una de nuestras startups de esta empresa, Ian y a NLEE, IAM Lee, Golf, MD, CBS, MD, A, Cardeton, Lite, IAM Lee,
Speaker 3: No, ese es así, IAM Lee, pero cuál.
Speaker 3: No Juan espacio, Chile.
Speaker 2: Él Es un genio, tiene 25 años, él es mi socio especialista. Levantó 210 USD a los 22 años. Sí, su empresa fue valorada en 10 USD hace 4 años atrás. Examedic, una empresa de la cual ya la empezó, la terminó y hoy en día es socio, ya no trabaja ahí. Lo ha vendido. Vendió, se quedó con un porcentaje. Él es socio mío en varias empresas, en varias empresas, pero en la de tecnología, él es el amo. Yo veo finanzas, administración, algunas cosas comerciales. No soy un genio, se lo trabajo 18 horas.
Speaker 2: No, pero es un puto genio. Esto estaba ahora en Emiratos, me decía. Ayer, el 24 de junio de 2026, me llamó y me decía, todavía alcancé a llegar porque hoy día, 25 de junio de 2026, tenemos una reunión en Emiratos con los jeques de no sé qué mierda. Uno tiene el nombre del aeropuerto, imagínate, uno de los que ahora en la reunión tiene el nombre del aeropuerto. Es de la reunión de hoy. Y el 24 de junio de 2026, no sé, en Abu Dhabi. Sí, me mandó hasta el pantallazo y yo le dije, me estáis weando. Claro, debe ser el emir de Abu Dhabi. No sé, es una locura. De Dubai no sé qué nombre tiene, pero de Abu Dhabi, el aeropuerto es.
Speaker 2: Tayed. Jammed, a ver. Jammed Maná, Ahmed Maná. No sé, este es uno. De ahí de Dubai a Cotoum. Ah, debe ser de Maktoum. Este es el de Dubai. Bueno, ese es uno de los que va a la reunión hoy día a las 7 y el 24 de junio de 2026 en la mañana me decía, tómate un avión y vente, weón, volando, vente si alcancé a llegar. Pero justamente el 24 de junio de 2026 tenía algo familiar acá con mi suegro y todo y le dije, weón, no puedo. Por dos días que vienes de Chile aquí tienes que cumplir.
Speaker 2: No vengo por dos días. Vengo por un mes. Sí, máquina. Creo que era un chino chileno. Es coreano. Su papá es coreano. Su mamá es coreana. Él nació en Chile, pero tiene nacionalidad nacional. Y él es socio mío en otras empresas, los alimentos que te comenté, en otras startups de asesorías tecnológicas que hacemos en Perú, en Estados Unidos, en Chile, hacemos asesorías tecnológicas. Ahora, por ejemplo, agarramos una empresa que partió el abuelo de quienes hoy día las encargó.
Speaker 2: En buena red de retail, de comercialización de accesorios electrónicos y eléctricos, así como materiales de no sé, como el. Cómo se llama aquí, donde se compra la. Cuando tú necesitas un enchufe para la casa y lo compras en el bricolaje. Ah, sí, bricodepot, bricomart. Le estamos haciendo todo el salto cuántico de la tecnología moderna en Chile, porque están todavía con el arco y la flecha en términos de, De la tecnología de la empresa, los estamos llevando a volar en los F35.
Speaker 2: Hacemos también esos, esas.
Speaker 3: Asesorías de aumento de tecnología y los resultados son todos espectaculares,
Speaker 2: Todos espectaculares. Realmente tenemos gente muy buena. Yo tengo personalmente un desarrollador trabajando para mí 24/7, que está desarrollando un proyecto que se llama Segundo Cerebro.
Speaker 2: Suena. Entonces Nedtor es de I and Lee y tuyo. No, nosotros tenemos, nosotros en la empresa tenemos el 45% con IA. Nexor facturó y llegó a facturar en 6 meses 340 millones de dólares.
Speaker 2: Es que nos fue muy bien si cuando hicimos la presentación en Estados Unidos, ¿qué haron y.? Cómo estáis? Hola, ¿qué tal? Me ayuda?
Speaker 3: Hay posibilidad de llevar.
Speaker 2: Xpeng. Dame un minuto.
Speaker 2: Ahora, ¿Cree que Joan Kika es el responsable de Xpeng?
Speaker 3: Sí, Es el papá de Rafael.
Speaker 2: Es el tío. Será muy mala educación. Mira, saludarle y felicitarle.
Speaker 3: Como es el de.
Speaker 4: De la casa, se compró un XP.
Speaker 1: It's not.
Speaker 2: En Este caso, cuando tenía.
Speaker 1: 13 años yo trabajaba en esta Obra.
Speaker 2: Es como es una.
Speaker 1: Presión de un trabajo.
Speaker 2: Pues Que yo, yo, yo a mi padre, al final, yo tenía 30, 14 años, porque yo iba a comer una hora con mis amigos, pero.
Speaker 1: Había su pueblo, que no sabía lo que valía eso. Una hora. No, no, no era fácil. Pero al final, it's a go, go.
Speaker 1: The second point is the function, that is going to be here, and it's not a nice day for this. Yeah, it's yeah, basically, there is a nice thing, and then you want to go to the right, and the two is again, and the next one is not going.
Speaker 1: Yeah, yeah, there's nothing we have a computer, and there's another extense from the air box.
Speaker 1: What is that?
Speaker 2: Tengo la funda preparada ¿Eh? De la moto. Sí. Javi. No, Javi. Se se le nota que tiene veinte es ¿O no? Es más. Es más analítico que yo. No, no, y tiene, pero tiene veinti poco y se le nota. Tres menos que yo. Treinta y tres, tiene. Ah, pero se lo veía más joven, como más pequeñito. Yo estoy muy cascado. Bueno, yo creo que puede ser interesante una reunión contigo, por lo que me comentas, con el propietario sobre todo, y con el director comercial.
Speaker 2: Eso para lo de Ned solo para lo de los vehículos, para todo. Para lo de los coches. Al final tú piensa que con el propietario, que evidentemente es el, si está el propietario te puedo decir que no necesitamos a nadie más, pero al final. Al final, el director comercial, que es el que tiene los datos de los las puntas de sobre stock de la empresa a nivel global, pero yo puedo pensar en una marca, pero es que tenemos 10 marcas. Claro, entonces ya hay unos números que los tienes que ver desde la posición número uno, digamos, no desde la posición, desde el tercer escalón de la empresa.
Speaker 2: Y a partir de aquí, yo siempre digo yo todo lo que sea una herramienta más. Que te dé un valor añadido a tu negocio y esto yo bueno, lo quiero mañana. Al final lo que tú dices, yo lo que no quiero es que me entre un correo a las 2:00 un sábado y estar así de le tengo que contestar porque si no, yo sé que si no contesto y no soy bueno y directo y entonces yo el 24 de junio de 2026 cuando llegué de Ibiza.
Speaker 2: Estaba con mi abuelita cantando cumpleaños feliz y me entró un correo de la marca, claro, y luego cuando lo veo digo, ostia, es un señor que he hablado esta mañana estando en Ibiza, ¿sabes? Y es como claro, si tú tienes esa herramienta, pum, puedes decir al final del día lo reviso y es que es lo que yo hago al final del día reviso todas estas cosas que ya las tengo medias automatizadas porque sé que la urgencia la captan en el minuto. Al final del día, esto requiere de mi intervención ahora. Esto no, esto sí, ayuda un montón a la eficiencia.
Speaker 2: Porque tú al estar así como estás, que me pasaba a mí, se pierde eficiencia. Pues lejos. Eres muy eficiente, pero podría ser más.
Speaker 2: Ya, yo lo que digo, yo puedo, pero en algún momento, en algún tema de mi día a día, fallaré. Es decir, el tiempo que estaba siendo eficiente contigo contestando un correo, te vas a estar con tu mujer. Obvio, en algo voy a fallar. Con la abuelita, con el tío, con el primo, con el mano. Entonces, la idea es tratar de compensar eso y para eso usar la tecnología. Mira, lo de los coches, lo que yo te decía es cuándo es el momento. O sea, aquí finalmente, cómo pasaba el DMV en España, en Chile.
Speaker 2: A mí, el de usados, me mostraba la pantalla y me decía, mira, estos son mis días de inventario. Los que tenía, no sé cuántos días de inventario, me decía, casi yo te los puedo regalar porque el costo que me empiezan a cargar contable por tenerlo cada día más para mí es más barato venderlo muy barato y sacarlo. Yo no sé cómo funciona guías igual ya exactamente igual. Entonces quizás es al revés. Tú me podrías decir Oye, mira de los 2026 que son los únicos que aplican para mí los de los 2026 con menos de 10.000 15.000 20.000 5.000 kilómetros no sé tan fiebre este es el ranking de donde yo mejor puedo hacer el esfuerzo de precio y yo ahí hago el ejercicio hacia allá.
Speaker 2: Digo a ver si me cuesta 10 más los 2500 12.500 más el IVA de allá que son 19% me voy a quedar en 15.000 yo lo voy a poder vender en 16.000 17.000 20.000 ahí hago el análisis completo por eso no he mirado los precios en chile yo te puedo decir si pongo punto ch desde el de chile Ah es que no te va a venir.
Speaker 2: No, tiene una falla ahí. Cuando tú entras aquí no te deja entrar a la de Chile, te hace un baneo. En Argentina sí que es la web oficial. En Chile no. SCH. No, SB Premium usado. Mira, pon BMB usado Chile. BMW.
Speaker 2: Premium Selection. Chile.
Speaker 2: Punto CL. BMBPS. BMW.cl BM Premium Selection. Aparecen los nuevos. BBO Premium Selection, aceptar, te interesante, seminuevo. Ah, me hace registrarme. Me hace un full ver stock seminuevos. Sí, lo veo.
Speaker 3: Te cuento dos cosas de lo que pasa en BMW.CL. Yo trabajé mucho con ellos, años, hasta que el gerente usado se fue a Costa Rica. ¿Por qué?
Speaker 2: ¿Pagaron más en Costa Rica?
Speaker 3: No, porque el nuevo que llegó era un corrupto. Yo compraba como 500.000 euros mensuales en coche, aquí.
Speaker 2: Y eso se murió una BMW en Santiago de Chile. No, no, hay varias, pero son todas del mismo. Propietario. Mismo grupo, Inchcape, que es un grupo inglés que tiene Detec, Porsche, tiene Subaru, tiene un montón. Es como Proa aquí. Lo tienen monopolizado. BMW, sí. Claro, ahí no entro más. No le digo, yo compraba 50 EUR por mes fácil acá y hasta que se fue ese y entró un gerente nuevo y el gerente nuevo quería dinero para su casa.
Speaker 2: Son buenos precios. Yo le dije, no más. Claro, lo que veo es que no tienen, lo tienen, ves, este sí paquete M deportivo, que todo lo demás, así paquete básico.
Speaker 3: No, no, sí, son otro, son otro. ¿Qué te pasa hasta ahora?
Speaker 3: Estaba escuchando un podcast que se lo activo,
Speaker 2: No sé, veo muchos coches básicos. Nosotros aquí el 90% de los coches los tenemos con paquete, con paquete,
Speaker 3: Pero nos cruzan para el ranting, ¿no? Esos son más básicos,
Speaker 2: También todos, porque luego a la reventa, el cliente no,
Speaker 3: Pero por ejemplo, ese es un IX 3 M ya ese cuesta 39. 39.000 euros ¿Cuánto cuesta aquí 2023? va a pasar una comparación siempre el 2023 ojo no no yo revisé el de.
Speaker 2: 2023 Mira 45.
Speaker 2: Mira, nuestro de Palma, ¿cuánto vale? Es más caro,
Speaker 3: Pero ya 40.
Speaker 3: Ahora anda a ver cuántos días de stock tiene y qué kilometraje tiene.
Speaker 3: No sale kilometraje?
Speaker 2: Sí, 23 y el de.
Speaker 2: Desde Chile, 30.000. Claro, tendríamos que ver el equipamiento. Sí, por eso te digo, veo precios muy parecidos.
Speaker 3: Yo creo que sí hay espacio en algunas cosas. En algunas unidades.
Speaker 2: Claro, tendríamos que ver la unidad en concreto.
Speaker 3: Mira, dame el ejemplo de la moto. A ver, déjame ver si puedo entrar aquí. No sé si me va a dejar entrar desde acá.
Speaker 2: Aparte de lo de Nexor, la presentación y Get Nexor, ¿qué quieres que le pase algo más de lo que me has pasado?
Speaker 3: Yo creería que ver esa presentación, entrar en Nexor y hacer la prueba que hicimos aquí es suficiente. O sea, hay uno,
Speaker 2: No es que.
Speaker 3: Antropic es quien creó Cloud. Cloud, eso es para que lo estudies tú,
Speaker 2: Eso para que tú entendéis lo que yo expliqué de los sistemas agénticos, que es lo que yo te lo doy como consejo. Yo no sé cuántos años lleva en esta compañía.
Speaker 2: El primero que empiece a impulsar este tipo de cosas va a ser el que va a liderar las empresas. Y sea el vendedor, sea el recepcionista, sea quien sea, el que logre hacer que el cabeza de la empresa implemente estas cosas, va a ser el líder de la compañía. Eso es un hecho.
Speaker 2: Esto lo voy a mostrar.
Speaker 2: Mira, mira, acá hay un ejemplo súper claro.
Speaker 3: Con la moto. Que es lo que tenemos.
Speaker 2: Más más fresco la moto la c 400 x 2026 cierto aquí viene 2021 2020 2021 2022 2025 mira aquí viene 2025 cuesta 10.000 euros 10.000 euros en Chile, Una 2025 c-400x es urgent estoy reunido decíame una una nota de audio a un WhatsApp si vos vale de acabar tomé una cerrada.
Speaker 3: Cuesta 10.000 esta supongamos que tú me la voy a entregar en 7.000 voy a poner un número no sé tú, ¿Qué posibilidad tendría? Le quito el IVA, porque yo ese IVA lo voy a recuperar porque lo voy a exportar.
Speaker 3: Cierto? 7000.
Speaker 2: Mira, mira, ahora el informático me está.
Speaker 3: Espera.
Speaker 2: No, el informático me está abriendo una reunión. Ahora.
Speaker 2: Alberto.
Speaker 2: Bueno, te diría que bien, pero.
Speaker 6: Pero es que este tema ya.
Speaker 2: No, mira, yo solo os pido. ¿Podéis contactar con estos de Motor Flash?
Speaker 6: Pero Vosotros no sabéis si están haciendo las motos tendidas a través de esto.
Speaker 2: No, lo que yo no sé es de qué manera Proa tiene que informar o pasar. Los datos que sean a estos 2, el de Motorfly y el de porque al final tenemos anuncios que no se están publicando correctamente y lo que me dicen estos chicos es que pasándole nosotros estos datos que nos piden se hace todo automático.
Speaker 2: No lo sé, yo no tengo ni idea, es decir, Alberto, yo no sé cómo lo hace coches, yo les dije a ellos. Yo daba por hecho que la operativa era la misma que hacíamos con coches, entonces ahora tenemos motos. Pues entonces, ¿cuál es la operativa de motos? Yo informáticamente lo desconozco.
Speaker 6: Yo tampoco sé cómo los vendedores anuncian a quite que esa moto está vendida, porque esto es para saber los coches que están vendidos y los coches que están en venta, no,
Speaker 2: Y no, y para publicar,
Speaker 6: Bueno, motos y para publicar. Yo sé que antiguamente se hacía a través del fichero, un fichero que se subía al PIX, que es el servidor de que tramita la marca, y Avenid de este año, a mí me contacto yo en acá para cambiarlo en moto, me dice el cambiar proceso, en coches, perdona, que es el cambiar proceso, y se pone los cambios en un par de ficheros y confirmamos el que está funcionando. Entonces, claro, yo no sé tampoco cómo es la causística, la parte del comercial, cómo tienen que hacerlo, solicitarlo.
Speaker 2: Por eso yo os pido si podéis contactar con estos señores de Motorflash a ver qué es lo que necesitan de nuestro departamento de informática de soporte. Y a partir de aquí, si a mí me dais unas indicaciones de cómo proceder, yo lo haré. Pero al final, yo es lo que te digo, Alberto, yo hablo con estos de Motorflash y me piden cosas y datos y a mí me están hablando en chino.
Speaker 6: A su servidor de Motoflash está hecho, entonces.
Speaker 2: Perfecto, por eso yo ya se lo pedí a Miguel Vives, lo hablé con Pere porque a mí me están dando hostias de que no tenemos actualizado el portal de BMW y ojo, y nos olvidamos que el portal de BMW también, Muelca a motos.net y walapop.
Speaker 2: Claro, Pero yo necesito que Proadata me diga, Miquel, pues para publicar los 30 anuncios que tienes en la web oficial de BMW para duplicarlo en motos.net y Wallapop tiene este coste. Tenemos que hacer esta operativa. Yo necesito esto por vuestra parte también, porque yo si me dicen, yo hasta ahora estoy publicando los anuncios manualmente, picando todos los datos. Esto es a mí, como te puedes imaginar, me quita unas unas horas que si lo tengo que hacer, si me decís no es que esto es una operativa, mira, me lo como y lo hago, pero con las herramientas que tenemos y con y si en coche se hace de una manera, pues hacerlo igual en motos, me decís, vale.
Speaker 2: Vale, pues que te comenten los de Motor Flash cómo lo podemos hacer.
Speaker 2: Vale.
Speaker 2: Si hay Jonathan. Jonathan.
Speaker 6: Pero no te escucho, Jonathan, si estás hablando, ¿no? Vale.
Speaker 6: Yo en coches.
Speaker 2: No lo hacía yo en coches, hasta donde yo sé, está Marta, que es la responsable de tema fotos y que y crear anuncios. Ahora lo que es crear el anuncio en Doom. O duc en coches y luego ese anuncio que se vuelque a la cuenta de coches.net o lo que tengan coches es un tema. Al final en motos tenemos el doom bloqueado porque los 11 anuncios que metí la semana pasada están bloqueados por algún motivo que yo es que os puse también en copia en algunos correos yo al principio de meter los anuncios.
Speaker 2: Es que cada anuncio que metía tenía que mandar 7 correos a 10 personas en copia y nadie era capaz de ayudarme. Ahí fallaba algo y luego una en un momento era porque hay un tic rojo que tienes que poner tic verde. Lo ponía después, el tic verde se volvía a poner rojo, luego era porque no ponía disponible un clic aquí, lo ponías y volvía a fallar. Luego era otra cosa y yo ya me negué y digo, tío, no puede ser que cada anuncio que suba. Tenga que mandar 7 correos a 10 personas para que me ayuden y sea visible.
Speaker 2: Tiene que haber una operativa más sencilla. No sé, estamos en el siglo 21, el que me parecía tercermundista lo que estaba haciendo, que sí, que en coches cuelgan las fotos y ponen cuatro datos y ya se cuelga automáticamente, porque es que además en BMW con el chasis que lo pones y te coge todos los datos automáticamente, al final tú solo tienes que poner unas fotos actualizadas en un anuncio porque todos los datos ya están. Pues sí, o en el caso de usados tienes que poner los kilómetros, vale, pero no sé.
Speaker 2: Yo en este tema ya estoy un poco desesperado porque pasa el tiempo, pasa el tiempo, no tenemos la web actualizada. Yo intento actualizarla y me y tengo todas estas trabas. Luego me comentan que se puede hacer todo automatizado y derivar a otros portales. Pero también necesito de tu ayuda en ese aspecto, Alberto, que tú eres el que domina estos sistemas.
Speaker 6: Bueno, entonces es una ayuda de Kitter por parte de Motorflash, claro, no tienen que ayudar. Porque simplemente yo lo que hago esta es la misión entre Kitter y Motorflash. Hola, buenas. Qué tal? Cómo estás? Muy bien.
Speaker 2: Te has quedado con el nivel, no? Entonces, mi informático y nada. Esta buena locura. A mí me pasa esta buena, los despido a todos.
Speaker 2: Yo llevo medio año con esto, que los anuncios de moto. Igual estos se solucionan 15 días. Hago yo las fotos, yo me pongo en una plataforma. Y tiene su volante. Pero ni aún así va bien. Sí, lo entiendo. Cuáles son los portales más importantes? Coches.net, Wallapop. Y Wallapop. Y de motos? Eso, motos.net y Wallapop. Y hay uno de coches, que es coches.net. De coches no le pasa esto. No, ahí sí lo hacen funcionar bien.
Speaker 7: Esto que estábamos diciendo es que si ellos nos envían, si vosotros, o sea, quiter y vosotros nos enviáis el fichero con el stock de motos dentro de ese fichero y también las ventas dentro del fichero de ventas. Lo que vamos to hacer es que vamos a automatizar todo el interfaz, porque podemos crear ya las montas de manera automática, sin necesidad de que este Mikel hacen la creación manual. Hay una serie de beneficios, aparte de que la marca también recibe toda la parte de ventas y que Mikel en este caso tiene que dar las ventas de una manera manual, etcétera.
Speaker 6: Qué cosa, que sea, un fichero de encontrar como de mod con tres coches? O sea, quedar a dos. Vale, el problema es que mi tío no sabe cómo transmitir esa información hacia Kitter o cómo hacerlo.
Speaker 2: Más que nada porque yo no lo he hecho nunca.
Speaker 6: En coche qué lo está haciendo?
Speaker 2: Marta. Bueno, Marta o Rafa Romera, yo no sé quién lo hace.
Speaker 6: Pues sería encontrar a alguien que subiera esta información también para motos.
Speaker 6: Pues si puedes hablar con Marta o Rafa para que le pase información a ellos para que la puedan subir a Kitter.
Speaker 2: Al final, alguien de coches pasa el archivo de Kitter a Motor Flash para que todo se suba automáticamente. Es así y se actualice. Vale, pero. Yo, hasta donde yo sé, hay una chica en coches que sube manualmente cada anuncio de V o de coches.
Speaker 2: Entonces, lo que yo estoy haciendo en Doom ahora mismo yo lo tengo hecho, pero es que tengo 11 anuncios en Doom que están bloqueados y no sé el motivo por el cual está bloqueado y lo he hecho yo manualmente. Entonces, si yo lo hago manualmente y queda bloqueado. Cuando lo pasemos el archivo completo, no sé quién revisa o quién está encima de que esté subido correctamente.
Speaker 7: Claro, hay también hay 2 cosas, vale, uno es la creación de la moto como tal y se va a hacer de manera automática vía DPS, o sea, eso es lo que te hace es que te hacemos la creación base, vale, pero luego es verdad que tienes que entrar en DOOM y poner las fotografías y poner el precio, eso sí que. Necesario que se entre y se muere aquí. O sea, los datos que desde el DPS entonces los vas a actualizar de manera automática. Vale.
Speaker 2: Ok. Y coches vincula a coches.net y Wallapop?
Speaker 7: También, También. O sea, ellos tienen la posibilidad de hacer lo mismo, de hacer la exportación igual. Pero lo hacen. Por ejemplo, con nosotros.
Speaker 7: En coches.es, otros portales también lo podrían hacer.
Speaker 2: Ya, pero ahora no lo están haciendo.
Speaker 7: No te sé de ti, por eso tendría que hablar con algún compañero de exportaciones, pero puedo consultar.
Speaker 7: No te voy a decir si lo hace o no. Pero bueno,
Speaker 2: Yo al final, la problemática que tenía con los anuncios que subo en el portal de BMW, El delegado me ponía en copia a 3 o cuatro personas, ayudar a Mikel, ayudar a Mikel y cuando no era una cosa era otra y al final voy subiendo anuncios y por y por A o por B o por C ese anuncio no se llega a subir a la plataforma y ya no sé de qué manera lo tengo que hacer. Luego vosotros me nos pedís unos datos de nuestro de nuestra plataforma de data para vincular directamente desde Kite y yo ahí ya me pierdo, es decir, al final.
Speaker 2: Es lo que digo, Alberto, yo no soy informático, es decir, claro. Y yo, claro, yo lo comenté con los con Jonathan y con Cristian, que trabajábamos igual que con coches, exactamente igual, y que la información y todos los permisos o lo que se diga estaba ya hecho esta parte. Entonces.
Speaker 2: No sé de qué, no sé de qué manera podemos trabajar como trabajan en coches y no tener la problemática de que los anuncios no se suben y no sé.
Speaker 7: Mira, os os, si queréis hacemos la consul, voy a compartir pantalla y lo vemos aquí en 2 segundos, vale, me tengo que conectar 1 segundo a la VPN.
Speaker 7: Que os lo muestre, pero si me dais, dos segundos me conecto y así lo recordrá. Y en la móvil free. Es posible que me desconecte dos segundos para desconver. Esperemos que no, pero. A presentar un poquito. Ya ha sido un ostra.
Speaker 2: Tú Te imaginas, seis meses después, tener que estar con esta forma. Teniendo una empresa de programadores informáticos? Aquí está la solución. Yo se lo digo a mi gerente, digo tío, al final yo puedo hacer un trabajo de chino, de surf. A eso a lo mejor tenía a alguien que cobre el mínimo y tú te preocupas de lo que es relevante. Tú no podías estar haciendo ese trabajo porque es carísimo, que tú lo hagas. Es que además que tenemos la herramienta para que coja de un programa. Está mal hecha la herramienta.
Speaker 2: Es exportar. Está mal hecha la herramienta, ¿sabéis por qué?
Speaker 2: La conectividad que tienen no está correcta.
Speaker 2: Dile, pregúntale cómo tienen las integraciones entre esa plataforma interna que se llama. Cómo se llama la plataforma? Motorflash. Motorflash es la de ustedes? No, la externa. No, la de ustedes. Cuál es la donde ustedes cargan? Kitter. La integración entre Kitter. Y motos.net y no sé cuál es la otra. La integración es la que está incorrecta. Ahí está la falla, ahí está el bug. Sí, es que no la hay. Es que ahí está el bug.
Speaker 2: Con ese bug solucionado, está listo.
Speaker 2: Nosotros lo hicimos en Chile. Yo lo ocupo. Yo tengo mi plataforma que se llama Go Auto. Yo ahí ingreso todo. Y aprieto un botón y lo publican en el coches.net, y lo publican en el Instagram, y lo publican en el Facebook,
Speaker 7: Y lo publican en todos lados. Y estos son los ficheros que recibimos todos los días,
Speaker 2: Veo que aquí tienen,
Speaker 7: Son los de ventas y estos son los de stock, vale, que de hecho mira, voy a descargar 1 segundo, pues ahí mismo y os lo muestro, se va a descargar aquí y os lo muestro, 1 segundo que pongo aquí.
Speaker 7: Vale.
Speaker 7: Fijaros, son estos dos, ¿vale? Yo los voy a renombrar, a renombrar, añadir texto, a renombrar. Voy a aplicar todo. Vale. Entonces ya hago estos dos.
Speaker 7: Abrir.
Speaker 7: Tienen un formato raro, por ejemplo, lo voy a poner para que se pueda ver bonito. A ver un segundo. Me pongo aquí, datos, de estos en columna,
Speaker 1: Y satan, datos, que.
Speaker 7: Recibimos aquí, vale. Este por ejemplo es el de stock, vale. Y este de aquí es el de ventas, vale. En el stock recibimos todos los bastidanos. Esto es un Mini, esto es un BMW, entonces recibimos aquí pues todo lo que hay en nuestro inventario de stock. De momento solo recibimos coches, fijaros que aquí no estamos los recibimos WB1, M3, M4 y son motos, ¿vale?
Speaker 2: Vale, pues aquí, ¿quién es Alberto que puede pasar este archivo de motos? Porque al final es poner.
Speaker 6: Un consejo.
Speaker 6: Porque al.
Speaker 2: Final en Kitter poner un claro, es poner el concesionario 87 que es motos y descargar este fichero.
Speaker 6: Actualmente quién es y pues.
Speaker 6: Pase la información de las motos que tenéis disponibles, yo lo que queréis crearse y añadirlo aquí, como he dicho, señalando la información que me tiran.
Speaker 7: No es necesario que pongáis ninguna información separando de coches de motos, sino que estos datos ya salen directamente de manera dinámica desde vuestro DMS. En cuanto compráis una moto, pues se vende directamente con el stock de vehículos, vende aquí, vendéis la moto y también todos los datos pues de la misma manera. Cuando nosotros recibimos esto, ¿qué hacemos con los coches? Para poner un poco el símil, ¿no? De lo que hacemos con las motos. Le damos de alta con el bastidor y con las consultas que tenemos a marca, los datos de BNU y las consultas interactivas que tenemos nosotros, de base de datos, pues sacamos marca, modelo, versión, equipamiento en serie, opcionales, lo publicamos, dejamos toda la información hecha.
Speaker 7: Aquí, como vais a ver, no tenemos precio de publicación, Qué hacen los responsables de vehículos? En este caso, entran en el Doom, no ponen fotografías, ponen precios, aparecen kilómetros. Y es donde iba yo, Jonathan?
Speaker 2: Perdona que te interrumpa. Una vez te pasan este fichero desde Proa, solo entramos al anuncio para actualizar fotos, precio y kilómetros. Así de sencillo.
Speaker 7: Exacto, pues todo esto se va a repercutir en los portales en los que publiquéis. Imaginaros que vosotros tenéis con nosotros, nosotros como fuente de vuestra web, por ejemplo, vale, sea un XML que os exportemos toda la información, lo que os decía, como de duestra unificados, equipamento, todo se exporta directamente, fotografías en el barco de dirección que os lo mandéis, etc. Todo se manda a ese portal, sea coche componente, sea otra web, sea motoflash, sea la que sea.
Speaker 2: El portal principal, Jonathan, es. BMW Premium Selection, correcto.
Speaker 7: BMW Premium Selection para coches, BMW, para vosotros. De acuerdo,
Speaker 2: Y a partir de aquí se.
Speaker 7: Y entonces, claro, a partir de aquí, solo por por concluir, entonces, una vez que vosotros modifiquéis toda esa información de manera que va a repercutir en esos portales, es uno de ellos y cuando se venda en la moto, en este caso, vale, una vez que esté vendido, Tú tampoco la tienes que ir a la rebaja, porque el propio proceso que importa, estos coches de aquí, los va a dar rebaja. Claro. Te explico? Sí, sí.
Speaker 7: Con lo cual, al final, lo único que tendrías que hacer es el reporting de ventas. O sea, como las venta ya se dan de alta, lo único que sería cerrar la venta, ¿no? Con los datos de diez y demás, que esto para el artillano de la marca es importante, pues ya lo tendríamos todo concluido. No es necesario que estés creando una marca, modelo de versión, poniendo fecha de manipulación, fecha de fabricación. Todo eso se crea directamente en nuestra base de datos por procesos semiautomáticos, no entre agentes y el propio robot.
Speaker 7: Y a quién?
Speaker 2: A quién notificamos nosotros que, por ejemplo, en mi caso, el stock de motos lo quiero duplicar en Wallapop y motos.net y el número máximo de anuncios, el tema de costes, eso cómo va?
Speaker 7: No, no te preocupes, coches.net está incluido, es decir, tú directamente si nos das los datos de tu cuenta de Motos.net nosotros ya podríamos exportar de manera gratuita. En coches no es gratuito, vale, aquí Motograd, o sea el equipo de Miguel, la niña, no, Borja, etc. Os va puliendo ya. De acuerdo. Es una formación gratuita para vosotros y se puede hacer. Igualabot?
Speaker 7: Ahora en la pasarela, que también es muy reducido, pero como en Motos. En contacto del equipo que se encarga de hacer, digamos, la exportación de las motos al portal también o se arriba al mundial, no hay ningún problema. Te cuento, solo por matizar, ¿vale? Como en algunos portales hay una invitación de slots que vosotros hacéis, o un stock de 50 motos y has contratado con Motos.Planet 15.
Speaker 7: Nosotros no publicamos las, Fotos en esos 15 espacios te la mandamos al backend y del paquete solo tienes que ir a hacer clic en cual quieres publicar cuando.
Speaker 2: Claro, lo que yo no sé si es que ahora mismo solo tengo 10 disponibles porque tengo 11 en cola que me harían un total de 21. Y no hay manera de que se publiquen. Entonces, no tengo información de el mínimo de anuncios que tenemos disponibles, ni de costes, ni nada. Para poder también.
Speaker 7: Vosotros Tenéis suelta ahora mismo en un motor punto en el concierto?
Speaker 2: Bueno, compartida con Proabikes. No, de Motorrad BMV directamente no.
Speaker 7: Te doy aquí un punto adicional, que no, Si para vosotros es importante o no.
Speaker 2: Es muy importante. Necesitamos tener la. Sí.
Speaker 7: No sé si trabajan vosotros, pero ya que tenemos ahora el interfaz en el que se van a dar de alta las motos, nosotros tenemos un servicio donde podemos crear motos multimarca también, que son las que tienen Proabikes.
Speaker 2: Sí, no, no, pero yo. Me centro en BMW Premium Selection. Al final Proabikes tiene que ir por por otro camino.
Speaker 7: Por otro camino, parece. Sí, Si es solo para ti, es lo que sí,
Speaker 2: Vamos juntos, pero yo necesito los anuncios correctos de BMW ocasión y bueno, y todo el stock que tengo de BMW.
Speaker 7: Pues esa es la opción que nosotros tenemos, vale, entonces ahí sería, pues eso, comentar con poster MS, con Kinter Manuel. No sé si podéis hablar con alguien de Kinter Star, creo que son. Libia, Sandra, Manuel, Manuel Mesones. No sé si le conocéis? No, yo no. Qué contactos a lo mejor tenéis allí a Alberto?
Speaker 6: Yo lo sé todo a Manuel, compartiré también de coaches con Hugo, pero a Hugo no sé si es Ayer.
Speaker 7: O no le conozco, pero a Manuel, vamos, podemos liar con ellos sin ningún problema para el tema de incluir las fotos en.
Speaker 2: Pues Si me podéis mandar detallado el volumen que tenemos contratado de anuncios y cómo va el tema de costes y demás, me haríais un favor. Yo ahora yo pregunto a coches cómo, quién se encarga, quién lo vincula y lo vamos gestionando.
Speaker 2: Sí, a ver quién es. Saber quién es la persona responsable de pasar los ficheros a Motorflash y que esa persona pueda duplicar otro fichero, que es que es el mismo programa, es poner cambiar un código y tienes lo mismo. A mí si me dicen cómo va la operativa lo hago yo, pero es que es lo que digo, yo no lo he hecho nunca y no soy informático.
Speaker 7: O sea, entiendo que no va yo a. Mucho tiempo de hacer la activación, porque allí ya tenéis las bolsas esperadas, cada vez que. Por eso,
Speaker 2: Y también te pido, por favor, si nos puedes confirmar qué volumen de anuncios tenemos contratados o disponibles y los costes y demás, porque es eso, me duele los ojos ver que solo tengo 10 anuncios publicados cuando tengo 11 en cola y tengo 10 más para subir.
Speaker 2: Vale, por supuesto. Vale, pues no sé, pues muchas gracias. Vale, yo enseguida, enseguida me confirmen esto que he comentado, os lo digo, y tú, Jonathan, si nos puedes pasar de Motorrad nuestro estatus a día de hoy de lo que tenemos contratado y los costes y pues te lo agradezco.
Speaker 7: Vale, te voy a poner los costes de lo que sería la exportación, por favor.
Speaker 7: Muy importante confirmar que vamos a utilizar la. Que votos. Qué probáis?
Speaker 2: No, No, lo de probáis.
Speaker 7: Y que nos confirméis en este caso si son las que son motos o lo que sea. O os van a pedir información del equipo de exportaciones de "oye, ¿nos podéis dar acceso a vuestra API de votos.net, etc. Para que puedan hacer el proceso automático?" Perfecto. En la parte de motos.net no hay ningún coste, ni coste solo hay en la parte.
Speaker 2: Ok, pues muchas gracias, Jonathan. Me quedo a la espera, Vale.
Speaker 2: Muchas gracias.
Speaker 7: Venga, Hasta ahora.
Speaker 2: Estoy Desesperado en esto.
Speaker 3: Me estaría desesperado si tengo un tercio de mi stock publicado, porque significa que tengo dos tercios perdiendo dinero todos los días y después contabilidad te va a venir a reventar. Por los días de inventario de productos que no existen, si no están en la web no existen,
Speaker 2: No lo puedes tener ahí, no existen. Están en la web de Proabikes hay una parte del stop. También ahí estoy un poco porque por una parte la empresa me hace ir de la mano con Proabikes, que es la empresa de ocasión de motos. Yo como marca tengo que tener BMW Premium Selection. Alimentar la web de Premium Selection y luego derivo, obvio, pero tengo que tener la de Premium Selection. Correcto. Lo que pasa es que Dutrello parte en Premium Selection.
Speaker 2: En Premium Selection tú debes cargar y Proa Bikes debe tomar la información de Premium Selection sin tú hacer nada. Correcto. Y la carga en Premium Selection deberá ser así cuatro fotos, especificación técnica, año de kilometraje, el dueño, el motor flash, es decir, Kitter. Tú le pones el chasis, sale todo como nosotros, le ponemos la placa y aparece todo, marca, modelo, año, kilometraje, claro. Tú solo tienes que poner precio, kilometraje y fotos.
Speaker 2: Por eso te digo, pero no funciona.
Speaker 2: No funciona, yo ya no sé cómo hacerlo. La idea es buena, pero no funciona. Bueno, nosotros tenemos Go Auto, que justamente hace eso, nosotros subimos la foto y ponemos la placa, la placa patente, como son usados. Y con eso identifica todo. Y si se revisa de repente que se puede equivocar en algo, no sé, que decía 4x2 y era 4x4 o 4x4 y bueno, pues hace una revisión súper rápida. Y con eso luego vamos a un apartado acá y como el Motornet, hay uno que se llama Chile Autos, para publicar en Chile Autos, publicar en Lince, publicar en Yapo, publicar en Mercado Libre, hago los clics y lo hace automático, pero eso de hacerlo manual, manual, manual.
Speaker 2: Bueno, Tengo que ir con los tres. No, sí, yo creo que tengo un montón de tiempo. La de la moto. Y lo que mañana vienes a poner el case o. Sí. Cómo no. Sí. Te aviso cuando llegue.
Speaker 3: Y la moto esta que te llevo la dos mil veintiséis avisa realmente.
Speaker 2: Empezar a hacer una relación.
Speaker 7: Qué es.
Speaker 2: Un emit de Marisol?
Speaker 2: Venía a buscar mi funda, ¿o no? No, no, la.
Speaker 6: La Funda de la moto. Cómo se llama? Ah, el top case.
Speaker 2: El Único que había para esa marca me dijeron que para ese modelo había una. Me dice que no hay, que llega mañana, 26 de junio de 2026, debe ser.
Speaker 7: Como esta, parece.
Speaker 3: Como este, es como este, parece, ¿no?
Speaker 2: Bueno, me dice que lo voy a leer mañana, 26 de junio de 2026, sí.
Speaker 3: Hola.
Speaker 3: No sé, estoy con.
Speaker 3: Oye, esa. No. Cuál era? El qué? La que había visto yo antes.
Speaker 3: Estaba aquí recién. La primera por la que vine.
Speaker 3: No, está ahí.
Speaker 2: Por la que yo vine inicialmente. Sí, estaba ahí. Esa es, esa es 2026. Esa con rojo con la calamata.
Speaker 3: Puede ser realmente el mejor precio que puede sacar eso para hacer el ejercicio con Chile.
Speaker 2: Yo te diría precio export. Pole Pole 7000.
Speaker 2: Tú piensas que en web está sin transporte, sin traspaso, que son 350 y aplicando. Una comisión financiera que serían unos 1000 EUR. El precio de coste de esa moto serían 7707 7 de esta moto, donde esto es la tuya, no te voy a por la junta.
Speaker 1: O sea.
Speaker 2: Que si yo le quisiera llegar a Chile me pegaría más de 7000 es que el precio de coste es más no por eso por esa el precio de coste son 7 IVA incluido si yo lo calculé con 7000 IVA incluido, El precio de coste. Me quedaba en Chile en 9000 y fracción. Ahora te lo pongo en el WhatsApp, te pongo el precio de coste. Porque esa es 2026? Sí, de la de 2026 vale.
Speaker 2: Me gustaría hacer una prueba económica y si pierdo dinero, bueno pierdo dinero pero hago la prueba. No, te paso el precio de coste y te digo esta te quedaría así y haces. No llevo el ejercicio de comprarla, llevarla, moverla. Tendría que darte el casco. Lo gestiono mañana, 26 de junio de 2026. Ah, claro, te tengo que dar el tuyo. M. Quieres la que eres M?
Speaker 2: Voy a mandar. Y como va a ir este, dos. Dos M,
Speaker 3: Porque voy a poder ponerlo uno ahí.
Speaker 2: Ah, ¿quieres dos? No, no puedes. Si pones este casco. Ah, en el top C, perdón. Quieres dos cascos? Talla M, color blanco.
Speaker 2: Y este anda de maravilla.
Speaker 2: Ah y hay que hacerle lo del computador a esto.
Speaker 2: Que al 2016 no voy a poder llegar, está difícil.
Speaker 2: Bueno mira, cómo sabes si en una de esas terminamos haciendo un negocio.
Speaker 2: Wallapop. Ese era? Sí. Qué es lo que es Wallapop? Portal de venta de ocasión de todo, de todo, un after market, de todo, ropa, todo, cualquier cosa. Bueno, voy a dar una mano a los chicos. Gracias por tu tiempo, perdona. No, no, faltaría. Es un placer compartir tiempo con. Mira, es que yo estoy de vacaciones, entonces distinto. En Chile duermen todavía.
Speaker 2: Te confirmo mañana, 26 de junio de 2026, y vienes en un momento, ¿te parece? Gracias.
Speaker 1: Hola.
Speaker 2: Protector para el calor para el asiento?
Speaker 8: Lo Único que tengo, digamos, es para hacer el asiento más cómodo, pero para protector el asiento no tengo nada Más.
Speaker 1: Y guantes de verano?
Speaker 1: Solo las calles que hay acá.
Speaker 8: No sé si está allí fuera otra. No puede ser que lo tenga arriba.
Speaker 6: Es que he visto que está en la talla L.
Speaker 8: Ah, donde lo tengo arriba,
Speaker 6: Pero abajo para todas. Claro, de ese de aquí, que tengo el de aquí delante,
Speaker 7: La X. Y no sé si hay mucha diferencia entre este que es más deportivo, o el otro que es más.
Speaker 8: Y el de arriba, pero, ¿eh?
Speaker 1: Con una.
Speaker 3: Talla Menores ¿No?
Speaker 8: Es el único que tengo.
Speaker 3: Cuándo Debe ser las medidas que uno hace que cómo vamos ahora?
Speaker 8: Yo también.
Speaker 3: Para Que te vayan.
Speaker 8: Bien, tienes que sobrar un poco de delante, pero un poco, y te tiene que ir ajustado, o sea, no te tiene que apretar como para que te haga daño,
Speaker 1: Let me know.
Speaker 8: Thank you.
Speaker 8: Cortana.
Speaker 1: You, bye bye.
Speaker 1: Chat.

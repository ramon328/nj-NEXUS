---
tipo: plaud-resumen
tags: [plaud, resumen]
autor: plaud
fecha: 2026-06-18
---

# Conversación: Viaje familiar a Mallorca y preparativos diarios

<mark style="background-color: #F9EDD4">[Speaker 1]: Recordar algo importante desde el día 12 comencé viaje familiar más que vacaciones, porque sigo entre trabajo y actividades familiares para la contextualización de los mails que se va a recibir nexos.</mark>
[Speaker 1]: Es importante esta declaración. Desde el día 12 estamos en formato viaje, vacaciones visitando a la familia en Mallorca. Entonces estoy en un modo diferente a mi día a día de del trabajo diario. Estoy entre el trabajo, el viaje, actividades familiares, etcétera.
[Speaker 4]: Yo Tenía Un pezón de crepes.
[Speaker 1]: Yo ando con mi hijo.
[Speaker 5]: Papá.
[Speaker 5]: Adivina qué. Alcancé a tocar el gatito que se me escapaba.
[Speaker 1]: ¿Verdad, el negro? El de rayas.
[Speaker 5]: El de rayas, se me escapaba siempre así.
[Speaker 1]: No me de las manos.
[Speaker 4]: Yo no lo toqué pasa. Venía Toni, siéntate con nosotras si se puede. No, sí, sí se puede. Estaba muy contento que tenía el gato.
[Speaker 1]: Ah, Bueno. Le tocaste al gato, se le arrancó.
[Speaker 1]: ¿Aló correando? Sí.
[Speaker 3]: El Tani se fuga a comer con. Con.
[Speaker 3]: Y le estaban comiendo el de la mi mamá y la.
[Speaker 3]: Unos rollitos de chocolate blanco comer un comer un puras tonteras entonces de esos rollitos de Mani no sé lo que estoy sintiendo acá.
[Speaker 4]: Y esa va la cosilla, la hacela papi.
[Speaker 5]: Querida en el día de la madre en su vuelta cuando.
[Speaker 3]: Diente esta agüita. Después de que se vaya.
[Speaker 1]: Dame una.
[Speaker 3]: Vuelta a mí, porfa.
[Speaker 3]: Ya me la tomé pues hija papá si te metes papá qué? Si te pones esto no puede ser bien.
[Speaker 1]: Sí, sí puedo ver bien. Si me ayuda a los ojitos, hija.
[Speaker 1]: Okay. Es que tengo un problema en los ojitos. Cómo que me ayudas?
[Speaker 5]: No, No es para el niño. Te vas a bailar, Diego? No. Es que tendrías que ponerte en tu País.
[Speaker 1]: Justamente ahora. Te compras en mi vida. Mira mi amor. Dígame. Ya cacha la diferencia de la charlas ojeras. Dónde dejaste la.?
[Speaker 1]: Te compraste otras dos? Mira, ¿dónde están las de.? Mira en esta parte de este pie. Esta parte a las otras. Las de Lego. Esa cosita está para afuera, no está un día. Y eso es lo que me hizo y me empezó a romper.
[Speaker 1]: Está igual. No, mira, tráelo. Está puesto el que no. Está igual. No, está hacia afuera, mira aquí. Aquí está un día y está hacia afuera. Aquí está justo. Eso es lo que me hace romper. Y acá está para adentro, entonces me pregunté que se por decir. No yo agregaría que un parche de esto de. De las típicas cosas de. De pie. También te pasa?
[Speaker 3]: Cuando me pongo esto, pero si me lo quito me queda así.
[Speaker 1]: ¿Sería cómodo, esto? Yo lo ocupo con eso, yo lo ocupo así, más cómodo.
[Speaker 3]: Porque si no me empiezan a volver.
[Speaker 3]: Yo ahora si no me muevo nada, ni siquiera siento que tengo algo yo que decir.
[Speaker 5]: Papá, Pontemos todo esto. Contemos todo esto, a ver, mira las dos. Uno en el balcón, porque si la vemos llegar, ahí sí que está.
[Speaker 3]: Papi, me pasas la tarjeta para abuelo. Ya, bueno, mejor te la doy. Pero si se me pierde.
[Speaker 3]: En mi caja de la ¿Hasta.
[Speaker 3]: Dónde lo bajaste hija?
[Speaker 3]: ¿Dónde mi amor?
[Speaker 1]: Les pido un favor. Les voy a sacar un poquito alto que tengo aquí. No me pueden tocar nada, ni mover nada, porfa. Porque estoy haciendo una prueba. No me pueden tocar nada ni mover nada.
[Speaker 1]: Estoy haciendo una prueba de unos audífonos, a ver si puedo comprar una cajita y arreglar.
[Speaker 2]: Ya, me.
[Speaker 3]: Has visto que Te peinas.
[Speaker 3]: La bolsa, no es la de mañana, la de los reyes. Y en la naranja que te regaló el papa que es para la piscina o no la va a ocupar? No, a esta la voy a ocupar para ir a la playa.
[Speaker 3]: Esa la voy a ocupar para ir a la playa. Y para otras ocasiones. Ahora quiero llegar a los tamaños.
[Speaker 2]: Un beso.
[Speaker 4]: Belenita hija no.
[Speaker 1]: Se solucionan las cosas así con eso de loca. Cálmate. Tenemos que estar todos aguantando tu grito.
[Speaker 3]: Yo no voy a arreglar.
[Speaker 3]: A ver.
[Speaker 4]: ¿De qué color las de la? ¿De dónde ha sacado ese? Ese es el de la Helena? No, no te lo prezco. Yo voy a buscar el tuyo. Escúchame. Ese es de la Helena. Ah, pero está mío. Lo voy a buscar. Y esto ¿de qué es?
[Speaker 4]: Yo voy a buscar el tuyo ahora, hija. Cálmate.
[Speaker 3]: Sí perfectamente porque.
[Speaker 3]: Llevaré un libro para leer que me trajeron los Reyes Magos, mira, yo quiero un libro, se llama unicornio, un baile hechizado, unicornio, un baile hechizado, un colegio de sangre así que me lo voy a llevar.
[Speaker 3]: Es que esta para que yo venga.
[Speaker 3]: Ya, pero. Hice algo para que fuera.
[Speaker 3]: Para la sal Elizabeth, esa cosa. Para atrás.
[Speaker 4]: En esta parte de arriba, en el primer, ¿hay es? A combinarlo Con.
[Speaker 3]: Con la parte de arriba.
[Speaker 3]: Mira, traigo un libro y tengo un squishy y también traigo la tarjeta.
[Speaker 3]: Juguete.
[Speaker 3]: ¿Sí? Por ahí no.
[Speaker 3]: La tarjeta para abrir la puerta de los de papá que me la dio.
[Speaker 3]: La llevo ordenada, la tarjeta la tengo.
[Speaker 3]: Este sí que no lo vas a tener y es de los que brillan en la oscuridad, este no lo vas a tener. No, pero la la versión puro.
[Speaker 3]: Porque acá traigo muchos juguetes para que ellas jueguen.
[Speaker 3]: Y para ella pues. Oh, sí, lo tenía. ¿Tú tienes?
[Speaker 3]: No,
[Speaker 3]: Chicos, adivina qué está recién ya.
[Speaker 3]: Elizabeth Mamá,
[Speaker 1]: Vamos a las once y nueve las once y media dijiste que venía mi amor?
[Speaker 3]: En Cualquier minuto llega mis lentes con sol para que no quede mucho se nos cree. No, en cualquier minuto llega.
[Speaker 3]: Yo llevo un libro para leer un chapuzón en la piscina Lo llevo todo ordenado ¿Por qué es que estaba diciendo? Mira, mira lo.
[Speaker 1]: Mío La mesa, ponga atención ¿Y la mesa es para subirse?
[Speaker 1]: ¿Para qué son las mesas? Para subirse arriba?
[Speaker 1]: No es.
[Speaker 1]: Para Subirse arriba, es para poner cosas. No es para subirse Arriba.
[Speaker 3]: Apoya las cosas que estaban.
[Speaker 1]: Yo a Nicole le pasé la que encontraste en el bolso. Tú tienes la tuya.
[Speaker 1]: Pero deberías tener la tuya. Yo la que me pasaste en el bolso que encontraste, se la pasé a la Nicole. Yo tengo la amiga que tenía en mi billetera Acá.
[Speaker 4]: No, pero aquí está.
[Speaker 1]: Pero entonces la perdemos.
[Speaker 1]: Mi amor, las toallitas de alcohol, no voy a pasar una puna un pequeño.
[Speaker 5]: ¿Qué? Necesito toallitas de otras toallitas. ¿De cuáles?
[Speaker 5]: De las de bebés.
[Speaker 1]: ¿Dónde están las de bebés? Las de bebés están en.
[Speaker 5]: El baño. Están en el baño móvil.
[Speaker 4]: ¿Y Tus lentes elen dónde están?
[Speaker 1]: De la niña bareciana.
[Speaker 4]: En el váter, hija, ¿dónde está el váter?
[Speaker 3]: Con jabón no.
[Speaker 1]: Está limpiando, abejas sucias.
[Speaker 1]: Ah, la boca, a ver, mírame. Tu boca.
[Speaker 1]: Pero estás preciosa. Un besito, papito. Te amo.
[Speaker 4]: ¿Quieren bajar bien? Vamos.
[Speaker 4]: Para pasar delante del hotel suele haber sitio y si no, a la vuelta en ambos. Si aparca a la vuelta, mira a Juanjo que trata de estacionarse en el sentido por dentro de la calle, porque la calle se está haciendo en sentido contrario de mujeres el otro día, ¿vale?
[Speaker 4]: Está esperando que llegue el Juanjo que había ido al banco. Parece que no sabe que el banco lo abren a las 8 de La Mañana.
[Speaker 4]: No hagas eso con los lentes porque se rompen. Todavía no han salido de su casa.
[Speaker 4]: ¿Quieren bajar o quieren estar aquí preguntando cuando hayas escuchado en su casa esperando a que llegue el papá de la Sara Elizabeth para que las traiga?
[Speaker 4]: No, hija, pero tengo las camillas reservadas de adorno, con los adornos para que estén más abajo. Ya, vamos y vamos. ¿Tú lo paras ahora, papá? Sí, un ratito. Ya vamos un pichurrí. Los lentes saca los de ahí, Clara.
[Speaker 4]: ¿Te los pones?
[Speaker 3]: Que para eso son. ¿Por qué están? Morado. ¿Por qué esto es morado? ¿De quién es?
[Speaker 3]: Es morado.
[Speaker 1]: Pero si.
[Speaker 3]: Hizo rosado. Tendría que ser rosado. ¿Qué? Ella lo había pedido de rosado.
[Speaker 1]: No, ella pidió morado. Me estoy.
[Speaker 3]: ¿Volviendo loca o qué? Parece. Papá, en verdad, ella lo había cogido rosado. No, mi amor. Eso es rosado.
[Speaker 2]: Hey, Cortana, play "Play 'Up of Instagram'".
[Speaker 2]: YouTube.
[Speaker 2]: A.
## Resumen de la Grabación
La grabación captura una escena familiar ruidosa y caótica. <mark style="background-color: #F9EDD4">Al inicio, un hombre (Speaker 1) explica que desde el 12 de junio de 2026 se encuentra en un viaje familiar en Mallorca, compaginando trabajo y vacaciones, lo cual contextualiza su disponibilidad.</mark> Poco después, la conversación se llena de interacciones con niños y otros adultos. Un niño (Speaker 5) cuenta emocionado que logró tocar un gato, mientras se escuchan discusiones sobre comida, como rollitos de chocolate.
La conversación principal se centra en preparativos y objetos personales. Una niña (Speaker 3) habla sobre lo que llevará a la playa o piscina, incluyendo un libro de unicornios, un squishy y una tarjeta de acceso que le dio su padre. Hay confusión y discusiones sobre pertenencias, como un par de sandalias que causan molestias, unas bolsas, y la tarjeta del hotel. El padre (Speaker 1) pide en un momento que no toquen sus cosas porque está probando unos audífonos para ver si puede repararlos.
Hacia el final, la conversación deriva hacia la logística de salir. Una mujer (Speaker 4) da instrucciones para aparcar el coche cerca del hotel y menciona que están esperando a "Juanjo", que fue al banco. También reprende a una niña por jugar bruscamente con unos lentes. La grabación termina con una discusión sobre el color (morado o rosado) de un objeto y un comando de voz a Cortana para reproducir música en YouTube.

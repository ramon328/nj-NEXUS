---
tipo: plaud-resumen
tags: [plaud, resumen]
autor: plaud
fecha: 2026-06-19
---

# Viaje Familiar: Vacaciones en Mallorca y Anécdotas Cotidianas

Speaker 1: Estamos con viernes 19 de junio.
Speaker 2: Seguimos modo viaje, vacaciones y trabajo remoto pero en Mallorca.
Speaker 3: Ah porque está con la Recógelo tú.
Speaker 3: Lo levanta, me levanta ahí, sí, perdón.
Speaker 4: No lo sé porque no la conozco.
Speaker 3: Cuchillo por caído.
Speaker 5: Muy bien, mi amor.
Speaker 2: Por allá, por allá, por allá que se dan la vuelta. Por allá hija. No, por allá, porque yo tengo que abrir la puerta aquí.
Speaker 3: El agua ahora no el auto, hija.
Speaker 4: Oye, la pelota me la perdieron, esa pelota de colores que compré.
Speaker 3: Déjala Acá con el toque en la receptor. Le pasamos un lápiz.
Speaker 4: Estoy esperando para cerrar para ponerte el cinturón.
Speaker 2: Súbete, Clara.
Speaker 5: Qué falta que ha pasado.
Speaker 4: A tu hermana?
Speaker 4: Tú crees?
Speaker 2: Tú Crees que vas a poder hacer eso? Aquí el te manda el papá y la mamá.
Speaker 6: Hoy termina en el cole Natalia. Ay Natalia, la Socia y Mateo. Qué bueno por ellos! La terminamos la semana pasada. La Nicole y la Natasia coinciden?
Speaker 6: Estás en mitad de un curso a mitad del otro durante tu año, Nicole.
Speaker 5: Bueno.
Speaker 3: Pero ahora bajó.
Speaker 3: Yo le he bajado más de 40 dólares de dólares.
Speaker 4: Puedo hacerla todavía?
Speaker 4: Yo no quiero hacer. Te va a hacer bien. Desarrolla el aprendizaje.
Speaker 3: No, porque es verdad que te sirve.
Speaker 2: Esto no es diesel.
Speaker 4: Abre La tapita y yo le iba a decir. Esto no es diesel.
Speaker 3: Sí.
Speaker 3: No la tengo física, mi amor.
Speaker 6: Nicole, Préstale un poquito que.
Speaker 4: Tiene que pagar la mamá.
Speaker 4: Sí.
Speaker 4: 40, 50, no sé. Que me tengo cuántos se yen po.
Speaker 4: Chícale mi padre, ¿Cómo se hace? Ah, es que eso de nuevo por ponértelo muy cerca, hija.
Speaker 4: Si me.
Speaker 3: Tienes que tocar la pantalla, tienes que dejarla así.
Speaker 3: Vale.
Speaker 5: Qué quieres subir?
Speaker 3: El volumen.
Speaker 4: Puede ser.
Speaker 4: Puede ser que se llene con eso.
Speaker 4: Ponle un poquito más.
Speaker 4: No, no, pero mira, levanta un poquito la manguera y ahora aprieta.
Speaker 1: Mira, mi amor.
Speaker 5: No pudo?
Speaker 2: Contactó a treinta, sin hacer nada, no sé cuánto toques gastó. Da lo mismo, parece que hay un afectivo. Bájale, bájale, bájale. Estamos esperando, la mas estamos andando como loco Pero, muy buena esta, si sale Después se replica todos los días Y contacte, contacte, contacto,
Speaker 5: Chamo Mi teléfono no.
Speaker 6: Tengo llama.
Speaker 2: Viste que aprendió algo, que es fácil aprender?
Speaker 4: Si porque llena con 60 po Entonces.
Speaker 5: Está Vacío.
Speaker 5: Voy a averiguar donde haga.
Speaker 4: Hace la noche o no? 2017, sí. Este si yo me acuerdo de por ahí. Kenberg, en 2018.
Speaker 6: En 2018 nació la Nicole en septiembre.
Speaker 6: Ahora. Vamos a desayunar primero en.
Speaker 6: Tiene derecho todo. No. Nos vamos a una playa de rocas. Si vamos a la playa es la de arena fina, todas son de arena fina por aquí.
Speaker 4: Voy a jugar con sus bolsitos de. Se le están a la maleta.
Speaker 4: Se señorita es que los tres.
Speaker 4: Ojo! Esos sonaron esos y se les pasaron todo lo que pasa.
Speaker 5: Sí, iba.
Speaker 3: Cuando trabajaba en la fecha.
Speaker 6: Puedes estacionar?
Speaker 3: Sí, si está.
Speaker 3: He venido a trabajar como se ha guardado. Está en la pomar ese y no.
Speaker 3: Acá acá a desayunar ¿Qué Cosa?
Speaker 4: Ya nada más de tablets no, nada más de tablets en el bolsito.
Speaker 2: Eso ahí pero bloquéale la pantalla, bloquéale la pantalla.
Speaker 7: Por qué nunca puedo desabrochar el cinturón de color negro?
Speaker 2: No, es un pareo ahí. Los pareos son para eso, para andar en zonas de playa. Si estamos al lado de la playa, mira que hay arena.
Speaker 2: Mira. La playa está cerca ahí. Esta es una zona de playa. No salta por ahí, parece, ¿no? Sí.
Speaker 3: Mira que bonita las sillas. Vieren acá las pequeñitas?
Speaker 4: Vayan a mirar allá lo que quieran pedir.
Speaker 4: Oye, mira, más país el perro.
Speaker 4: Vayan a mirar.
Speaker 3: Where are You?
Speaker 5: Qué, mi amor? Puedes venir aquí, por favor?
Speaker 2: Ah, ya,
Speaker 3: Un americano.
Speaker 3: Parece que.
Speaker 2: Quería una galleta que ya no hay. Esta es la oreja que queda. Y lo hay. Y también me hacen la cupita.
Speaker 2: Bueno, después compramos otra, pero esa pueden sacar un trocito y probar de todo.
Speaker 2: No les da cuenta el cremadillo. Siéntate ahí clarito.
Speaker 2: Elena, que te dije de las gafas. Van así. No, no te olvides, así nunca. Ok.
Speaker 7: Un.
Speaker 7: Una galleta muy buena.
Speaker 2: Pero cuando termines de comer, porque si no lo vas a ensuciar.
Speaker 1: Faltó un plato pequeño?
Speaker 1: Es incómodo, ¿no?
Speaker 5: Quiero probar.
Speaker 2: Un poco de este. La mamá lo va a cortar ahí, le va a poner un trocito ahí en cada cosa y todos comen de un poquito de cada.
Speaker 2: Cuidado. Endulzante tiene? Endulzante? Eso. O azúcar granosa o.
Speaker 2: No sé, ese es el único que tiene, sí. O azúcar blanco o azúcar moreno, pero si quieres. No, no, está perfecto, Gracias.
Speaker 7: La salsa no me gustó, pero es rica y cirugía.
Speaker 2: Puedo Ver un vaso con ella, no va a tomar.
Speaker 3: Me gustan las cositas.
Speaker 6: Este a ver vamos a probar clara. Ser rico, pruébalo el gran chino. Tal vez no tal vez no.
Speaker 2: Cómo eso tal vez no tal vez no?
Speaker 3: Qué significa tal vez no tal vez?
Speaker 3: Upa! ¿Y.
Speaker 6: Será Que ya lleva suficiente Esto?
Speaker 3: Igual que la cucaína que hago esto.
Speaker 2: Igual y haces igual de.
Speaker 2: No La hay fiesta nunca?
Speaker 2: Yo sí, he visto platos.
Speaker 6: También, pero lo que así como para darme cuenta que también hay una textura y todo. Cómo eso? No lo creo. Cómo eso?
Speaker 6: Puede dejar de hacerlo aquí, ponle las.
Speaker 3: Plicas, pues.
Speaker 3: Porque los mejores están perdidos y poquito.
Speaker 3: No pero yo no se raiga a la gente que está aquí. Porque no hay chistosa. Ya está bueno?
Speaker 2: No, Porque no. Exacto. Además tienes que entender que no sé, eso no es un motivo para reírse, ni para abundarse, ni para mucho menos para la gracia. Los mejores el señor está enferdito.
Speaker 2: De hecho, está enfermo.
Speaker 2: Una persona que está así significa que está enfermo, que sus juegan están enfermos.
Speaker 6: Se llama Cremaní, es muy bueno. Muérdelo, Clara, pero muérdelo, no lo despejes con las mantas, no tiene ni una gracia.
Speaker 2: Eso de los pueblos dónde dice,
Speaker 6: A qué hora es? En el polígono de Cambalero. En el polígono de Cambalero está cerca de casa de mis padres.
Speaker 6: Te acuerdas que una vez fuimos en un polígono donde harían con las náuticas de los niños? Hay un tan decarón y todo eso, me parece. Vamos a ver, algunas cosas Que Faltaban.
Speaker 2: Sí, en exacto.
Speaker 6: Celebrar que los primos terminaran en el curso escolar.
Speaker 3: Cuando Nicole terminó en segunda, en el primer trimestre.
Speaker 3: El chiste, el más corto del mundo?
Speaker 3: El del perrito que se llamaba Calcetín.
Speaker 2: Algún Perrito que se llamaba Calcetín. Salió a la calle y se lo pusieron Aquí.
Speaker 3: Calcetín se pone.
Speaker 3: El perrito.
Speaker 2: Se llamaba Calcetín.
Speaker 2: Como se llamaba Calcetín, cuando salió a la calle, lo tomaron y se lo pusieron.
Speaker 2: Dos tomates salieron por la calle y cruzaron por un lugar que no era el paso de cebra. Los atropellaron y quedaron. Ketchup! Un.
Speaker 3: Auto lo atropello.
Speaker 7: Y avisaron a su mamá y su mamá y pobre. El queso se lo enseñó el.
Speaker 2: Tata Hay otro chiste que se llamaba un niñito que se llamaba Cuchillo Salía a la carne y se lo afilaron Double San Que se llamaba un.
Speaker 7: Niñito que se llamaba Queso ¿Queso?
Speaker 2: Cómo el te crees?
Speaker 7: Había un niñito que se quedaba queso, y cuando se fue a venir, se encontró con un queso.
Speaker 2: Y se quesearon.
Speaker 2: Había un perrito que se llamaba queso, salió a la caña y se encontró con un gato. Y qué pasó?
Speaker 7: El gato se lo comió.
Speaker 2: Salió corriendo, el perro salió corriendo del gato, todo lo contrario de lo que pasó normalmente, el gato arranca del perro. Pero el perro cómo se llamaba? Queso. Salió arrancando. Del gato, porque al gato le gusta el queso.
Speaker 2: Para el ratón, está lo mismo. Me cojo. Me doy cuenta en algún chiste.
Speaker 2: Tomatela.
Speaker 2: Qué le dice? Espérate. Qué le dice?
Speaker 2: Sí, pero quiere irse un tomate otro tomate, Dijiste.
Speaker 7: Nos vendimos.
Speaker 7: Cállate perro.
Speaker 2: No le toca a Nicole ahora.
Speaker 7: Por qué los tomates no toman café? Están super buenas?
Speaker 7: Porque no tienen boca. Por qué los tomates no toman café? Porque no tienen boca. Porque toman té.
Speaker 7: Porque toma Té.
Speaker 2: No toma café. Si no sería un toma café o un tomafé o un toma café.
Speaker 2: Porque un toma café no toma café. Qué es eso?
Speaker 2: Porque un toma café no toma café.
Speaker 2: Porque toma café.
Speaker 2: Ya tú ahora a ver. La clara verdad. Pasto. Mañana te aplasto. Eso es una broma, no es Un Chiste.
Speaker 3: Elena, Elena.
Speaker 3: Girasol Girasol Giro,
Speaker 2: Girasol A ver, me lo giro Bueno, ando sin calzón Papá Porque tengo tarja de baño.
Speaker 7: A mí se me ve la gestión del traje de.
Speaker 2: Baño Bueno, tenme bañador.
Speaker 2: Me dijiste que era, pero no me dijiste la Hora.
Speaker 7: Me haces.
Speaker 7: Te cuento chiste. Es verdad.
Speaker 2: Que no me gustaba mucho, no sé por qué a ti te gustaba esto. Pasando de puerto.
Speaker 2: Hay una de esas que tu se promete a mi niño, yo digo. Pero me da lo mismo, cualquiera. Para que juegan los niños. Ah, ojo, no tenemos quitasol. Pasto. Ojo, que no tenemos quitasol. Pasto.
Speaker 7: Te aplasto. Te dije, pero nunca dije cuando.
Speaker 2: Oye, ¿Quién se va a comer ese pastelito que queda ahí?
Speaker 2: Agarrar esto para que no lo.
Speaker 2: Agarrara Ella y.
Speaker 2: Perdón.
Speaker 2: No, hay que hacer en los cojones.
Speaker 2: Se cayó porque quería agarrar esto para que la Elena no lo botara y terminé botándolo yo.
Speaker 7: Terminaste botándolo tú, agüita, chica.
Speaker 3: Tómalo con la manita.
Speaker 5: Cuidado, hija.
Speaker 3: Muchas gracias.
Speaker 6: Ahora Yo lo recojo.
Speaker 1: Con la escoba.
Speaker 3: Gracias. Me quedé sin café.
Speaker 4: Solo con el auto.
Speaker 4: Solo para que no se aburran en el auto.
Speaker 2: Solo cuando es para que no se aburran en el auto, dije.
Speaker 2: Y a quién se va a comer eso?
Speaker 3: No, ya no más. Nada más? Ya. Y tú? Nada más?
Speaker 7: Por qué dijiste pero dijiste que fuiste atrás del café? Dónde el café fui yo?
Speaker 1: Bueno, Nos movemos.
Speaker 1: Ya apagaste, no? Toma.
Speaker 1: Sólo para que te lo pongas.
Speaker 1: Ah bueno.
Speaker 5: Bing.
Speaker 2: Vamos niñas con la señora, cuidado con la señora.
Speaker 2: Qué?
Speaker 2: Pero vamos a ir a la playa ahora.
Speaker 2: Quieres jugar un ratito ahí? Ya un ratito, vamos. Un ratito a jugar ahí a los juegos y nos vamos a la playa.
Speaker 1: Vamos a mover esto.
Speaker 2: Nada. Que no era? Ah, no, no era ese el que pedí.
Speaker 2: Hay tres pocos, no era. Y esta tenía cuatro cosas. Ah, oye, te iba a decir. No puede ser también tus expresiones. Yo fuera la que atienda y te manda la coche.
Speaker 2: Muy, muy, muy pesada.
Speaker 2: Pero no hay nada de una forma. Forma de cerrar una basura.
Speaker 2: Si da lo mismo, pero di lo mismo, tiene la expresión de mirar en menos. Debe ser el qué? Y no son las 10. Son las 11 y media, casi al mediodía.
Speaker 2: Que después la gente empeza porque reacciona, no saben las personalidades de la gente.
Speaker 2: Con mayor razón.
Speaker 2: No, pero si cada uno tiene su cara que tiene.
Speaker 2: Mira que el choteo ese columpio que está ahí, para sentar a los niños, cachai, ha sido así, tenia puesta que este mes.
Speaker 2: Cachai? No lo.
Speaker 1: Había visto.
Speaker 2: Entonces ese no era, pero hay otro que se llama igual, que está en otro lugar. Mira, no sé si era la forma de ver cuál era el más recajado que yo.
Speaker 2: Recién hecho todo, recién horneado.
Speaker 2: Porque eso no creo que lo hagan a diario. O sea, con el tiempo puede ser que se haya convertido en eso. Creo que lo horneado a diario.
Speaker 2: Pero ahora qué? Habían hecho?
Speaker 6: Ahora me estoy desahogando las dos de la mañana y porque cada mañana es la misma historia.
Speaker 6: Con la ropa, cantidad de ropa que les he distraído para que cada día se puedan poner algo diferente y no tener que preocuparme de lavar y todo, tiene que ser rotella algo, y la misma polera y a conjuntar con el libre mañana.
Speaker 2: Pero Eso está bien. Te puedo juntar como les ve la gana, está bien po.
Speaker 6: No, no está bien, nunca le llevan unas tintas y no tienen ropa tan linda.
Speaker 2: Pero eso está bien po, porque da su personalidad.
Speaker 2: No está bien que esos cambios, lo que sí no está bien es que te obliguen a ponerle algo y ya está sucio, por eso no po. Pero si se quiere andar rojo con verde, problema de ellos.
Speaker 3: Está bueno el vientrecito.
Speaker 2: Bueno, les escribí a estos de, te parece que éramos tres esos mouse que eran como origamis?
Speaker 2: Les escribí y me contestaron al toque. My air. Ya le damos tres main. Quería ver la Página.
Speaker 2: Esta Es la página Estos?
Speaker 1: No me ves la página myrzero.com ahí está se aplasta cuánto van a estar.
Speaker 2: Mega cool.
Speaker 6: Que usarlo, solo para vender.
Speaker 2: No, obvio, pero para eso la compro. Pero si lo venden? No, eso quiero ver po, yo quiero gastar los precios, o sea cuestan como un mouse de Mac, no o no? No, el mouse de Mac vale más caro.
Speaker 6: Porque es lo que usted.
Speaker 2: Está en Chile.
Speaker 2: Entonces quiero saber cuánto es el costo, si el costo es la mitad o qué sé. Pero en qué se cuestan los mouse, un mouse de Mac vale, Y tanto los de marcas y porque son marcas este tiene su.
Speaker 2: Su especialidad a ver si yo le pongo de menor a la mayor se puede o no?
Speaker 2: Solspire yo.
Speaker 6: Creo que depende para el tipo de usuario es un diseñador.
Speaker 2: No, pero yo creo que esto es para lo cool. Creo que esto es para la gente cool, así onda. El universitario con plata, recién salido, que ese cómplice da el gusto y quieren andar con su mouse cool. El emprendedor, que toda la innovación, la tecnología.
Speaker 6: La Golpe podría dar su apreciación. El guían te podría dar su apreciación y tu tener la tuya de.
Speaker 2: O sea, yo lo veo como eso, como los niños, los jóvenes que tienen poder adquisitivo potente. Se piensa que nosotros tenemos veintitantos cabros, todos menores de 25 años y todos ganan plata. Sin decirle el precio,
Speaker 6: Solo mostales.
Speaker 2: Todos esos gallos, cachai, como son emprendedores, buscan la innovación, la tecnología, pagan por eso, cachai? Saben que se pueden comprar un mouse por 5 o 10 lucas, lo tengan claro. Pero pagan porque es, Algo innovador, algo diferente, algo el caché?
Speaker 2: De la guatita.
Speaker 6: Quiere agüita?
Speaker 6: Sí.
Speaker 3: Y dónde está la guatita? Para que no se acabe.
Speaker 7: Para que asuste la mama. Ah? Para que no se asusten.
Speaker 7: Es muy chistoso.
Speaker 1: Todo era barato. Todo. Que a lo mejor.
Speaker 2: Tu hace 20 años lo estabas lejos y la gente decía ¿campo? No, era casa, por eso te digo, es como las brisas de piedra roja yo compré, Cuando vieron el ok del paso porque dije ahora va a estar cerca ya no va a ser lejos porque antes era lejos que la wea está al lado no po, si era por la autopista autopista, autopista, llegaba poder ir a darse una vuelta así para ir a piedra roja y cachai entonces la gente lo consideraba lejos cuando vieron el ok del.
Speaker 2: Cuando vieron el ok del camino yo dije este es el momento antes que se haga vox populi.
Speaker 2: De comprar, porque los precios subieron y subieron un montón.
Speaker 6: Po' Tiene la cosita de limpiar o no? Acá no.
Speaker 6: Una rayita que no se si es rayado.
Speaker 2: O que. Y los terrenos han subido po' Yo creería que, no me acuerdo cuanto pagamos nosotros, pero 8 mil, 9 mil por el tarado Pero creería que hoy día un terreno no vale menos de 12, 15 según la zona, Porque creo que es la zona ese.
Speaker 2: Sí, porque estaban viendo de arrendado de. Ah, También. Qué bueno por los perros.
Speaker 6: A su casa el otro día.
Speaker 2: Ah, subió unas fotos de la Clara.
Speaker 6: Y unos perritos, pero ella no estaba, estaba la nana, que la nana era una iraní.
Speaker 2: Cómo entraron así?
Speaker 6: No, Ella había ofrecido que fuéramos. Podemos ir ahora y me dijo yo no estoy, pero está mi nana y está la Clara.
Speaker 6: Pis por todos lados. La casa o fuera? Tiene una pinta de malula esa niña y me dijo, perdona el desastre, pero es que estoy haciendo unas reformas, unos arreglos de no sé qué, dije, yo no he visto nada, no te preocupes en todo caso porque yo de la cocina no he pasado.
Speaker 6: Y le dije madre mía el trabajo que tienes aquí, Dios mío, pipí por todos lados a cada rato, porque la señora pasaba la pregona y dije no, pipí, pipí, me mandó un audio, sí, por eso es que estoy harta y ahora no puedo más, mucho trabajo y tal, así que yo me mudo, nos vamos.
Speaker 2: Qué tiene que ver eso los perros?
Speaker 6: Nos vamos, lo que dijo que se iba a vivir y la casa se la queda mi mamá para cuando venga de Suiza, pero que dijo que vivía el Suiza.
Speaker 2: No sé.
Speaker 6: Si lo dijo en el audio o no, es que habla muy rápido y no la entiendo.
Speaker 6: Cuando nos digáis.
Speaker 2: Sabes quería jugar un rato acá, habla con tus hermanas y se ponen de cuenta.
Speaker 2: Cómo se llama? Este que tenía un acento, yo te dije que tenía acento.
Speaker 6: A ver si la casa se la queja mi mamá y la está re haciendo. Me voy a mudar en un tiempo porque está lámpara en mi casa.
Speaker 2: Se Va a la de criadero la weá,
Speaker 6: Como decir. Yo quería el tarjeta duro.
Speaker 2: Oye, pero no puede ser esa weá po. O sea, en la casa la van a usar de criadero, y no, esa weá no puede ser. Porque si no viven ahí.
Speaker 6: Porque si una sinvergüenza esta.
Speaker 2: No, no por eso, pero si no van a vivir ahí y empiezan a tener el pico de puta, yo voy a reclamar. Porque la weá está bien que tenga perro y su perro lo cruce y ya, y haga su negocio. Pero que deje la casa para eso, ya esa weá es un criadero, a webi. O sea,
Speaker 6: Ya es un criadero.
Speaker 2: No, no, sí, pero por último, pero es un criadero donde vive ya. Pero más encima donde no va a vivir, o sea, lo va a usar como.
Speaker 6: Mi hijo me voy a vivir a los trapense. A los trapense. A los trapense dice. A ver, que yo no la entendí.
Speaker 2: Entonces no, esa weá sí que no me aparece. Ojalá que no nos genere problema, pero si se genera, yo voy a wear.
Speaker 3: Opa.
Speaker 3: No, no, pero el otro, así es.
Speaker 2: Hay que ir para adelante, ahora para atrás. No, pues, las piernas para arriba, las piernas para atrás. Las piernas para arriba, las piernas para atrás. Para arriba, para allá.
Speaker 5: Digo, mi.
Speaker 2: Amor, si tengo calor, vamos, pero están jugando. Tenemos apuro para ir a la playa. A refrescarte? Sí, pero mira, te voy a decir que este real. Cuando quieran hacer algo así hay que dejarlos que tomen hasta que lleguen hasta que lleguen aquí a decir estoy aburrido. Si no tenemos nada que hacer.
Speaker 2: Si es verdad po.
Speaker 2: Qué pesada.
Speaker 6: Yo no digo nada. Yo quiero aquí a mirar el cielo mío.
Speaker 2: Por ejemplo, a contemplar las piedras que son bonitas por lo demás.
Speaker 2: Por qué no se pueden mantener? Debe ser por el clima, ya no se mantienen así de limpias las cosas.
Speaker 6: Por el peor de hecho.
Speaker 2: Por lo.
Speaker 6: Menos encuentro que.
Speaker 2: Tienen bien.
Speaker 6: Para las fachadas que en Chile.
Speaker 2: Por eso te digo que aquí se mantienen mejor. Debe ser por el clima quizás?
Speaker 6: Sí, pero también llega como este moho. No, bueno,
Speaker 2: Está el cagado porque si el mar.
Speaker 6: Es el mar, está el pico y es como Viña, Antopagata, La Serena.
Speaker 6: Te das la cuenta viene de arriba, deben de ser las tejas lo que hace que se destiña.
Speaker 2: Es que la teja arriba, mira, arriba está llena y eso escurre.
Speaker 2: Pero así todo no se ve feo, siento que se ve como pintoresco. Estas paredes ponte tú de allá, de allá de la derecha.
Speaker 2: De pura. Qué es Esto.
Speaker 6: Se ve una iglesia ahí como un ángel arriba.
Speaker 2: Esas paredes ponte tú de pura piedra, me estáis de allá. En verdad, a lo mejor en otro lugar, de otra forma, se vería como feo. Pero aquí se ve bonito, pues mira, el piso de piedra, todo como queda.
Speaker 6: Santiago parece que todo es piedra, viste? Dónde están tus padres? En Santiago de Colombia.
Speaker 2: Ah, no vi.
Speaker 2: Allá hacen una caminata como conocía, ¿no?
Speaker 6: Sí, el Camino de Santiago parte desde varios puntos de España.
Speaker 2: Que se lo hacen caminando, en bicicleta, en moto.
Speaker 6: Peregrinaje. Hay varias formas de hacerlo.
Speaker 2: Se turnan, no es tuyo, es de todas.
Speaker 6: Y obviamente termina en Santiago de Santiago y durante el, Te van. Es lo que va a hacer ahora el hijo de Lara tiene.
Speaker 2: Está ganando el ticket. O sea, como pin, pin es. La dejan allá?
Speaker 6: El César lo va a hacer ahora en el museo.
Speaker 2: No sabía. Sí, pero hay una época que lo hace en todo el mundo. Matías lo hizo con los mamotos.
Speaker 2: El Matías lo hizo?
Speaker 6: En un momento hay rutas que son más largas.
Speaker 2: Déjala Clara ahora. Deja la clara, no me deja de molestarla, déjala clara ahora, quédate que te tu ahí.
Speaker 2: Ya para allá sí, pero déjala clara ahora que se suba, que ya le veía la intención de girarse y salir corriendo.
Speaker 2: Oye si ya te leo el pensamiento, estabas esperando que se parara para ir corriendo a subirte tú, o no molestarla.
Speaker 2: Ah no, si no te conozco la cara.
Speaker 2: Venía caminando así como lento, cachai, ya lo solté.
Speaker 6: Cumplir ocho y se ve más grande.
Speaker 2: Qué, mi amor?
Speaker 2: No crezcas más, mi guagüita.
Speaker 6: Oye, la disfraz, manda un mensaje ayer felicitándote por tu curso.
Speaker 4: Ah, verdad.
Speaker 6: Por tu esfuerzo. Ahora te lo leeré si quieres ya.
Speaker 1: Buenas.
Speaker 2: Y todos vamos para allá y.
Speaker 6: A dónde vamos en ese pantalón de putillo el caballero.
Speaker 2: No nos gusta nada estaba con pantalón de pitillo pero con una polera de campesino y un gorro de adense.
Speaker 6: El pantalón, así que lo asesoraba el pobre hombre.
Speaker 2: Moderno po, pitillo no, qué incómodo, pobrecito pero eso se estuvo de moda hasta hace un par de años ¿te acordáis? Ahora ya, Yo creo que no tanto. No, no, yo creo que no tanto. No, tampoco ancho ancho, pero. Ahora creo que están como los de modelos como más apretados arriba y suelto como Juan de Elefante, te acordáis de eso de los años 60? No, eso es de los 60 y eso estaban los Beatles.
Speaker 2: En los hombres al menos? En los hombres lo usaban los 70?
Speaker 6: Sí, sí, pero eso no está.
Speaker 2: Yo he visto un par de cosas.
Speaker 2: Los acampanados están exagerados, pero medio así, medio aquí hay como suelto, he visto. Bueno no me interesa, ya no me voy a comprar más ropa en harto rato, así que. Ya ya. Si po me voy a comprar weás necesarias no más. Estas camisas necesarias para andar aquí, estas son necesarias para andar acá, pero si ropa, ropa como antes, que yo iba a comprar una maleta.
Speaker 2: Es que tengo exceso de weás en la casa.
Speaker 2: Pero tienes que tirarte despacio.
Speaker 2: Tienes que ir afirmándote! Esta bueno ese juegos. Porque tiene para jugar, para sentarse allá abajo, eso. Y allá atrás no sé qué es lo que tiene. Para escalar? Si po, donde está la cosita para engancharse así. Para hacer eso precisamente. Dónde está? Qué es lo que hay detrás de eso para escalar?
Speaker 2: Atrás del. Lo revisé, tengo mi idea.
Speaker 2: Abajo de la casita de árbol le podríamos poner una cosa así.
Speaker 2: Lo veteis? Para sentar. Todo lo que tiene un gráfico, por su casa. Lo podríamos agregar si es como la acción. Claro. Y de hecho lo podríamos unir con un. Ya es tan grande pues, con un tubo, para que se inspiren así a los bomberos.
Speaker 2: No cuesta nada, se puede hacer una decepción, para que depile al pie. Que le haga abajo una terraza,
Speaker 6: Que le haga una terraza con mesita, con no sé qué y con un palo al medio que sirva para bajar y para escalar para arriba, para subir.
Speaker 2: A lo mejor le niegas. Sí, yo creo.
Speaker 5: A ver qué más respuesta.
Speaker 6: Este sistema está bueno. Sí po.
Speaker 2: Cómo, pero con tu voz?
Speaker 5: Pero Si así sombras las velas.
Speaker 2: No, la helena que sea el pulpo. Tendría que ser con pilares verdes.
Speaker 4: Verde de arneto, estamos todos verdes? Verde el tipo de los colores de arneto. Eres del Pumpo.
Speaker 2: El Pumpo? Tu eres del Pumpo? No, tu. Tu. Oye, las gafas, las gafas si no te las vas a poner, pásamelas.
Speaker 2: Pero coche creció todo lo que creció po, pero antes se veía horrible.
Speaker 2: Este garage lo quiero forrar. Y los foros nos tiran.
Speaker 6: De oscuro que ya lo aprendimos. No sé. Pero forrarlo cuando. Sí, mi amor. Con la imitación de pie.
Speaker 2: Sí, con una wea. Sí. O sea, no comas.
Speaker 6: No sé, ahora que tenemos a Manuel, ese señor, le podemos pedir lo que son dos muros.
Speaker 2: Ah, lo voy a decir. Ese señor. Voy a importar la wea de China. Estas piezas, miro los metros cuadrados y le digo al Manuel cuando llegue, sale. Vamos pues. Quieres saber agua? Entonces las gazas.
Speaker 1: En cuál? En esto.
Speaker 1: Sí. Sí, mi amorcito.
Speaker 1: Yo iba a.
Speaker 7: Jugar con la arena. Fuera el castillo de arena. Ay, ¿por qué no para el viaje? Un poquito yo. El techo del estacionamiento le está quedando bien bueno. Sí? Porque el viento me ahora, me adora, porque es cierto, algo que me busca,
Speaker 5: Algo que me gusta.
Speaker 2: Viste que estaba bueno que mueran, tranquila, ¿Qué se lo estarían transmitiendo ahí? Que quería ir algo peor, quería ir algo peor. Es rico este viento hija. No le molestes a las mamás.
Speaker 1: Ya Vamos al auto para ir a la playa.
Speaker 2: Muy bien, no vas a ver al hotel y no hay playas y se ponen así. Pero un golpe más y les voy a sacar la cresta a las tres.
Speaker 2: Siéntate bien y ponte el cinturón.
Speaker 3: Por qué te estás haciendo?
Speaker 3: Cómo era la.
Speaker 6: Otra que me habéis dicho?
Speaker 6: Obras reportadas más adelante.

# Incidente — Caída de Nexus · 5 jul 2026

- **Fecha:** domingo 5 de julio de 2026
- **Detectado por:** Ramón
- **Síntoma:** Nexus no respondía en algún punto del día
- **Causa probable:** pendiente de investigar (¿apagón / Mac en reposo / crash de proceso?)
- **Estado:** sin diagnóstico confirmado

## Pendiente
- Revisar logs del servidor (PM2 / Docker)
- Verificar si el Mac entró en reposo o hubo corte de luz
- Revisar si hubo timeout/crash de alguna dependencia (Supabase, WhatsApp API, etc.)

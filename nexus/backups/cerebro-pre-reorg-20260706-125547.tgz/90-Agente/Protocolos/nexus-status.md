# ⚡ Protocolo: `nexus status`

> Cada vez que Ramón diga **"nexus status"**, Nexus ejecuta un chequeo en vivo de todas sus funciones y reporta el estado de cada una.

---

## Funciones a verificar (en paralelo cuando sea posible)

| # | Función | Herramienta(s) | Cómo verificar | Indicador OK |
|---|---------|---------------|----------------|-------------|
| 1 | **Base de datos (Supabase)** | `listar_tablas` + `consultar_bd` | Llama `listar_tablas` | Devuelve lista de tablas sin error |
| 2 | **Segundo Cerebro** | `buscar_cerebro` | Busca "nexus" | Devuelve ≥1 resultado |
| 3 | **Portal Aliace** | `guia_aliace` + `iniciar_sesion` | Llama `guia_aliace` | Guía cargada; credenciales en sitios |
| 4 | **GoAutos / MallorcAutos** | `consultar_goautos` | `resumen` | Devuelve total_vehiculos > 0 |
| 5 | **SII / Martes** | `sii` | `accion: estado` | ANA CLARA SPA = conectada |
| 6 | **Credenciales guardadas** | `listar_sitios` | Lista sitios | aliace, sii, goautos presentes |
| 7 | **Navegador web** | `navegar`, `leer_pagina`, `clic`, etc. | Implícito en Aliace o leer página simple | Sin errores de browser |
| 8 | **Guardar notas (Cerebro)** | `guardar_nota` | Guardar esta nota es la prueba | Sin error al guardar |

---

## Template de respuesta al usuario

```
⚡ NEXUS STATUS — [fecha/hora]

1. 🗄️  Base de datos (Supabase) ........... ✅ OK  — XX tablas disponibles
2. 🧠  Segundo Cerebro ..................... ✅ OK  — lectura y escritura OK
3. 🏢  Portal Aliace ....................... ✅ OK  — guía cargada / sesión activa
4. 🚗  GoAutos / MallorcAutos .............. ✅ OK  — XXX vehículos en sistema
5. 🧾  SII / Martes ........................ ✅ OK  — ANA CLARA SPA conectada
6. 🔑  Credenciales guardadas .............. ✅ OK  — [lista de sitios]
7. 🌐  Navegador web ....................... ✅ OK  — operativo
8. 📝  Guardar notas ....................... ✅ OK  — escritura confirmada

Estado general: ✅ TODO OPERATIVO
```

Si alguna falla, indica ❌ y el error específico.

---

## Notas
- Las verificaciones 1–6 se lanzan en paralelo para no perder tiempo.
- Si Aliace muestra /login, reconectar con `iniciar_sesion('aliace')` antes de reportar estado.
- Este protocolo fue creado el 2026-06-19 a petición de Ramón.

---
tipo: indice
tags: [agente]
---

# 🤖 Notas del agente (2cerebro)

Las notas que el agente crea automáticamente caen aquí (resúmenes de correos,
aprendizajes, respuestas elaboradas que conviene guardar).

- Llevan front-matter `autor: 2cerebro` y `creado:` con la fecha.
- Tú las puedes mover, editar o borrar libremente.
- Cada escritura del agente queda además auditada en Supabase (`log_acciones`).

> El agente NO borra ni sobrescribe tus notas sin que se lo pidas: crea archivos nuevos
> con un sufijo de fecha cuando hay duda.

# Preferencias de Ramón

- **Color favorito:** Verde

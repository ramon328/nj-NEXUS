---
tipo: memoria
tags: [agente, nexus, sii, impuestos]
autor: 2cerebro
creado: 2026-06-15
---

# Conector SII

`~/nexus/conector-sii/` entra al portal del SII con **clave tributaria** (RUT + clave). Empresa configurada: **ANA CLARA SPA, RUT 77.271.121-2** (clave guardada en `credenciales.json`). Descargas a `~/Desktop/documentos sii/<empresa>/`.

## ⚠️ Riesgo de bloqueo
El SII bloquea por logins automáticos repetidos. Regla: **un solo login por corrida**, sin bucles de reintento, abortar ante 403/429/"bloqueado/captcha". Hubo un throttle el 14/06 (ya pasó).

## 🎯 Para bajar facturas (RCV) se necesita el CERTIFICADO .p12
Verificado el 15/06: el login con clave funciona y la cuenta está sana, **pero el servicio de datos del RCV (`getResumen`) NO acepta el token del login con clave** (da `codRespuesta:99 "El token no es valido"`). Solo acepta el token del flujo por **certificado digital** (`seed→firma→getToken`).
- **Pendiente:** cargar el `.p12` de ANA CLARA SPA en `credenciales.json → sii.empresas["77271121-2"].cert` (ruta + clave) y correr `node descargar-todo.mjs 77271121-2 N`. El `.p12` NO se ha entregado todavía.
- La vía certificado además **no dispara el bloqueo** anti-bot.

Relacionado: [[Arquitectura Nexus]].

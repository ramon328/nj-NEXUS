---
tipo: indice
tags: [agente, nexus, memoria]
autor: 2cerebro
creado: 2026-06-15
---

# 🧠 Memoria de Nexus (la IA)

Aquí vive la **memoria de largo plazo de Nexus**: cómo está armado, sus conectores,
reglas del negocio y aprendizajes. Está en el Segundo Cerebro a propósito, para que sea
**durable, visible y editable** (no se pierde si se reinstala algo) y para que el agente
la pueda leer por su conector.

> Puedes editar o corregir cualquiera de estas notas en Obsidian; el agente las lee.

## Índice
- [[Arquitectura Nexus]] — la `.app` es solo un lanzador; el código real está en `~/nexus` (daemons launchd).
- [[Conector GoAutos (MallorcAutos)]] — autos directo de Supabase; **SOLO MallorcAutos (client 32)**.
- [[Conector SII]] — ANA CLARA SPA por clave; para bajar RCV se necesita el certificado `.p12`.
- [[Conector Correo]] — lee correos de Nico (Ailnest) en solo lectura.
- [[Auto-descarga de correos]] — baja el contenido de correos que cumplen una regla → notas en el cerebro.
- [[Navegador (DNS y login)]] — Chrome (no Brave), modo visible, auto-cura el DNS de Tailscale, login idempotente.
- [[Hub y tope de tokens]] — `consultar_bd` acotado; facturación = portal Aliace, no la BD.
- [[WhatsApp (OpenClaw)]] — canal linked; regla anti-fuga (no mostrar puertos/hub al usuario); delega datos al hub.
- [[Supabase y consumo]] — 3 proyectos Supabase distintos.
- [[Segundo Cerebro de Nico]] — el vault personal "Super Yo".

## Reglas de oro (resumen)
1. **GoAutos = SOLO MallorcAutos.** Nunca datos de otras automotoras.
2. **Facturación/ventas/pagos = portal Aliace**, nunca la tabla `reportes` (son citas de clínica).
3. **SII: un solo login por corrida**, riesgo de bloqueo; para RCV usar certificado `.p12`.
4. **Nunca exponer la cañería interna** (puertos, "el hub", errores técnicos) al usuario en WhatsApp.

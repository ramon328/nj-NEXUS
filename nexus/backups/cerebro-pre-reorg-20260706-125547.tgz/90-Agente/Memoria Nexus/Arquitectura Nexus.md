---
tipo: memoria
tags: [agente, nexus, arquitectura]
autor: 2cerebro
creado: 2026-06-15
---

# Arquitectura Nexus

`Nexus.app` (en el Escritorio) es **solo un lanzador**; el código real vive en **`~/nexus`** y corre como **daemons launchd** (`com.nexus.*`), todo en `127.0.0.1`.

## Servicios (puertos)
- **Hub** `:3000` (`hub/`) — cerebro conversacional (Opus 4.8) + UI web (Jarvis). Endpoint `/api/chat`.
- **Navegador** `:8082` (`conector-navegador/`) — opera la web (Aliace, GoAutos) con Chrome.
- **Cerebro** `:8081` (`conector-obsidian/`) — lee/escribe el vault `~/nexus/cerebro`.
- **Transcribe** `:8083` — Whisper local para notas de voz.
- **OpenClaw** `:18789` — gateway de WhatsApp (agente Nexus).
- Otros: SII (`conector-sii/`), correo (`conector-correo/`), registrador de consumo.

## Credenciales
Todas en `~/nexus/credenciales.json` (chmod 600, gitignored) y `~/nexus/.env`. **Nunca pedirlas por chat.**

Relacionado: [[Conector GoAutos (MallorcAutos)]], [[WhatsApp (OpenClaw)]], [[Navegador (DNS y login)]].

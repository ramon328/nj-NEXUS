---
tipo: memoria
tags: [agente, nexus, supabase]
autor: 2cerebro
creado: 2026-06-15
---

# Supabase y consumo

Hay **3 proyectos Supabase distintos** en juego (no confundirlos):
- **Negocio del hub** (`ydcpsihovvaefyobnhws`) — la base que consulta `consultar_bd`. Incluye datos de una clínica (tabla `reportes` = citas) y otros. **NO es la facturación de Aliace.**
- **Correo/Ailnest** (`otuzwaxanenbmpvnfsik`) — correos de Nico.
- **GoAutos** (`miuiujntdjrjhhcysiba`) — autos de MallorcAutos (ver [[Conector GoAutos (MallorcAutos)]]).
- Aliace tiene además su propia base (`mdrvhekhimhcwydrpueo`), pero su facturación se obtiene navegando el portal.

El contador de consumo de API se arregló vía `registrador-consumo`.

Relacionado: [[Hub y tope de tokens]], [[Conector Correo]].

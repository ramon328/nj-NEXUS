---
tipo: memoria
tags: [agente, nexus, correo, automatizacion]
autor: 2cerebro
creado: 2026-06-18
---

# Auto-descarga de correos específicos

Sistema que **baja el contenido de un correo automáticamente cuando cumple una regla** y lo guarda como nota en el cerebro (`90-Agente/Correos/`).

## Piezas (en `~/nexus/conector-correo/`)
- **`reglas-descarga.json`** — qué correo es "específico". Criterios opcionales (todos los presentes deben cumplirse): `remitente`, `asunto_contiene`, `empresa`, `solo_importantes`. Poner `"activa": true` para encender.
- **`watch-descargas.mjs`** — el vigilante: una pasada por corrida. Busca correos nuevos en Ailnest, matchea reglas, guarda contenido en `90-Agente/Correos/`.
- **`estado-descargas.json`** — anti-duplicado (último check + IDs vistos). Primera corrida arranca desde AHORA (no baja histórico).
- **Daemon `com.nexus.correo-watch`** — lo dispara cada **180s** (`StartInterval` en `~/Library/LaunchAgents/`).

## Fuente y futuro
- **HOY:** fuente = Ailnest (Supabase `otuzwaxanenbmpvnfsik`, tabla `emails`). Por intervalo (3 min).
- **DESPUÉS (Google API):** crear `fuentes/fuente-gmail.mjs` con OAuth (`GMAIL_CLIENT_ID/SECRET/REFRESH_TOKEN` en `.env`) → permite **tiempo real** (Gmail `watch` + Pub/Sub). El resto (reglas, guardado, anti-duplicado) ya está hecho.

Destino elegido por Ramón: **solo cerebro** (sin carpeta de disco ni aviso WhatsApp, por ahora). Ver [[Conector Correo]].

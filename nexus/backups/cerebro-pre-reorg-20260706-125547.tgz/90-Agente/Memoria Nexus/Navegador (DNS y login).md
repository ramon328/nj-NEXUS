---
tipo: memoria
tags: [agente, nexus, navegador]
autor: 2cerebro
creado: 2026-06-15
---

# Navegador (DNS y login)

`~/nexus/conector-navegador/` (Playwright, puerto 8082) opera la web por el agente.

## Motor: Chrome, no Brave
**Usa Google Chrome** (`channel: 'chrome'`). Brave rompe GoAutos (sus shields). Quedó en **modo visible** (`NAVEGADOR_VISIBLE=1` en el plist) para ver el mouse operar. *(Si molesta tener la ventana abierta, sacar `NAVEGADOR_VISIBLE` del plist y recargar.)*

## Auto-cura de DNS (Tailscale)
El DNS de Tailscale (`accept-dns=true` → resolver `100.100.100.100`) dejaba a Chrome sin resolver dominios ("sin internet"/`ERR_NAME_NOT_RESOLVED`) tras reconexión/suspensión. El conector ahora **fuerza `accept-dns=false` solo**: al arrancar, cada 5 min, y al primer fallo de DNS (+ flush de caché). `/ir` reintenta 3 veces. La pantalla no se suspende (`caffeinate -d` en `com.nexus.despierto`).

## Login idempotente
`ejecutarLogin` espera ~3.5s el redirect: si la URL deja de ser de login, ya hay sesión y no reintenta (antes daba "login falló" cuando en realidad estaba dentro). Sitios: `aliace`, `goautos`, `sii`.

Relacionado: [[Conector GoAutos (MallorcAutos)]], [[Hub y tope de tokens]].

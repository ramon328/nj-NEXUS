---
tipo: memoria
tags: [agente, nexus, cerebro]
autor: 2cerebro
creado: 2026-06-15
---

# Segundo Cerebro de Nico

Hay **dos vaults Obsidian**:
- **`~/nexus/cerebro`** — el vault **operativo del agente** (lo lee/escribe el conector cerebro, puerto 8081). Carpetas: `00-Inbox`, `10-Empresas`, `20-SII`, `30-Procesos`, `40-Plantillas`, **`90-Agente`** (donde vive esta memoria).
- **`~/Desktop/segundo cerebro nico`** — el vault personal **"Super Yo" de Nico** (Identidad, Empresas, Principios, Proyectos…).

Esta **Memoria Nexus** vive en `~/nexus/cerebro/90-Agente/Memoria Nexus/` a propósito: es durable (Markdown en Obsidian), editable a mano, y el agente la lee por su conector. Si OpenClaw o algún store interno se reinstala, la memoria **no se pierde**.

Relacionado: [[Arquitectura Nexus]], [[_Índice — Memoria Nexus]].

---
tipo: memoria
tags: [agente, nexus, whatsapp, openclaw]
autor: 2cerebro
creado: 2026-06-15
---

# WhatsApp (OpenClaw)

Nexus recibe/responde WhatsApp por el canal **whatsapp** de OpenClaw (daemon `com.nexus.openclaw`, gateway `127.0.0.1:18789`). El agente `main` ES el mismo Nexus (no uno aparte); sus instrucciones viven en `~/.openclaw/workspace/AGENTS.md`.

- **Acceso:** allowlist por número (Nico y Ramón). Sumar a alguien: `openclaw config set channels.whatsapp.allowFrom '[...]'` + reiniciar gateway.
- **Reiniciar:** `launchctl kickstart -k gui/$(id -u)/com.nexus.openclaw`.
- Transcribe notas de voz local (Whisper, puerto 8083) antes de pasar al modelo. Ve fotos (Haiku 4.5).

## ⚠️ Las sesiones se "amañan" — usar `/reset` tras cambiar instrucciones
OpenClaw usa **una sesión persistente por número** (dmScope per-channel-peer). Si cambias
`AGENTS.md` o un conector, una **sesión en curso NO toma los cambios** (queda anclada a su
historial e instrucciones viejas; reiniciar el gateway no la resetea). Solución: el usuario
manda **`/reset`** en WhatsApp → arranca conversación nueva con las instrucciones actuales.
Para verificar sin enviar WhatsApp: `openclaw agent --session-id <nuevo> --message "..."` (sin `--deliver`).
*(Ej.: GoAutos seguía raspando la SPA pese al conector nuevo, hasta hacer `/reset`.)*

## 🟰 Modo ESPEJO (jun-2026): WhatsApp = Nexus Desktop
Para que WhatsApp dé EXACTO lo mismo que el PC, el agente de WhatsApp es un PUENTE: por cada
mensaje ejecuta `node ~/nexus/hub/preguntar.mjs "<mensaje>"` (que llama al hub `/api/chat`, el
cerebro del PC) y devuelve esa respuesta tal cual. AGENTS.md quedó reducido a esa regla
("no sabes nada, ejecuta siempre el comando"). Respaldo del AGENTS.md viejo en `workspace/AGENTS.md.bak-*`.
El hub (Desktop) YA tiene **GoAutos** como herramienta (`consultar_goautos` en `hub/asistente.mjs`,
usa el conector goautos.mjs, SOLO LECTURA — el portal GoAutos NO se puede scrapear, su SPA no
renderiza la tabla). Faltan aún Plaud/SII/correo si se quieren en el espejo. `preguntar.mjs`
tiene timeout (110s) para que el puente no se cuelgue. Heartbeat: AGENTS.md responde
`HEARTBEAT_OK` al poll interno (no se entrega al usuario). Si se quiere espejo
100% determinístico (sin Haiku), montar un shim anthropic-messages en el hub y apuntar el
modelo de OpenClaw ahí.

## Reglas clave
- **🚫 Anti-fuga (regla dura):** NUNCA mostrar al usuario la cañería interna (puertos, "el hub", `curl`, nombres de tablas, errores técnicos). Si algo falla por dentro, reintentar o responder humano ("dame un momento, no pude obtenerlo recién"). Mismo trato limpio para Nico y Ramón. *(Surgió porque a Nico le filtró "error en un puerto / voy a revisar el hub".)*
- **Datos de negocio:** el agente **delega al hub** (`curl 127.0.0.1:3000/api/chat`) → hereda las consultas acotadas. Mantener el hub `:3000` arriba.
- **GoAutos:** usar el conector (ver [[Conector GoAutos (MallorcAutos)]]); navegador solo para acciones de UI.

Relacionado: [[Arquitectura Nexus]], [[Hub y tope de tokens]].

---
tipo: memoria
tags: [agente, nexus, correo, nestor]
autor: 2cerebro
creado: 2026-06-15
---

# Conector Correo (Néstor)

`~/nexus/conector-correo/correo.mjs` lee los correos de Nico (plataforma **Ailnest**, proyecto Supabase `otuzwaxanenbmpvnfsik`), **solo lectura**. Son las mismas funciones del agente Néstor.

```bash
node ~/nexus/conector-correo/correo.mjs resumen        # [--dias 7] [--importantes]
node ~/nexus/conector-correo/correo.mjs buscar --texto "factura"
node ~/nexus/conector-correo/correo.mjs leer --id <id>
node ~/nexus/conector-correo/correo.mjs reuniones
```

Enviar correos / agendar **NO** está disponible (requiere Gmail API). La sync la hace Ailnest, así que los correos pueden tener horas de atraso. Si el CLI da error, decirlo tal cual; nunca inventar correos.

Relacionado: [[Arquitectura Nexus]], [[Supabase y consumo]].

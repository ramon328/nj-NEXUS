---
tipo: memoria
tags: [agente, nexus, hub, aliace]
autor: 2cerebro
creado: 2026-06-15
---

# Hub y tope de tokens

El chat del hub (`~/nexus/hub/asistente.mjs`, Opus 4.8, límite 1M tokens) daba `prompt is too long`. Causa: `consultar_bd` topaba las filas pero no el **tamaño**; tablas con filas gigantes (`listings`, `reportes`) traían 600k–800k tokens y reventaban.

## Arreglo (no quitar)
Topes de tamaño: `MAX_BD_CHARS=12k`, `MAX_TOOL_CHARS=16k`, backstop `MAX_PROMPT_CHARS=600k`, historial entrante recortado a 200k. `consultar_bd` ahora acepta `columnas` y `filtro` (PostgREST) para traer solo lo necesario.

## 🎯 REGLA: facturación = portal Aliace, NO la base
La **facturación/ventas/pagos** de Aliace salen del **portal `admin.aliace.cl`** navegando, NUNCA de `consultar_bd`. La tabla `reportes` de la base del hub son **citas de una clínica** (pacientes/psicología), NO facturación — está **bloqueada** en `consultar_bd`. Verificado: facturación mayo 2026 = **$1.957.627.924** (desde Aliace).

Relacionado: [[Navegador (DNS y login)]], [[Supabase y consumo]].

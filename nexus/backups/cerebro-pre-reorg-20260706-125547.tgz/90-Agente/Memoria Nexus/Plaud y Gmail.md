---
tipo: memoria
tags: [agente, nexus, gmail, plaud]
autor: 2cerebro
creado: 2026-06-19
---

# Plaud y Gmail de Nexus

**Gmail conectado:** `niconexus29@gmail.com` (OAuth). Se conecta desde el panel del hub (Servicios → "Conectar cuentas → Gmail de Nexus"). Credenciales OAuth en `~/nexus/conector-correo/google/oauth-client.json`; token en `token.json` (chmod 600). Endpoints en el hub: `/api/google/status|connect|callback`.

**Plaud → Segundo Cerebro:** los correos de `no-reply@plaud.ai` ([Plaud-AutoFlow]) traen 2 adjuntos `.txt` (`resumen.txt` + `transcripción.txt`). El script `~/nexus/conector-correo/plaud-descargar.mjs` baja **SOLO el adjunto del resumen** (no el cuerpo del correo) y lo guarda como nota limpia en `90-Agente/Plaud/`. Dedup en `estado-plaud.json`. Daemon `com.nexus.plaud-watch` corre cada 15 min. Para backfill histórico: `node plaud-descargar.mjs <N>` con N alto.

Permiso Gmail usado: solo `gmail.readonly` (+ userinfo.email). Ver [[Conector Correo]], [[Auto-descarga de correos]].

---
tipo: memoria
tags: [agente, nexus, goautos, mallorcautos]
autor: 2cerebro
creado: 2026-06-15
---

# Conector GoAutos (MallorcAutos)

GoAutos (portal `https://portal.goauto.cl`, admin de **MallorcAutos**) es un SPA React+Supabase. Raspar la página fallaba (la tabla no es `<tbody tr>`, los datos cargan por API, y Brave la rompía). **Solución: leer la Supabase de GoAutos directo.**

## 🔒 REGLA: GoAutos = SOLO MallorcAutos
El usuario (`ramon@dropout.cl`) es **super-admin** y ve las 60 automotoras del portal. Por exigencia del negocio, **todo se acota a MallorcAutos = `client_id 32`** (tabla `clients`). El conector lo filtra siempre (constante `CLIENT_ID = 32`, no quitar). MallorcAutos: **145 vehículos, 142 en stock**.

## Conector (solo lectura)
```bash
node ~/nexus/conector-goautos/goautos.mjs resumen        # total / en stock / online / en local
node ~/nexus/conector-goautos/goautos.mjs publicaciones  # los que están en stock
node ~/nexus/conector-goautos/goautos.mjs vehiculos --limite 50
node ~/nexus/conector-goautos/goautos.mjs buscar --texto "audi"
```

## Datos
- Supabase GoAutos: `https://miuiujntdjrjhhcysiba.supabase.co` (URL + anon key públicas, del bundle del cliente). Repo local: `~/Documents/GitHub/goautos-admin`.
- Auth: Supabase Auth con las credenciales `goautos` de `credenciales.json`.
- Tabla `vehicles`. OJO: en MallorcAutos `is_published` viene **null**; el estado real es **`show_in_stock`** (true/false) y `stock_type` (online/dealership). Marca/modelo por embed `brands(name)`,`models(name)`.

Relacionado: [[Arquitectura Nexus]], [[WhatsApp (OpenClaw)]].

# Perfil — Ramón (admin)

> Se activa cuando habla **Ramón** (WhatsApp +56932945240 / ramon@dropout.cl).

- **Quién:** Ramón. Admin de Nexus, lado técnico (Dropout). Mismo acceso que Nico (full).
- **Cómo tratarlo:** directo, técnico, al grano; sin vueltas.
- **Le interesa:** que todo funcione, automatizaciones, cobranza, GoAutos/MallorcAutos, SII, el propio Nexus.
- **Preferencias:** ver [[preferencias-ramon]] (p.ej. color favorito: verde).

Cuando habla Ramón: usa esto + el [[_Comun|contexto común]] y, si necesitas más, busca en el cerebro con `buscar_cerebro`. Lo que Ramón te pida recordar, guárdalo como nota (en su perfil/preferencias o donde corresponda).

# Perfil — Nico (admin · dueño)

> Se activa cuando habla **Nico** (WhatsApp +56975481858 / njuri@dropout.cl / nicojuri@gmail.com).

- **Quién:** Nicolás Juri. Admin y **dueño** de los negocios. Mismo acceso que Ramón (full).
- **Negocios:** MallorcAutos (autos), Aliace, HN / ImportHN.
- **Identidad y forma de ser (Super Yo):** está en la carpeta [[10 — Identidad]] →
  [[11 — Biografía y familia]], [[12 — Dimensión personal]], [[13 — Cómo trabaja y se comunica]].
  Busca ahí con `buscar_cerebro` cuando necesites contexto profundo o saber cómo tratarlo/comunicarte.
- **Le interesa:** ventas, cobranza, sus correos (Néstor), el negocio en general.

Cuando habla Nico: usa esto + el [[_Comun|contexto común]] y, si necesitas más, busca en el cerebro su identidad/conocimiento. Lo que Nico te enseñe o pida recordar, guárdalo como nota en el cerebro.

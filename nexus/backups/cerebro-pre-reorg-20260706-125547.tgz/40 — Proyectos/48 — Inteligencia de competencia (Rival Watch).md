---
tags: [proyecto, competencia, scraping, impomin]
actualizado: 2026-06-13
---

# 48 — Inteligencia de competencia (Rival Watch)

> Vigilar automáticamente a los competidores (precios, stock, movimientos) y alertar cuando pasa algo relevante. Foco inicial: [[22 — IMPOMIN]].

## Qué hace
- Scrapea las tiendas online de la competencia → lee productos con **nombre, precio, stock y enlace**.
- **Dashboard comparativo** producto a producto (IMPOMIN vs. competencia), con navegador por empresa.
- Detecta **promociones y cambios de precio** y los deja listos como **alertas**.
- Capa minera preparada (modelo de camioneta, faena, kits) para activarse con competidores del rubro real.

## Estado
- Pasó de 4 a 13–16 sitios operativos. "Primera gran etapa OK". Por ahora **no requiere agente de IA** en esta plataforma (decisión de Nico).

## Competidores listados (Excel "COMPETENCIA")
Socadin, Implementos, Lorenzini, Kupfer, Encendido Total, Repuestos Norte, 3V, Sodimac, RAC, Ingecot, Bryo, DPRO SpA, Grupo Serex, Caren (y otros en el mapa de IMPOMIN: Escapes Mendoza, Equipa Chile, Start Fire, SafeTruck, Alessandrini).

> Conecta con la estrategia comercial: el benchmark mostró que la competencia gana licitaciones por **propuesta integrada** — eso motiva las 5 prioridades de [[22 — IMPOMIN]].

Relacionado: [[22 — IMPOMIN]] · [[23 — HN]]

Fuentes: [[63 — Requerimientos Nexus v1]], [[64 — Handoff web IMPOMIN]], [[65 — PDR ejecutivos (8-11 jun)]], [[67 — Reporte de avances (3 jun)]].

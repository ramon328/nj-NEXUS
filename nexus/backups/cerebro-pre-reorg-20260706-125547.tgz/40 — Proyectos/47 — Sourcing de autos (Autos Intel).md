---
tags: [proyecto, autos, scraping, mallorcautos]
actualizado: 2026-06-13
---

# 47 — Sourcing de autos (Autos Intel)

> Detectar **oportunidades de compra** de autos usados automáticamente. Es el corazón de [[24 — MALLORCAUTOS]] (90% del negocio es comprar bien).

## Qué hace
- **Scraper** de portales (ChileAutos, Yapo, Linze; MercadoLibre fue descontinuado) → base de ~6.780–11.738 avisos con fotos reales.
- **Filtros** por precio, km, modelo, segmento (clustering: premium, camionetas, etc.).
- Apartado **"Oportunidades":** la IA marca cuándo conviene comprar (descuento vs. mercado, liquidez del modelo, vendedor motivado) en niveles excelente / buena / moderada.
- Detección de **vendidos** e **historial de precios** (avisa bajadas de precio).
- Agente IA dentro de la plataforma + por WhatsApp: responde info, contacta unidades a pedido, marca importantes.
- Seguimiento por unidad: revisada / contactada / contactada con respuesta.

## Visión a 4 capas
1. Datos (en curso) → 2. precio justo + tendencia → 3. agente Claude → 4. dashboard de capital.

## Detalle técnico
- Stack: Next.js + Supabase + scraper Python (cron GitHub Actions / horario mañana-noche).
- Vinculado a **GoAuto** ([[25 — ACE SpA]]).

## Bug abierto conocido
- El filtro por "vendidos" no funcionaba bien (aparecían unidades ya vendidas) — en corrección.

Relacionado: [[24 — MALLORCAUTOS]] · [[25 — ACE SpA]]

Fuentes: [[63 — Requerimientos Nexus v1]], [[65 — PDR ejecutivos (8-11 jun)]], [[67 — Reporte de avances (3 jun)]], [[68 — Tablero GM (dashboard_gm.jsx)]].

---
tags: [proyecto, correo, ailnest, nestor, agente]
actualizado: 2026-06-13
---

# 46 — Correo unificado (Ailnest · Néstor)

> Anidar las **6 cuentas de correo** (una por empresa) en una sola bandeja, con un agente que ayuda a gestionarlas. Plataforma "Ailnest", agente "Néstor".

## El dolor
Nico tiene 6 cuentas y miles de mails. Lo crítico se mezcla con CC informativos. Pierde tiempo leyendo cosas vanales y arriesga perder lo importante. Ver [[33 — Preferencias de comunicación]].

## Qué debe hacer
- **Priorizar por importancia, no por orden de llegada:** lo urgente e importante primero.
- Segmentar bien: dirigido a Nico / en copia / mencionado. Y separar **leídos importantes** de **leídos no importantes/en copia** (misma lógica en respondidos y enviados). Hoy hay duplicidad entre "no leídos" e "importantes" — corregir.
- **Néstor** funciona en **WhatsApp y dentro de la plataforma**: resume mails, busca lo que se le pida, redacta.
- **Autoadministra** la plataforma: ej. "crea una carpeta y mueve ahí todos los correos donde estoy en copia y me mencionan".
- **Detecta conflictos** entre las partes en correos donde Nico está en copia. Ver [[53 — Conflicto detectado entre terceros]].
- Detector de reuniones (si alguien quiere agendar, muestra solo el apartado para agendar).

## La regla (nivel COMUNICAR)
- **Fase 1 (actual):** segmentar + **proponer respuestas** (borradores), nunca enviar solo.
- **Fase 2:** escalar a respuestas más autónomas **según resultados**.
- Regla dura: nada se envía automático sin aprobación. Ver [[31 — Regla de Oro de Autonomía]].

## Estado
Néstor ya lee todos los buzones del dueño (antes solo uno), tiene chat con IA para redactar/gestionar. En jun-2026 estuvo apagado temporalmente por un bug (para no gastar tokens).

Relacionado: [[33 — Preferencias de comunicación]] · [[42 — Alí]] · [[53 — Conflicto detectado entre terceros]]

Fuentes: [[63 — Requerimientos Nexus v1]], [[65 — PDR ejecutivos (8-11 jun)]], [[61 — HANDOFF Nexus v1]].

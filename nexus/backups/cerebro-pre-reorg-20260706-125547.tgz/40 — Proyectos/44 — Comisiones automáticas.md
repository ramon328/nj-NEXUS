---
tags: [proyecto, comisiones, finanzas, rrhh]
actualizado: 2026-06-13
---

# 44 — Comisiones automáticas

> Requisito **transversal crítico**: automatizar al 100% el cálculo de comisiones de las 5 empresas.

## Flujo deseado (de punta a punta)
1. **Día 1 (corte):** el sistema extrae data de **SAP** (facturas, vendedores, montos).
2. **Día 2:** calcula comisiones según las reglas de cada empresa.
3. **Día 2 PM:** genera reporte Excel + email a gerencia (contador + RR.HH. + Nico).
4. **Día 3:** Nico **revisa y aprueba** en una UI.
5. **Día 3 PM:** integra con nómina (Talana/Rex/Payroll.cl).
6. **Día 4:** se ejecuta la nómina.

> Nota: el paso 4 (aprobación de Nico) es coherente con la [[31 — Regla de Oro de Autonomía]] — un pago no se libera solo.

## Estado por empresa
| Empresa | Estado |
|---|---|
| [[23 — HN]] | Semi-auto (Google Sheets + script SAP, ~99% exacto) |
| [[22 — IMPOMIN]] | Semi-auto (Google Sheets + script SAP, ~99% exacto) |
| [[21 — ALIACE]] | Manual → automatizar |
| [[24 — MALLORCAUTOS]] | Manual → automatizar |
| [[26 — Food Expert SpA]] | Manual → automatizar |

**Dolor actual:** Nico tiene que "recordar cómo se cargaba la info"; semi-auto = clicks manuales; no escala a 5 empresas.

## Hito con fecha dura
- **24 de junio 2026:** debe estar el cálculo de comisiones a pagar del período **23-may a 23-jun** (HN/IMPOMIN). Llevarlo a formato plataforma (estilo "plataforma del centro médico").

## Detalle técnico a cuidar
- Normalización de **folios** (histórico con/sin guión — mismo problema que en captura SII).
- Validaciones: vendedores sin comisión, devoluciones, etc.

Relacionado: [[23 — HN]] · [[45 — Captura SII]] · [[63 — Requerimientos Nexus v1]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[63 — Requerimientos Nexus v1]].

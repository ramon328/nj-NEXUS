---
tags: [proyecto, nexus, super-yo]
actualizado: 2026-06-13
---

# 41 — Nexus

> El proyecto paraguas: el **"super yo" digital** de Nico. Un sistema agéntico que automatiza de forma integral sus procesos personales y empresariales, operando 24/7.

## Visión
- Un **clon operativo** que informa, prepara y ejecuta tareas de bajo riesgo, dejando a Nico solo las decisiones estratégicas.
- Meta declarada: pasar de **8-10 h/día a 2-3 h/día** de decisiones.
- Se construye por **subagentes especializados** que en una etapa final se integran en un único agente.

## Arquitectura cerrada (no se reabre sin Nico)
1. **[[31 — Regla de Oro de Autonomía]]** — el principio que gobierna a todos los agentes.
2. **[[42 — Alí]] es el prototipo replicable**, no un proyecto aislado: se diseña multi-tenant desde el día uno.
3. **Dos capas:** transversal (le habla a Nico) + por empresa (le habla a cada empresa). Ver [[40 — Proyectos (tablero)]].
4. **Separación estricta de fuentes de datos:** el motor de [[43 — Conciliación bancaria]] es agnóstico; banco (Rail/Fintoc) y SII se enchufan por separado.

## Stack
- Backend: Node.js + Express · BD: PostgreSQL · IA: API de Anthropic (Claude) con *tool calling*.
- Frontend: React + Tailwind + Recharts.
- Conectores: banco (Rail/Fintoc), SII, SAP, Odoo, Gmail, nómina (Talana/Rex/Payroll), scraping autos.
- Infra: Mac mini M4 Pro 24/7. Hub "Forja" con login único.

## Módulos que viven dentro
[[43 — Conciliación bancaria]] · [[44 — Comisiones automáticas]] · [[45 — Captura SII]] · [[46 — Correo unificado (Ailnest · Néstor)]] · [[47 — Sourcing de autos (Autos Intel)]] · [[48 — Inteligencia de competencia (Rival Watch)]] · [[6C — Control de costos de IA]].

## La capa personal (pendiente)
El "super yo" completo incluye lo personal — papá, marido, músico, autos, deporte. Hoy **no está mapeado** y queda fuera del MVP, pero es parte del objetivo final. Ver [[12 — Dimensión personal]].

## Nombres que aparecen en las fuentes
"Nexus", "super yo", "2cerebro", hub "Forja", web pública `nicojuri.ai` / `www.nicojuri.ia`. Son distintas capas del mismo proyecto.

Relacionado: [[42 — Alí]] · [[40 — Proyectos (tablero)]] · [[34 — Cómo querría que un agente actúe en su nombre]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[62 — HANDOFF Nexus v2]], [[67 — Reporte de avances (3 jun)]], [[68 — Tablero GM (dashboard_gm.jsx)]].

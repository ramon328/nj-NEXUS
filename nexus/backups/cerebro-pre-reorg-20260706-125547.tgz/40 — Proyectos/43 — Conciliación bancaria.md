---
tags: [proyecto, conciliacion, finanzas, codigo]
actualizado: 2026-06-13
---

# 43 — Conciliación bancaria

> **Único módulo con código ya entregado ✅.** Cruza la cartola del banco contra los documentos del SII y propone conciliaciones. Archivo: `conciliacion.ts`.

## Qué hace
Por cada movimiento de la cartola, busca el documento del SII que le corresponde (factura compra/venta, BHE) y lo clasifica en 3 niveles de confianza — que son la [[31 — Regla de Oro de Autonomía]] hecha código:

| Nivel | Significado |
|---|---|
| **AUTO** | alta confianza → auto-concilia |
| **SUGERIR** | propone a humano para 1 click |
| **REVISAR** | sin match claro → manual |

## Lo que resuelve bien
- Pagos agrupados (N facturas → 1 transferencia).
- Dirección correcta: venta = abono, compra/BHE = cargo.
- *Scoring* multicriterio: monto, fecha, RUT/nombre en la glosa, folio.
- **Salvaguarda dura:** nunca auto-concilia si el monto **no calza exacto**.
- Compila limpio en `tsc --strict`. **No emite pagos ni toca el banco: solo lee y propone.**

## Arquitectura
- **Agnóstico de proveedor:** las fuentes se enchufan implementando la interfaz `FuenteDatos`.
  - Banco (cartola) → **Rail** (o **Fintoc** de respaldo). Solo lectura.
  - SII (documentos) → proveedor aparte (ver [[45 — Captura SII]]).
- ⚠️ **Rail NO baja documentos del SII** — es solo banco.

## Pendientes técnicos (TODO en el código)
- **Retención BHE:** el monto que llega al banco ≠ monto de la boleta (descontar impuesto 2da categoría antes de comparar).
- **Pago parcial** 1 doc : N movimientos (hoy resuelve N docs : 1 pago).
- **Tabla de auditoría:** quién aprobó qué conciliación/pago y cuándo (la pedirá el contador).

Relacionado: [[31 — Regla de Oro de Autonomía]] · [[45 — Captura SII]] · [[6A — Motor de conciliación (conciliacion.ts)]]

Fuentes: [[62 — HANDOFF Nexus v2]], [[6A — Motor de conciliación (conciliacion.ts)]].

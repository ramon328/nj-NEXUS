---
tags: [proyectos, moc, tablero]
actualizado: 2026-06-13
---

# 40 — Proyectos (tablero)

Lo que se está construyendo para el "super yo". El proyecto paraguas es [[41 — Nexus]].

| Proyecto | Qué es | Estado (jun 2026) |
|---|---|---|
| [[41 — Nexus]] | El cerebro/orquestador central ("super yo") | En desarrollo |
| [[42 — Alí]] | Agente GG de ALIACE, prototipo replicable | En desarrollo (45 capacidades) |
| [[43 — Conciliación bancaria]] | Motor que cruza banco ↔ SII | **Código entregado ✅** |
| [[44 — Comisiones automáticas]] | Cálculo de comisiones de las 5 empresas | HN/IMPOMIN semi-auto; resto manual |
| [[45 — Captura SII]] | Bajar documentos tributarios 24/7 | Decisión doble vía (build+buy) |
| [[46 — Correo unificado (Ailnest · Néstor)]] | 6 cuentas en una bandeja + agente | En desarrollo |
| [[47 — Sourcing de autos (Autos Intel)]] | Detectar oportunidades de compra de autos | En desarrollo (base poblada) |
| [[48 — Inteligencia de competencia (Rival Watch)]] | Vigilar precios/movimientos de competidores | Prototipo (16 competidores) |
| [[49 — Comité comercial ALIACE]] | Desempeño comercial "en una hoja" | En desarrollo |

## Dos capas (cómo se ordena todo)
- **Capa transversal** (cruza todas las empresas, le habla a **Nico**): correo unificado + conciliación bancaria + captura SII + control de costos de IA.
- **Capa por empresa** (le habla a **cada empresa**): un Alí + subagentes por área.
- El "super yo" = la capa transversal arriba + un Alí por empresa abajo.

## Infraestructura
- **Hub:** "Forja" / Dropout Capital (donde viven las apps con login único).
- **Hardware:** Mac mini M4 Pro corriendo 24/7 (más servidor DigitalOcean para el agente de WhatsApp).
- **Dominios:** nicojuri.com / nicojuri.ai (ver nota de gobierno en [[35 — Gobierno de activos personales vs empresa]]).
- **Costos de IA:** módulo dedicado de FinOps. Ver [[6C — Control de costos de IA]].

Fuentes: [[62 — HANDOFF Nexus v2]], [[63 — Requerimientos Nexus v1]], [[65 — PDR ejecutivos (8-11 jun)]], [[68 — Tablero GM (dashboard_gm.jsx)]].

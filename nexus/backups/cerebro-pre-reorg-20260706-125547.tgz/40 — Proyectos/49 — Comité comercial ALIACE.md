---
tags: [proyecto, comercial, aliace, dashboard]
actualizado: 2026-06-13
---

# 49 — Comité comercial ALIACE

> Ver en **"una hoja"** el desempeño comercial de [[21 — ALIACE]].

## Qué muestra
- Clientes, vendedores, márgenes, ventas, **EBITDA, YTD, MTD**.
- Comparativas **siempre en $ y en %** contra metas (por clientes, vendedores, productos). Ver [[33 — Preferencias de comunicación]].
- Acceso para vendedores (cada uno ve lo suyo: vendedor, zona, tipo de cliente).
- Diseño "todo en una hoja" + gráfico de tendencia mes a mes (historia / realizado / meta).

## El cuidado que pide Nico
- Que **"margen" y "EBITDA" tengan una definición única y validada** antes de graficar (que no signifiquen cosas distintas según la fuente).
- Que las cifras **cuadren al peso con la fuente oficial** (Power BI). Coherente con [[32 — Cómo decide Nico|"primero que el dato sea verdad"]].

## Por qué importa (el dolor de fondo)
Ataca el dolor comercial de ALIACE: vendedores enfocados en **precio y volumen** y no en valor de marca. El comité busca métricas de **"valor cliente"**, no solo volumen, para profesionalizar la venta B2B. Ver [[21 — ALIACE]].

> [[42 — Alí]] se alimenta de esta misma fuente: el objetivo es que el agente diga exactamente la misma cifra que el comité.

Relacionado: [[21 — ALIACE]] · [[42 — Alí]] · [[33 — Preferencias de comunicación]]

Fuentes: [[62 — HANDOFF Nexus v2]], [[63 — Requerimientos Nexus v1]], [[65 — PDR ejecutivos (8-11 jun)]].

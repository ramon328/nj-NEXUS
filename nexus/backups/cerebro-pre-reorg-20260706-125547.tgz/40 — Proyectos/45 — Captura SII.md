---
tags: [proyecto, sii, tributario, finanzas]
actualizado: 2026-06-13
---

# 45 — Captura SII

> Bajar de forma automática y 24/7 todos los documentos tributarios de las empresas y dejarlos en Nexus.

## Qué hay que capturar
- Facturas de **compra y venta**, afectas (DTE 33) y exentas (DTE 34).
- Notas de **crédito (61)** y **débito (56)**.
- **Boletas de honorarios recibidas** (las que terceros le emiten a la empresa).
- Destino: PostgreSQL + dashboard React con gestión de acuse de recibo.

## La realidad técnica (clave)
- El **SII no tiene API REST oficial** (se confirmó tras revisar; antes se creía que sí).
- Mecanismos reales: portal web (CSV del RCV), web services SOAP (con certificado), y **casilla de intercambio** (correo donde el proveedor deja el XML).
- **Arquitectura híbrida:** push por IMAP (casilla de intercambio, único tiempo real en compras) + polling al RCV y a las BHE.
- Ojo: el RCV tiene latencia (8 días legales) — crítico para usar el IVA crédito a tiempo.

## La decisión de Nico: doble vía en paralelo (ejemplo perfecto de su criterio)
- **A) Inmediato (comprar):** **ApiPyme Profesional** (~1,5 UF/mes, refresco cada 2h, incluye honorarios recibidas).
- **B) Definitivo (soberano):** **LibreDTE Community** autohospedado en el Mac mini (~$0, usa el **certificado de representante** que cubre todas las empresas; nadie externo custodia la clave).
- Se prueban ambas y se decide con datos del trial. Ver [[32 — Cómo decide Nico|criterio build vs buy]].

## Punto fuerte: credenciales
- Un solo **certificado digital de representante** de Nico da acceso a las (al menos) 5 empresas. No entregar la clave a terceros si se autohospeda.

Relacionado: [[43 — Conciliación bancaria]] · [[44 — Comisiones automáticas]] · [[32 — Cómo decide Nico]]

Fuentes: [[69 — Handoff captura SII]], [[67 — Reporte de avances (3 jun)]].

---
tipo: nota
tags: []
creado:
---

# {{título}}

## Contexto

## Detalle

## Acciones / pendientes
- [ ]

## Relacionado
- [[000 Inicio]]

---
tipo: proceso
tags: [proceso]
---

# Proceso: {{nombre}}

**Objetivo:**
**Responsable:**
**Frecuencia:** (diaria / mensual / al cierre / …)

## Pasos
1.
2.
3.

## Sistemas / enlaces involucrados
-

## Errores comunes y cómo resolverlos
-

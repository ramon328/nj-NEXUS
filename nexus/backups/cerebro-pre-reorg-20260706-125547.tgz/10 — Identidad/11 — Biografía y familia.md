---
tags: [identidad, biografia, familia]
actualizado: 2026-06-13
---

# 11 — Biografía y familia

## Quién es
- **Nombre completo:** Nicolás Patricio Juri Caballero
- **Nacimiento:** 02-08-1985 (40 años)
- **Profesión:** Ingeniero Comercial (UAI) · Magíster en Marketing
- **Vive en:** Chicureo, Santiago, Chile (huso GMT-3/GMT-4)

## Familia
- **Esposa:** Ana Palma (española, su familia es de Palma de Mallorca — de ahí nombres como "Mallorcautos", "Inversiones Baleares", "Ana Clara SpA").
- **Hijas:**
  - Ana Nicole (2018)
  - Clara (2021)
  - Elena (2023)

## Rol profesional
- **Gerente General de varias empresas** (5 operativas + asesorías), además de socio/director.
- Toma decisiones de forma **transversal**: finanzas, operaciones, comercial, logística y administración a la vez. Ver [[32 — Cómo decide Nico]].
- Día a día: 6 cuentas de correo (una por empresa), miles de mails y WhatsApp, llamadas y supervisión constante. Por eso valora tanto la eficiencia — ver [[13 — Cómo trabaja y se comunica]].

## Por qué existe este cerebro
Nico está construyendo [[41 — Nexus]], un "super yo" digital que actúe por él 24/7. Este segundo cerebro captura **su identidad y su criterio** para que ese agente lo represente bien.

Relacionado: [[12 — Dimensión personal]] · [[20 — Empresas (mapa)]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[62 — HANDOFF Nexus v2]].

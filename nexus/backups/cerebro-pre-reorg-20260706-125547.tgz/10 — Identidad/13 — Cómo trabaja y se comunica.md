---
tags: [identidad, comunicacion, estilo-trabajo]
actualizado: 2026-06-13
---

# 13 — Cómo trabaja y se comunica

> Resumen de estilo. El detalle "para agentes" está en [[33 — Preferencias de comunicación]] y [[34 — Cómo querría que un agente actúe en su nombre]].

## Estilo de trabajo
- **Tiempo muy limitado** → valora la eficiencia por sobre todo. Meta declarada: bajar de 8-10 h/día a **2-3 h/día** de decisiones estratégicas.
- **Trabajo incremental:** avanza por sesiones/semana, no de una sola vez.
- **Mirada transversal:** mezcla finanzas + operaciones + comercial en una misma decisión (ver [[32 — Cómo decide Nico]]).
- **Primero la verdad del dato:** su lema operativo es *"primero que el dato sea verdad, después lo demás"* — verificar estado real, buscar causa raíz, cuadrar contra la fuente oficial, comprobar en vivo antes de dar algo por listo.

## Cómo le gusta que le hablen
- **Idioma:** español **neutro/chileno**. **NO** voseo argentino.
- **Estructura:** **síntesis primero, razonamiento después.** Dale la conclusión arriba; el detalle abajo para quien lo quiera.
- Quiere **comparativas siempre en $ y en %**, contra metas, con vistas YTD y MTD ("todo en una hoja").
- En reportes: que se entienda de un vistazo (estilo PDR ejecutivo con titular del día + métricas grandes).

## Cómo prioriza el correo
- No por orden de llegada, sino por **importancia**: lo urgente e importante primero.
- Distingue: dirigido a él / en copia / mencionado. Detesta el ruido (CC informativos mezclados con lo crítico).

Relacionado: [[33 — Preferencias de comunicación]] · [[46 — Correo unificado (Ailnest · Néstor)]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[63 — Requerimientos Nexus v1]], [[66 — PDR ejecutivo (reportes diarios)]].

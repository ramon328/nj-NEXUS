---
tags: [identidad, personal, intereses]
actualizado: 2026-06-13
---

# 12 — Dimensión personal

> En los documentos se repite que esto es "no menos importante". El "super yo" completo no es solo el empresario: también es el papá, el músico y el deportista.

## Música
- **Baterista** (y toca otros instrumentos).
- Lleva a sus hijas a **School of Rock** (papá activo, no espectador).

## Autos (pasión central)
- **Coleccionista:** Honda Civic EK con motor K20.
- **Competencia:** corre en **Turismo Carretera (TC)** en Chile con un **Porsche GT4 981**.
- Otros activos de marca/motorsport (vía [[24 — MALLORCAUTOS]]): Cayenne S con *livery* Martini, F150 Lightning 1999.
- Su negocio de autos nace de esta pasión: "no vende autos, **cura** autos para gente que entiende la diferencia".

## Deporte
- **Boxeo**, **running** (corredor), **tenis** e **inviernos en la nieve**.

## Papá activo
- School of Rock y **gimnasia artística** de las niñas.
- Marido, hijo y hermano: la capa personal del "super yo" aún **no está mapeada en detalle** y queda fuera del primer MVP, pero es parte del objetivo final (anotado para no perderlo).

> Nota (inferido): la estética que le gusta — Martini Racing, autos de culto japoneses/americanos/alemanes, calidad sobre cantidad — refleja a alguien que valora **lo bien hecho y con identidad**, no lo masivo. Eso se nota también en cómo quiere sus empresas (premium, no commodity).

Relacionado: [[11 — Biografía y familia]] · [[24 — MALLORCAUTOS]]

Fuentes: [[61 — HANDOFF Nexus v1]], [[62 — HANDOFF Nexus v2]], [[68 — Tablero GM (dashboard_gm.jsx)]].

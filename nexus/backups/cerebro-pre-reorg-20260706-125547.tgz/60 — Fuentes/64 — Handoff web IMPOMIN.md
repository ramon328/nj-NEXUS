---
tags: [fuente, handoff, impomin, web]
actualizado: 2026-06-13
---

# 64 — Handoff web IMPOMIN

- **Tipo:** handoff de desarrollo web (Nico/Gerencia → Ramón/dev).
- **Fecha:** mayo 2026, v1.0.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/Handoff_IMPOIM.docx`.

## Qué contiene
Tres tareas web para impomin.cl, salidas de un benchmark competitivo:
1. Visibilizar la propuesta integrada IMPOMIN + HN (ALTA).
2. SEO técnico por modelo de camioneta + estándar minero (MEDIA).
3. Visibilizar el programa B2B 30/60 días (MEDIA).
Más estándares técnicos (Core Web Vitals, mobile-first, accesibilidad AA, tracking). Buen ejemplo de su estilo: cada tarea cierra con un "Por qué importa".

Alimenta: [[22 — IMPOMIN]], [[23 — HN]], [[48 — Inteligencia de competencia (Rival Watch)]], [[33 — Preferencias de comunicación]].

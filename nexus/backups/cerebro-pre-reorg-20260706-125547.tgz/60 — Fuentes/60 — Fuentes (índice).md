---
tags: [fuentes, moc, trazabilidad]
actualizado: 2026-06-13
---

# 60 — Fuentes (índice)

> De aquí salió todo este cerebro. Cada nota resume un documento original y enlaza a su ruta, para poder rastrear cualquier afirmación. Los originales están (solo lectura) en `/Users/AIagenteia/Desktop/segundo_nico`.

## Handoffs (documentos maestros)
- [[61 — HANDOFF Nexus v1]] · 27 may 2026 — quién es Nico, portafolio, dolores, roadmap.
- [[62 — HANDOFF Nexus v2]] · 6 jun 2026 — arquitectura cerrada y avances (la Regla de Oro vive aquí).
- [[64 — Handoff web IMPOMIN]] · may 2026 — 3 tareas web de impomin.cl.
- [[69 — Handoff captura SII]] · 3 jun 2026 — captura tributaria, build vs buy.
- [[6C — Control de costos de IA]] · 4 jun 2026 — FinOps de IA, router de modelos.

## Requerimientos y reportes
- [[63 — Requerimientos Nexus v1]] · 12 jun 2026 — las 10 plataformas/proyectos pedidos.
- [[65 — PDR ejecutivos (8-11 jun)]] · 8-11 jun 2026 — reportes ejecutivos de avance.
- [[66 — PDR ejecutivo (reportes diarios)]] · 5 jun 2026 — bitácora de build.
- [[67 — Reporte de avances (3 jun)]] · 3 jun 2026 — avances Forja, Rail, autos, Nexus, SII.

## Código y tableros
- [[6A — Motor de conciliación (conciliacion.ts)]] — el motor banco ↔ SII.
- [[68 — Tablero GM (dashboard_gm.jsx)]] — dashboard de proyectos con notas ricas.
- [[6B — Arquitectura agente WhatsApp (Banva)]] — referencia de cómo correr un agente 24/7.

## No extraído
- [[6D — Documentos no extraídos]] — qué quedó fuera y por qué.

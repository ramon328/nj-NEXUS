---
tags: [fuente, handoff, nexus]
actualizado: 2026-06-13
---

# 62 — HANDOFF Nexus v2

- **Tipo:** documento maestro (avance + arquitectura cerrada).
- **Fecha:** 6 de junio 2026.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/HANDOFF_RAMON_NEXUS_v2.md`.

## Qué contiene
El documento **más importante para la esencia**. Define la **[[31 — Regla de Oro de Autonomía]]** (los 3 niveles), que Alí es el prototipo replicable, las dos capas (transversal + por empresa), la separación de fuentes de datos, el estado por frente (Alí, comité comercial, conciliación, Rail, SII, correo) y la nota de gobierno sobre activos personales vs. socios.

Alimenta: [[31 — Regla de Oro de Autonomía]], [[42 — Alí]], [[43 — Conciliación bancaria]], [[35 — Gobierno de activos personales vs empresa]], casi todas las [[50 — Situaciones (índice)|situaciones]].

---
tags: [fuente, handoff, nexus]
actualizado: 2026-06-13
---

# 61 — HANDOFF Nexus v1

- **Tipo:** documento maestro (handoff de Nico/Claude a Ramón).
- **Fecha:** 27 de mayo 2026.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/HANDOFF_RAMON_NEXUS_v1.md` (hay copias: `HANDOFF RAMON NEXUS v1.md` y el PDF `Claude_AGENTE_NJC.pdf`, que es el mismo contenido en imagen).

## Qué contiene
La base de la identidad de Nico: biografía, familia, dimensión personal, portafolio de 8 empresas, **matriz de dolores priorizada** (5 prioridades), el requisito transversal de comisiones, el stack técnico, un roadmap de 4 semanas y las preferencias de comunicación.

Alimenta: [[11 — Biografía y familia]], [[12 — Dimensión personal]], [[20 — Empresas (mapa)]], [[44 — Comisiones automáticas]], [[33 — Preferencias de comunicación]].

---
tags: [fuente, codigo, conciliacion]
actualizado: 2026-06-13
---

# 6A — Motor de conciliación (conciliacion.ts)

- **Tipo:** código TypeScript (motor de matching cartola ↔ documento SII). Único módulo con código entregado.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/C13E3E55-41DE-4B99-8F1A-3D44FF03456F-export.ts` (es `conciliacion.ts`).

## Qué contiene
El motor que clasifica cada movimiento en AUTO / SUGERIR / REVISAR. Sus comentarios explican el principio textual: *"Conciliar TODO a ciegas es peligroso. Este motor solo auto-concilia lo inequívoco... No emite pagos ni toca el banco. Solo lee y propone."* — la [[31 — Regla de Oro de Autonomía]] hecha código. Tipos de dominio: `MovimientoBancario`, `DocumentoSII`, interfaz `FuenteDatos`. TODOs: retención BHE y pagos parciales.

Alimenta: [[43 — Conciliación bancaria]], [[31 — Regla de Oro de Autonomía]], [[51 — Un agente quiere pagar a un proveedor]].

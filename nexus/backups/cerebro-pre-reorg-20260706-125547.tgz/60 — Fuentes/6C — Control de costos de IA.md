---
tags: [fuente, handoff, finops, ia]
actualizado: 2026-06-13
---

# 6C — Control de costos de IA

- **Tipo:** handoff técnico de FinOps de IA (Nico → Ramón).
- **Fecha:** 4 de junio 2026.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/HANDOFF_RAMON_COSTOS_IA_v1.md`.

## Qué contiene
El módulo transversal para medir y controlar el gasto de IA. Logging por llamada, tabla `ai_usage_log`, **router central** que elige modelo por configuración, y la **regla de dos carriles** (volumen=barato / decisión=premium). Aquí está textual el criterio de fondo: cada agente debe poder decir **cuánto cuesta y cuánto valor genera**; el que no, es candidato a recorte.

Alimenta: [[57 — Una herramienta o agente cuesta caro]], [[58 — Hay que decidir qué modelo de IA usar]], [[32 — Cómo decide Nico]], [[34 — Cómo querría que un agente actúe en su nombre]].

---
tags: [fuente, codigo, tablero]
actualizado: 2026-06-13
---

# 68 — Tablero GM (dashboard_gm.jsx)

- **Tipo:** componente React (dashboard de proyectos de gerencia general) con datos por defecto muy ricos.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/dashboard_gm.jsx`.

## Qué contiene
Más allá del código UI, los `DEFAULT_PROJECTS` traen notas detalladas de cada proyecto: **Nexus** (visión, hardware Mac mini M4 Pro, costos USD 50-80/mes), **ALIACE** procurement IA (3 modelos, 12 variables, hit rate 67,6%), **Mallorcautos marca** (narrativa "curar autos", estrategia unicornios, plan Martini en 3 fases), **mallorcautos-platform** (clustering de autos), **IMPOMIN benchmark** (mapa competitivo por tiers, plan norte Antofagasta), **RPA Santander** (6 empresas con RUT y cuentas, anti-bot Akamai) y **RPA SII**. Es la fuente más rica para empresas y dimensión personal.

Alimenta: [[24 — MALLORCAUTOS]], [[22 — IMPOMIN]], [[41 — Nexus]], [[12 — Dimensión personal]], [[20 — Empresas (mapa)]], varias [[50 — Situaciones (índice)|situaciones]].

---
tags: [fuente, requerimientos]
actualizado: 2026-06-13
---

# 63 — Requerimientos Nexus v1

- **Tipo:** documento vivo de requerimientos (Nico → Ramón), formato tabla a completar.
- **Fecha:** 12 de junio 2026.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/Requerimientos_Nexus_Ramon_v1.docx`.

## Qué contiene
Las 10 plataformas/proyectos pedidos con prioridad, fecha y estado: ALIACE Plataforma Clientes, AilNest (correo/Néstor), Bank Portal (ALTA, Santander), Autos Intel, Rival Watch, System Plan, web general nicojuri.ia + "2cerebro/super yo", Comisiones HN/IMPOMIN (ALTA, vence 24/06), RPA SII (ALTA), Mac mini 24/7. Muestra el detalle fino de lo que Nico quiere de cada uno.

Alimenta: [[46 — Correo unificado (Ailnest · Néstor)]], [[47 — Sourcing de autos (Autos Intel)]], [[48 — Inteligencia de competencia (Rival Watch)]], [[44 — Comisiones automáticas]], [[49 — Comité comercial ALIACE]], [[33 — Preferencias de comunicación]].

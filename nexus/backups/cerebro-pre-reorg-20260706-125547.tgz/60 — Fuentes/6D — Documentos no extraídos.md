---
tags: [fuente, trazabilidad]
actualizado: 2026-06-13
---

# 6D — Documentos no extraídos / notas de extracción

## No extraído por texto (pero igual aprovechado)
- **`Claude_AGENTE_NJC.pdf`** (10 páginas). Es un PDF "vectorizado" sin capa de texto seleccionable; pypdf devolvió ~0 caracteres y no hay herramientas de OCR en el equipo (no hay `tesseract`/`ocrmypdf`). **Sin embargo, su contenido es el mismo del [[61 — HANDOFF Nexus v1]]** — se confirmó renderizando su primera página a imagen con `sips` y leyéndola. Por eso **no se perdió información**: todo su contenido está cubierto por la nota del v1.

## Archivos duplicados (mismo contenido, no se duplicó la nota)
- `HANDOFF RAMON NEXUS v1.md` = `HANDOFF_RAMON_NEXUS_v1.md` → [[61 — HANDOFF Nexus v1]].
- `pdrjune5(1).pdf` = `pdrjune5.pdf` → [[66 — PDR ejecutivo (reportes diarios)]].
- `reporte-avances.pdf` ⊂ `reporte-avances_1.pdf` (versión corta vs. larga) → [[67 — Reporte de avances (3 jun)]].
- El ZIP `Nico-20260613T043751Z-3-001.zip` y la carpeta `Nico/` contienen **copias** de los mismos archivos sueltos; no aportan documentos nuevos.

## Vacíos
- La carpeta `Nico/` solo tenía un `.DS_Store` (metadato de macOS, sin contenido).

## Herramientas usadas
- PDFs con texto: `pypdf` (instalado en el momento).
- `.docx`: `textutil -convert txt` (nativo de macOS).
- PDF imagen: render con `sips` + lectura visual.

---
tags: [fuente, arquitectura, whatsapp, agente]
actualizado: 2026-06-13
---

# 6B — Arquitectura agente WhatsApp (Banva)

- **Tipo:** documento de arquitectura (recorrido de lo construido por capas).
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/agente-whatsapp-banva-arquitectura (2).md`.

## Qué contiene
La referencia técnica de **cómo correr un agente por WhatsApp 24/7**: canal WhatsApp (Baileys), migración a servidor DigitalOcean en tmux, 7 MCP servers (incluido Supabase), fork del plugin con watcher outbound (file-drop IPC), productores cron (alertas de margen, reportes Flex de MercadoLibre) y loop conversacional. Es de "Banva" (otro contexto), pero es el **patrón de referencia** para los agentes de WhatsApp de Nico (Alí, Néstor) — salientes proactivas vía cron + entrantes reactivas vía polling.

Alimenta: [[42 — Alí]], [[46 — Correo unificado (Ailnest · Néstor)]].

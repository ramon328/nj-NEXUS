---
tags: [fuente, handoff, sii]
actualizado: 2026-06-13
---

# 69 — Handoff captura SII

- **Tipo:** handoff técnico (Nico → Ramón).
- **Fecha:** 3 de junio 2026.
- **Ruta:** `/Users/AIagenteia/Desktop/segundo_nico/HANDOFF_RAMON_CAPTURA_SII.md`.

## Qué contiene
Cómo capturar documentos tributarios 24/7. Explica que el SII no tiene API REST oficial, la arquitectura híbrida (IMAP casilla de intercambio + polling RCV/BHE), y la **decisión de doble vía** de Nico: ApiPyme (inmediato) + LibreDTE autohospedado (definitivo), con cuadro de costos. Punto clave: un solo certificado de representante cubre las 5 empresas.

Alimenta: [[45 — Captura SII]], [[52 — Hay que decidir comprar una herramienta o construirla]], [[32 — Cómo decide Nico]].

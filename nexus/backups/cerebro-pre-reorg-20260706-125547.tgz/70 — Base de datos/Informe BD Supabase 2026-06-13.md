# Informe — Base de datos Supabase de Nexus

**Fecha:** 2026-06-13
**Tipo de análisis:** Solo lectura (SELECT / count). No se modificó ni borró nada.
**Proyecto Supabase:** `ydcp****ws` (URL y claves enmascaradas por seguridad).

---

## 1. Resumen ejecutivo (para todos)

La base de datos está **viva y funcionando**. Nos conectamos correctamente con las credenciales que usa Nexus y comprobamos lo siguiente:

- La base de datos tiene **muchas más tablas de las que describe el esquema oficial** (`supabase-schema.sql`). El archivo de esquema solo define **6 tablas básicas** del "cerebro/agentes", pero la base real contiene **más de 50 objetos** (tablas + vistas) de varios sistemas distintos: autos usados, monitoreo de precios de la competencia, gestión de una clínica, y una app llamada "Forja". Esto **no es un error**: simplemente el esquema oficial está incompleto/desactualizado respecto a todo lo que hay realmente.

- Los datos importantes están concentrados en **dos sistemas con bastante actividad**:
  - **Autos usados** (tablas `listings`, `price_history`): ~26.000 registros de precios y ~25.700 avisos de autos. Es el sistema con más datos.
  - **Competencia/precios** (`productos_competencia`, `alertas_competencia`): ~3.400 productos y ~2.200 alertas.

- **La auditoría (registrarAccion) SÍ está funcionando**: existen registros reales en `log_acciones` escritos por los procesos `test` y `hub`. Es decir, cuando un agente actúa, queda la huella en la base. Eso sí, hay **muy pocos registros (solo 2)**, lo que sugiere que aún se usa poco o que la mayoría de procesos todavía no llaman a esta función.

- **El control de costos de IA está vacío**: la tabla `consumo_api` (que debería registrar tokens y dólares gastados con Claude) **no tiene ni una fila**. La función para escribirla existe en el código, pero nadie la está llamando todavía. Hoy no hay forma de saber cuánto se está gastando en IA mirando la base.

- Varias tablas de "negocio" del esquema oficial están **vacías**: `comisiones`, `folios_procesados`, `cierres`. Funcionalidad prevista pero todavía sin usar.

**Conclusión simple:** la base está sana y bien conectada; los sistemas de autos y de competencia ya producen datos reales; falta empezar a registrar el consumo de IA y usar más la auditoría.

---

## 2. ¿Qué tablas hay y para qué sirven?

### 2.1 Tablas del esquema oficial de Nexus (las 6 que define `supabase-schema.sql`)

| Tabla | Filas | Para qué sirve | Estado |
|---|---:|---|---|
| `agentes` | 3 | Registro de agentes (Nestor, Autos Intel, 2cerebro) y su estado | OK, con semilla |
| `log_acciones` | 2 | Auditoría: toda acción de un agente queda registrada | Funciona, poco uso |
| `consumo_api` | 0 | Control de costos: tokens y USD gastados con Claude | **VACÍA** |
| `comisiones` | 0 | Negocio: comisiones de vendedores | Vacía (sin uso) |
| `folios_procesados` | 0 | Negocio: folios DTE del SII procesados | Vacía (sin uso) |
| `cierres` | 0 | Histórico de cierres de período | Vacía (sin uso) |

### 2.2 Tablas EXTRA (existen en la base pero NO están en el esquema oficial)

Estas pertenecen a otros subsistemas de Nexus. Las agrupamos por dominio.

**Autos usados (búsqueda y precios de vehículos):**

| Tabla | Filas | Para qué sirve |
|---|---:|---|
| `price_history` | 26.337 | Historial de precios de cada aviso de auto |
| `listings` | 25.707 | Avisos/publicaciones de autos scrapeados |
| `opportunities` | 98 | Oportunidades de compra detectadas (con score) |
| `opportunity_activity` | 91 | Actividad sobre cada oportunidad |
| `model_liquidity` | 56 | Liquidez por marca/modelo (qué tan fácil se vende) |
| `excluded_brands` | 23 | Marcas excluidas de la búsqueda |
| `clusters` | 7 | Agrupaciones de modelos/segmentos |
| `search_profiles` | 3 | Perfiles de búsqueda |
| `scrape_runs` | 140 | Corridas del scraper de autos |
| `scrape_runs_nico` | 2 | Variante de corridas de scraper |
| `listing_snapshots` | 0 | Snapshots de posición en búsqueda (vacía) |

**Monitoreo de competencia / precios (Impomin):**

| Tabla | Filas | Para qué sirve |
|---|---:|---|
| `productos_competencia` | 3.457 | Productos scrapeados de la competencia |
| `alertas_competencia` | 2.201 | Alertas de precio/stock de la competencia |
| `catalogo_impomin` | 188 | Catálogo propio (costos, precios, margen) |
| `corridas_scraper` | 34 | Corridas del scraper de competencia |
| `mapeo_sku` | 29 | Mapeo SKU competencia ↔ SKU propio |
| `competidores` | 16 | Lista de competidores monitoreados |
| `reportes` | 5 | Reportes mensuales generados |
| `reglas` | 1 | Reglas (clave/valor) del sistema de competencia |

**Clínica / profesionales (gestión de pacientes y pagos):**

| Tabla | Filas | Para qué sirve |
|---|---:|---|
| `precios_especiales` | 571 | Precios especiales por paciente |
| `resoluciones_citas` | 522 | Resoluciones de citas |
| `descuentos_mensuales` | 122 | Descuentos mensuales por profesional |
| `profesionales` | 43 | Ficha de profesionales |
| `atenciones_funcionarios` | 11 | Atenciones a funcionarios |
| `tarifas` | 10 | Tarifas por tratamiento |
| `clientes_pago_mensual` | 0 | Clientes con pago mensual (vacía) |
| `planes_mensuales` | 0 | Planes mensuales (vacía) |

**App "Forja" (kanban / aprendizaje / usuarios):**

| Tabla | Filas | Para qué sirve |
|---|---:|---|
| `questions` | 110 | Preguntas de módulos |
| `forja_cards` | 46 | Tarjetas tipo kanban |
| `forja_projects` | 16 | Proyectos |
| `business_rules` | 15 | Reglas de negocio (clave/valor) |
| `forja_permissions` | 12 | Permisos por usuario/app |
| `forja_profiles` | 12 | Perfiles de usuario de Forja |
| `modules` | 11 | Módulos de aprendizaje |
| `module_progress` | 1 | Progreso por módulo |
| `users` | 1 | Usuarios |
| `forja_sessions` | 0 | Sesiones (vacía) |
| `opportunity_alerts_sent` | 0 | Alertas enviadas (vacía) |

**Vistas (consultas calculadas, no almacenan datos propios):**
`v_ranking_competidores`, `v_kpis_hoy`, `v_ultimo_snapshot`, `v_heatmap_categoria`, `v_salud_scrapers`, `v_precio_vs_impomin`, `v_alertas_feed`.

---

## 3. Comparación: esquema oficial vs. realidad

| Aspecto | Resultado |
|---|---|
| ¿Existen las 6 tablas del schema.sql? | **Sí, las 6 existen** con las columnas esperadas |
| ¿Hay tablas extra no documentadas? | **Sí, muchas** (~44 tablas + 7 vistas adicionales) |
| ¿Columnas coinciden con el schema.sql? | Sí en las 6 tablas oficiales (verificado vía API) |
| ¿La semilla de agentes se aplicó? | Sí: Nestor, Autos Intel, 2cerebro presentes |
| Tablas oficiales vacías | `consumo_api`, `comisiones`, `folios_procesados`, `cierres` |
| Tablas oficiales con datos | `agentes` (3), `log_acciones` (2) |

**Diferencia principal:** `supabase-schema.sql` es solo la "punta" (el núcleo de agentes/auditoría/costos). El resto de la base (autos, competencia, clínica, forja) se creó por fuera de ese archivo y no está documentado allí. La fuente de verdad real de la estructura **no es** `supabase-schema.sql`.

---

## 4. ¿Funciona la auditoría (`registrarAccion`)?

**Sí.** La tabla `log_acciones` tiene 2 registros reales:

| Agente | Acción | Recurso | Resultado | Fecha |
|---|---|---|---|---|
| `test` | `cerebro:crear` | `00-Inbox/prueba-conector.md` | ok | 2026-06-13 04:23 |
| `hub`  | `cerebro:crear` | `90-Agente/prueba-cadena.md` | ok | 2026-06-13 04:29 |

El helper `registrarAccion` escribe correctamente (campos `aprobado=true` y `requiere_aprobacion=false` cuando la acción no es crítica, tal como está programado). El volumen es bajo: parecen pruebas, no operación masiva.

`registrarConsumo` (el helper de costos) **no se ha ejecutado nunca**: `consumo_api` está en 0.

---

## 5. Problemas detectados

1. **Esquema oficial desactualizado.** `supabase-schema.sql` documenta 6 tablas, pero la base tiene ~50 objetos. Riesgo: si alguien corre `run-schema.mjs` confiando en ese archivo, no recreará la base real. La documentación no refleja la realidad.
2. **Sin control de costos de IA.** `consumo_api` vacía. Hoy no se puede saber cuánto se gasta en Claude desde la base de datos, aunque el código tiene el helper listo.
3. **Auditoría infrautilizada.** Solo 2 registros, ambos de prueba. La mayoría de los procesos (scrapers de autos, competencia, etc.) no parecen llamar a `registrarAccion`, así que sus acciones no quedan auditadas.
4. **Funcionalidad de negocio sin estrenar.** `comisiones`, `folios_procesados`, `cierres`, `clientes_pago_mensual`, `planes_mensuales`, `listing_snapshots`, `forja_sessions`, `opportunity_alerts_sent` están vacías: tablas previstas pero aún sin uso (no necesariamente un problema, pero conviene saberlo).
5. **`information_schema` no consultable vía API.** PostgREST no expone `information_schema` (esperado). El listado completo de tablas se obtuvo vía el documento OpenAPI del endpoint REST, que solo muestra objetos expuestos en el esquema `public`. Para una verificación 100% exhaustiva a nivel de Postgres haría falta `DATABASE_URL` (conexión directa), que **no está en el `.env`**.

---

## 6. Recomendaciones

1. **Actualizar `supabase-schema.sql`** para que refleje la base real, o dividirlo en módulos (`schema-core.sql`, `schema-autos.sql`, `schema-competencia.sql`, `schema-clinica.sql`, `schema-forja.sql`). Así `run-schema.mjs` deja de ser engañoso.
2. **Empezar a registrar consumo de IA**: llamar a `registrarConsumo(...)` en cada llamada a Claude (o al menos un resumen diario). Sin esto no hay visibilidad de costos.
3. **Extender la auditoría** a los procesos clave (scrapers, generación de reportes, acciones sobre oportunidades) llamando a `registrarAccion`. Hoy la mayoría de la actividad real no queda registrada.
4. **Agregar `DATABASE_URL` al `.env`** (conexión directa pg) si se quiere poder inspeccionar/recrear la estructura a fondo y correr `run-schema.mjs`.
5. **Revisar RLS.** El esquema activa Row Level Security sin políticas en las 6 tablas oficiales. Conviene confirmar que las tablas extra (autos, clínica con datos sensibles de pacientes/sueldos) también tengan RLS adecuado, especialmente si alguna app usa la clave anónima.
6. **Limpiar tablas de prueba** en `log_acciones` si se va a empezar operación real, para no mezclar pruebas con auditoría productiva.

---

## 7. Detalle técnico de la conexión

- **Cómo se conecta Nexus:** `shared/supabase.mjs` crea el cliente con `@supabase/supabase-js`, cargando `.env` con `process.loadEnvFile`. Usa `SUPABASE_SERVICE_ROLE_KEY` si existe (salta RLS), si no `SUPABASE_ANON_KEY`. Si faltan credenciales, `supa = null` y los helpers se vuelven no-op (degradación elegante).
- **Credenciales presentes en `.env`:** `SUPABASE_URL` (OK), `SUPABASE_ANON_KEY` (OK, 208 chars), `SUPABASE_SERVICE_ROLE_KEY` (OK, 219 chars). `DATABASE_URL`: **ausente**.
- **`@supabase/supabase-js`** está instalado en `shared/node_modules`, `hub/node_modules` y `conector-obsidian/node_modules` (no en la raíz).
- **Método de inspección:** script temporal en `/tmp` (ya eliminado) que importó el cliente real de `shared/supabase.mjs` y consultó `count` + muestras por tabla; el listado completo de objetos se obtuvo del documento OpenAPI de PostgREST (`GET /rest/v1/`), filtrando vistas (`v_*`) de tablas base.

> Nota de seguridad: en este informe no se incluyen claves ni la URL completa del proyecto; todo está enmascarado.
